// eslint.config.js
import { defineConfig } from "eslint/config";
import js from "@eslint/js";
import globals from "globals";
import tseslint from "typescript-eslint";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import prettier from "eslint-config-prettier"; // flat-config compatible

export default defineConfig([
  { ignores: ["dist", "coverage"] },   // use 'ignores' (not globalIgnores)

  // Include configs directly (NO 'extends' in flat config)
  js.configs.recommended,
  ...tseslint.configs.recommended,     // this is an array, so spread it
  reactHooks.configs["recommended-latest"],
  reactRefresh.configs.vite,
  prettier,                            // turn off rules that conflict with Prettier

  // Project-specific settings and overrides
  {
    files: ["**/*.{ts,tsx,js,jsx}"],
    languageOptions: {
      parser: tseslint.parser,
      ecmaVersion: 2022,
      sourceType: "module",
      globals: { ...globals.browser, ...globals.node },
    },
    rules: {
      "no-unused-vars": "warn",
    },
  },
]);
