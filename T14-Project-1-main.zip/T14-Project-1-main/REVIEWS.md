# Review Summary: IT2810-H25-T14

*Generated on 2025-10-14*

---

## REST API

**Manglende detaljer i feilhåndteringen**

Feilhåndteringen i fetch-kallene gir i dag kun en generell feilmelding uten nok kontekst fra API-et, noe som gjør det vanskelig å debugge og å gi brukeren presis informasjon om hva som gikk galt. Dette ble spesielt nevnt i frontendens datahenting hvor en enkel generell feil blir kastet i stedet for å inkludere statuskode eller responsinnhold. Konsekvensen er redusert observérbarhet og en dårligere utvikler- og brukeropplevelse når feil oppstår. Anbefalte tiltak er å logge eller videreføre mer informasjon fra API-responsen (for eksempel statuskode og body), vise mer beskrivende meldinger i UI, og beholde allerede gode praksiser for å mappe feil til riktige HTTP-koder slik at feilsøking og støtte blir enklere.

Reviewer(s): [Drew](#rest-api-drew), [Thea](#rest-api-thea)

---

**Ingen debouncing/rate limiting og filtrering kun på cache**

Det er ikke implementert debouncing eller noen form for rate limiting ved tasteinngang/fetching, og filtrering skjer kun på cachet data, noe som kan gi både overflødige kall og utdaterte søkeresultater. Dette ble påpekt i frontend-bruken av TanStack Query hvor kall trigges uten begrensning og filtreringen ikke nødvendigvis reflekterer frisk data fra API-et. Effekten kan bli dårlig brukeropplevelse ved rask typing, risiko for å treffe API-rater og at filtrert innhold ikke er oppdatert. Forbedringer kan være å legge inn debouncing ved søk, eventuelt rate limiting på klienten eller proxyen, og vurdere server-side eller re-fetch-baserte filtreringsstrategier i stedet for å stole utelukkende på cached data.

Reviewer(s): [Thea](#rest-api-thea)

---

**Manglende dokumentasjon om hvordan få API-nøkkel**

Det tok tid for en gjennomgang å finne fram til hvordan man skaffer API-nøkkel for Vinmonopolet, noe som tyder på at README eller prosjektets dokumentasjon mangler en klar veiledning. Dette påvirker nykommere og gjør det tungvint å sette opp prosjektet lokalt selv om .env og load_dotenv() er korrekt brukt for å skjule nøkkelen. For å forbedre onboarding bør dere legge inn en direkte lenke til Vinmonopolets API-side og en kort beskrivelse av stegene for å få tilgang til nøkkelen i README, samt eventuelt et eksempel på hvordan verdien skal settes i .env-filen. Dette vil redusere oppsettsfriksjon og gjøre prosjektet mer tilgjengelig for bidragsytere.

Reviewer(s): [Fiona](#rest-api-fiona)

---

## Dokumentasjon

**For mye gjentakelse og uoversiktlig prosjektstruktur**

Readme-fila inneholder noen deler som virker overflødige eller gjentas, som workflow, prosjektstruktur, features og intended use, og flere anmeldere nevner at deler av teksten bør slås sammen eller fjernes for å gjøre dokumentasjonen strammere. Prosjektstrukturen er beskrevet, men bør vises som en tydelig, innrykket liste slik at det raskt blir klart hvilke mapper og filer som ligger hvor. Nå gjør den gjentagende og ustrukturert teksten vanskeligere å skumme og øker terskelen for nye brukere som vil finne informasjon raskt. En klar forbedring er å fjerne unødvendige seksjoner, slå sammen overlappende avsnitt og bruke punktlister og underoverskrifter for å bryte opp teksten og gjøre informasjonen lettere tilgjengelig.

Reviewer(s): [Drew](#dokumentasjon-drew), [Fiona](#dokumentasjon-fiona)

---

**Manglende eller feilplasserte lenker til eksterne ressurser**

Det mangler noen viktige lenker og tydelig plassering av dem, for eksempel en VM-link som bør stå øverst i readme og en link til Vinmonopolets API med en enkel fremgangsmåte for å bruke den. Uten disse lenkene og instruksjonene blir det tyngre for personer utenfor gruppen å sette opp og kjøre prosjektet, spesielt når eksterne API-er krever egne steg. Å legge lenker tydelig i installasjons- eller hurtigstartseksjonen og inkludere korte, trinnvise beskrivelser vil gjøre installasjonen mer smertefri for nye bidragsytere. Plasser gjerne VM-linken helt øverst og legg API-lenken sammen med et kort "how-to" for å hente nødvendige nøkler eller endepunkter.

Reviewer(s): [Thea](#dokumentasjon-thea), [Fiona](#dokumentasjon-fiona)

---

**Uklart hva som testes ved "npm run test"**

Det står ikke klart i readme hva som faktisk testes når man kjører "npm run test", noe som gjør det vanskelig for lesere å vite hva testene dekker og hvordan testresultater skal tolkes. Denne mangelen på detalj finnes i testseksjonen i dokumentasjonen og påvirker både brukere og potensielle bidragsytere som ønsker å verifisere endringer. En enkel løsning er å beskrive hvilke testfiler eller testtyper som kjøres, hvilke hovedscenarier som dekkes, og eventuelt hvordan man kjører enkelte tester isolert. Å inkludere eksempelutdata eller en kort beskrivelse av suksess-/feil-tilstander vil også øke tilliten til testoppsettet.

Reviewer(s): [Drew](#dokumentasjon-drew)

---

**Stavefeil og språkvask**

Det er noen åpenbare skrivefeil i readme-en (for eksempel "enviroment" og "genereate") og enkelte formuleringer kunne vært strammere, noe som gir et mindre profesjonelt inntrykk. Slike feil går igjen i tekstdelen og kan både forvirre lesere og svekke dokumentasjonens troverdighet. En grundig gjennomlesing, bruk av en stavekontroll og gjerne en annen person til språk- og stilredigering vil rette opp disse problemene raskt. Å fjerne skrivefeil og forbedre språket vil gjøre dokumentasjonen ryddigere og lettere å forstå for alle brukere.

Reviewer(s): [Fiona](#dokumentasjon-fiona)

---

---

## HTML, CSS, Typescript

**Tilgjengelighet og fokusstyring**

HTML-bruken inkluderer allerede aria-attributter og semantiske elementer som hjelper skjermlesere, men det er fortsatt noen mangler som påvirker brukeropplevelsen for de som trenger tilgjengelighetstiltak. Spesifikt nevnes bedre fokusbehandling i dropdown.tsx og at ikke alle knapper har passende aria-labels, noe som kan gjøre navigasjon og forståelse vanskeligere for skjermlesere. Dette påvirker prosjektets brukervennlighet for personer med nedsatt syn eller de som navigerer med tastatur, og kan føre til at viktige kontroller blir vanskelige å finne eller bruke. Anbefalingene er å forbedre fokusstyring i dropdown-komponentene og gå gjennom alle knapper for å legge til konkrete aria-labels der det mangler, samt teste med skjermleser og tastaturnavigasjon for å verifisere at flyten fungerer som forventet.

Reviewer(s): [Drew](#html--css--typescript-drew), [Thea](#html--css--typescript-thea), [Fiona](#html--css--typescript-fiona), [Frank](#html--css--typescript-frank)

   
**Tomme, dupliserte og kommenterte filer som skaper rot**

Koden inneholder flere små eller helt tomme filer (for eksempel dropdown.css), dupliserte CSS-definisjoner (.card definert to ganger) og kommentert ut kode som gjør prosjektet mindre ryddig og vanskeligere å vedlikeholde. Slike filer og overflødige definisjoner gjør det tungvint å finne hvor endringer må gjøres og øker sjansen for inkonsistens og bugs. For å forbedre lesbarhet og vedlikeholdbarhet anbefales det å fjerne ubrukte og tomme filer, slå sammen små relaterte komponentfiler der det gir mening, og rydde opp i kommentert kode og duplikater i stilarkene. I tillegg bør all styling konsistent ligge i CSS-filer i stedet for å være spredt i komponentfiler, slik at det blir enklere å styre og endre designet.

Reviewer(s): [Drew](#html--css--typescript-drew), [Thea](#html--css--typescript-thea), [Fiona](#html--css--typescript-fiona)

   
**Visuell konsistens og responsivitet**

Det er flere designmessige inkonsistenser som påvirker det visuelle uttrykket, blant annet svak kontrast mellom logo og bakgrunn, ujevn bruk av border-radius og font, inkonsekvent fargebruk og knappestørrelser som ikke er balanserte. Dette gjør grensesnittet mindre helhetlig og kan svekke lesbarhet og brukeropplevelse på tvers av skjermstørrelser. Forslagene er å standardisere stilene (f.eks. fargepalett, border-radius og typografi), justere knappestørrelser for bedre balanse, gi select-elementet i filteroversikten mer omtanke, og bruke fleksible enheter som %, em eller rem fremfor faste verdier for å forbedre responsivitet. Å øke responsiviteten ytterligere og sørge for konsekvent fargebruk vil gi et mer profesjonelt og tilgjengelig sluttprodukt.

Reviewer(s): [Fiona](#html--css--typescript-fiona), [Hugo15](#html--css--typescript-hugo15)

   
**Semantikk og bruk av elementer (mindre bruk av div-er og manglende id-er)**

Selv om mange semantiske elementer brukes, finnes det fortsatt flere steder med generiske div-er som kunne vært byttet ut med mer meningsfulle elementer som header, nav eller section, og noen div-er mangler id-attributter som kunne hjulpet ved styling eller testing. Dette påvirker både tilgjengelighet og muligheten for entydig selektering i CSS/JavaScript, samt lesbarheten i strukturen for nye utviklere. En gjennomgang der div-er erstattes med riktige semantiske elementer der det er passende og der relevante elementer får id-er vil gjøre både markup og vedlikehold enklere. Slike endringer styrker også skjermleser-opplevelsen og gir et klarere dokumenttre for både utviklere og verktøy.

Reviewer(s): [Hugo15](#html--css--typescript-hugo15), [Frank](#html--css--typescript-frank)

   
**Detaljert feilhåndtering i TypeScript**

TypeScript-koden er generelt godt strukturert med gode typer og bruk av hooks, men feilhåndteringen kunne vært mer detaljert for å gi bedre tilbakemelding og robusthet i applikasjonen. Mangelfull eller generell feilhåndtering kan føre til uforutsigbare brukeropplevelser ved nettverksfeil eller andre unntak, og gjør det vanskeligere å feilsøke i produksjon. Forbedringer kan være å fange og gi konkrete feilmeldinger, skille mellom ulike feiltyper og eventuelt vise brukervennlige meldinger eller retry-logikk der det er relevant. En gjennomgang av error-flowene og implementering av mer spesifikk håndtering vil øke stabiliteten og gjøre det enklere å vedlikeholde.

Reviewer(s): [Thea](#html--css--typescript-thea)

---

## Responsivt design

**Dropdown/filtreringsliste fungerer ikke responsivt og posisjoneres feil**

Listen eller dropdownen som åpnes når man trykker "bla gjennom"/filtrer vises ikke riktig på mindre skjermer og kan havne delvis utenfor skjermen, noe som gir horisontal scrolling og gjør elementene vanskelig å bruke. Dette er observert både i selve "bla gjennom"-listen og i filter-popoveren, og gjelder både mobil og PC-visning. Problemet reduserer brukervennligheten ved at enkelte valg ikke er lett tilgjengelige og øker risikoen for at brukere går glipp av innhold. Anbefalt tiltak er å justere posisjonering og bredde til dropdowns/popovers, unngå faste width-verdier, og teste oppførsel på flere skjermstørrelser for å sikre at innholdet alltid holder seg innenfor viewporten.

Reviewer(s): [Drew](#responsivt-design-drew), [Hugo15](#responsivt-design-hugo15), [Thea](#responsivt-design-thea), [Fiona](#responsivt-design-fiona)


**For få breakpoints og manglende media queries / fleksible enheter**

Dere bruker i dag auto-tilpasning og kun to breakingpoints, og flere anmeldere påpeker at det bør legges inn egne media queries for pc, nettbrett og mobil for å få bedre kontroll over layoutendringer. Mangel på flere breakpoints og bruk av faste verdier gjør at enkelte komponenter ikke skalerer optimalt mellom standardstørrelser som 1024px, 758px og 480px. Dette kan føre til inkonsistent utseende og uforutsigbar oppførsel ved mellomstore skjermstørrelser. Forslagene er å legge til flere media queries (for eksempel 1024px, 758px, 480px), bytte faste størrelser til fleksible enheter (% / em / rem) og teste mer omfattende på ulike skjermstørrelser.

Reviewer(s): [Fiona](#responsivt-design-fiona), [Thea](#responsivt-design-thea)


**Tekstfelt/innhold klemmes mellom navigasjonskomponenter**

Et av tekstfeltene for ressursinnhold blir svært klemt mellom to navigasjonskomponenter på mindre skjermer, noe som gjør innhold vanskelig å lese og bruke. Dette ble spesielt nevnt i mobilvisning der layouten fører til at tekstboksen får for liten plass. Problemet svekker lesbarhet og kan hindre brukere i å fylle ut eller se innhold korrekt. Et foreslått grep er å endre lagrekkefølgen slik at navigasjonen løftes over tekstboksen eller restrukturere navigasjonen (for eksempel samle navigasjonselementer under menyer som "butikker") for å frigjøre plass til innholdet.

Reviewer(s): [Hugo15](#responsivt-design-hugo15)

---

## Utforming og stiling

**Svak kontrast og utydelig fargebruk**

Flera anmeldere peker på at kontrast og fargebruk ikke alltid er tydelig nok, spesielt mellom logo og bakgrunn og mellom søkeknappen og dens tekst. Dette gjør enkelte elementer vanskelige å se og svekker visuell tydelighet, særlig for logoen ("PolPal") og den hvite filter-knappen som forsvinner mot søkefeltet. Forslagene går ut på å gi knappene en egen, mer markant farge (for eksempel en lysere grønn eller en kontrastfarge som rød), gjøre knappbakgrunner mørkere for bedre tekstkontrast, og eventuelt farge stjerneikonet gult for å øke synligheten. Å stramme opp fargepaletten og sikre bedre kontrast vil gjøre grensesnittet mer tilgjengelig og intuitivt å bruke. 

Reviewer(s): [Drew](#utforming-og-stiling-drew), [Thea](#utforming-og-stiling-thea), [Fiona](#utforming-og-stiling-fiona), [Hugo15](#utforming-og-stiling-hugo15), [Lane11](#utforming-og-stiling-lane11)

---

**Knappplassering og navigasjonsknapper**

Flere mente at enkelte knapper og navigasjonselementer er enten dårlig plassert eller har feil størrelse, noe som påvirker flyten i brukeropplevelsen; filter- og "bla gjennom"-knappen oppleves malplassert og den hvite filter-knappen blir fort borte, mens pilene for å bla mellom butikker både kan virke rare og ta for mye eller for lite plass. Forslagene varierer fra å fjerne "bla gjennom"-knappen og vise listen et annet sted, til å endre pilene visuelt (forstørre dem, putte dem i sirkler eller bruke farger) eller gjøre navigasjonsknappene mindre slik at kortene får mer oppmerksomhet. Et annet konkret forslag er å gjøre navigasjonsknappene maksimalt like høye som butikk-kortene for bedre proporsjoner. Å optimalisere plassering og størrelse på disse elementene vil både forbedre estetikk og gjøre navigasjonen mer effektiv. 

Reviewer(s): [Drew](#utforming-og-stiling-drew), [Fiona](#utforming-og-stiling-fiona), [Hugo15](#utforming-og-stiling-hugo15), [Frank](#utforming-og-stiling-frank)

---

**Ressurskortet bør være mer kort-aktig og kompakt**

Det ble påpekt at ressursene vises i en lang, lysegrønn boks som strekker seg over hele bredden, noe som gjør innholdet mindre oversiktlig og gir kortene for lite visuell tydelighet. Forslagene er å gjøre kortene smalere og mer kort-lignende, legge til små ikoner for rask visuell gjenkjennelse, bruke fet skrift på butikknavn og grå tekst til metadata for bedre hierarki. En mer kompakt kortdesign vil gi bedre skille mellom elementer, gjøre det enklere å skanne innholdet og la hvert kort få mer visuell vekt. Dette ville også åpne for mer luft og gjøre siden mer balansert visuelt. 

Reviewer(s): [Drew](#utforming-og-stiling-drew), [Hugo15](#utforming-og-stiling-hugo15)

---

**Behov for mer helhetlig estetisk polering og intuitivitet**

Noen anmeldere mener at løsningen er minimalistisk og funksjonell, men mangler finpuss og mer estetisk arbeid som ville gjort appen mer intuitiv og engasjerende. Dette uttrykte seg som et ønske om flere detaljer, mer karakter i designet og økt brukervennlighet gjennom mindre estetiske forbedringer. Anbefalingene er å bruke mer tid på designfinish, legge inn ekstra visuelle elementer eller fargeaksenter, og forbedre småinteraksjoner for å gjøre helhetsinntrykket tydeligere. Å investere i denne typen polering vil gjøre appen mer tiltalende uten å endre kjernefunksjonaliteten. 

Reviewer(s): [Stefan27](#utforming-og-stiling-stefan27), [Thea](#utforming-og-stiling-thea)

---

**Uensartet styling (border-radius, fonter og select-komponent)**

Det er tydelig ulik bruk av border-radius og fonter i ulike deler av appen, og enkelte kontrollere som "Velg type" mangler styling, noe som gir et uprofesjonelt og uensartet inntrykk. Enkelte elementer bruker ulike skrifttyper (Times New Roman, Arial, Helvetica) og ulik avrunding på bokser og knapper, noe som reduserer visuell sammenheng. Forslagene er å standardisere radius for knapper og hovedbokser, velge én fontfamilie for hele appen og gi select-komponenten en konsistent og synlig stil. Å samle disse designelementene vil gi et mer konsistent og troverdig brukergrensesnitt. 

Reviewer(s): [Fiona](#utforming-og-stiling-fiona)

---

**For stor header på desktop**

Det ble nevnt at headeren tar opp for mye plass på PC-skjerm, og at dette reduserer den effektive arbeidsflaten og kan gjøre at brukeren må scrolle mer for å komme til innholdet. Anbefalingen er å redusere høyden på headeren slik at mer innhold er synlig ved første inntrykk og at fokus flyttes raskere til søk og resultater. En mindre header vil øke tilgjengelig skjemplass og fremheve selve funksjonaliteten i applikasjonen. 

Reviewer(s): [Frank](#utforming-og-stiling-frank)

---

## Web storage API

**Uklar lagringsstrategi for filtre og søk**

Gruppen har delt data mellom sessionStorage, localStorage og React state på en måte som gir uoverensstemmelse mellom hva som vises og hva som faktisk er aktivt; for eksempel lagres søkeord/resultater i sessionStorage mens filterstatus enten ligger i localStorage eller kun i React state, noe som gjør at filtervalg kan vises etter refresh uten å være aktive. Dette fører til et misvisende brukergrensesnitt og gjør det vanskelig å forutse hva som vil være bevart mellom oppdatering, lukking og gjenåpning av applikasjonen. Flere foreslår å velge en klar policy for hva som skal være midlertidig (sessionStorage) vs. persistente preferanser (localStorage), eller alternativt lagre både aktivt søkeord og faktisk filterstatus sammen slik at UI og intern tilstand alltid er synkronisert. En praktisk forbedring er å persistere søkefeltet og aktiv filterstatus i samme storage når det gir mening, eller rydde/initialisere UI fra storage ved oppstart slik at visning reflekterer reell tilstand.

Reviewer(s): [Drew](#web-storage-api-drew), [Fiona](#web-storage-api-fiona), [Thea](#web-storage-api-thea), [Frank](#web-storage-api-frank), [Hugo15](#web-storage-api-hugo15)

   
**Manglende konsoliderte storage‑utils og robusthet**

Lagringskoden er i dag spredt og håndteres ulikt flere steder, noe som øker duplisering og gjør det tungvint å teste eller endre oppførsel; flere påpeker behovet for felles helper-funksjoner eller hooks for parsing/serialisering, konsistente nøkkel‑konstanter og sentralisert try/catch-logikk. Dette påvirker vedlikeholdbarheten og robustheten, særlig ved behov for validering av parsed data, cache-invalidering (TTL/versjonering), håndtering av quota-feil og synk mellom faner (storage-event). Anbefalingen er å implementere små utils eller en usePersistentState-hook som samler denne logikken, legge på skjemavalidering av innholdet fra storage, og håndtere feil og opprydding ett sted for enklere videreutvikling og færre bugs. Slike endringer vil redusere duplisering, gjøre testing enklere og gi mer forutsigbar state across sessions og tabs.

Reviewer(s): [Stefan27](#web-storage-api-stefan27), [Frank](#web-storage-api-frank)

   
**Mangel på brukerkontroll over lagrede data og utnyttelse av preferanser**

Det finnes i dag ingen tydelig måte for brukeren å se eller fjerne data som er lagret i localStorage/sessionStorage, og enkelte brukerpreferanser som er åpnet for i designet utnyttes ikke fullt ut. Dette kan oppleves som dårlig kontroll og svekke tillit, særlig når valg oppbevares mellom økter uten enkel måte å tilbakestille dem på. En naturlig forbedring er å tilby enkle brukerinnstillinger for å rydde lagret data, velge om preferanser skal være persistente eller midlertidige, og å aktivt bruke tilgjengelige preferanse-mekanismer i UI. Å gi brukeren kontroll over hva som lagres vil forbedre personvern og brukeropplevelse.

Reviewer(s): [Thea](#web-storage-api-thea)

   
**Misvisende butikkstatus i UI**

Butikk-kortene viser ifølge tilbakemeldingen alltid at butikken er åpen, noe som skaper et misvisende inntrykk for brukeren og kan føre til feil forventninger rundt tilgjengelighet. Dette løpet opptrer i visningen av butikkkortene og påvirker direkte brukerens beslutninger om å besøke eller favorisere en butikk. Det bør sjekkes at logikken som beregner åpen/stengt-status bruker riktige tidsdata og eventuelle lagrede tilstander, og at UI oppdateres i takt med reell status eller klar melding dersom status ikke kan bestemmes. Retting kan innebære å korrigere beregningene, hente fersk status fra kilden eller fjerne statiske antakelser i presentasjonen.

Reviewer(s): [Fiona](#web-storage-api-fiona)

---

## Bruk av git

**Inkonsistente commit-meldinger og manglende metadata**

Gruppa bruker gode prefix som "feat", "fix" og "build" enkelte steder, men bruken er ujevn og noen commits bruker fortidsform ("fixed:") i stedet for imperativ form, noe som gjør git-historikken mindre konsistent og vanskeligere å automatisere eller søke i. Det foreslås å innføre og følge en felles konvensjon for commit-meldinger (f.eks. Conventional Commits), skrive meldinger i imperativ form, og gjerne inkludere hvilken fil som ble endret for større klarhet. Drew påpekte også at "co-authored" metadata mangler ved parprogrammering, så å legge inn denne informasjonen i commits vil bedre sporbarheten av hvem som har jobbet sammen. Thea og Fiona oppfordrer til mer regelmessig bruk av disse konvensjonene for å gjøre historikken ryddigere, og Lane11 anbefaler å inkludere filnavn i meldingen.

Reviewer(s): [Drew](#bruk-av-git-drew), [Thea](#bruk-av-git-thea), [Fiona](#bruk-av-git-fiona), [Lane11](#bruk-av-git-lane11)

   
**Uensartede og mangelfulle issue-beskrivelser og bruk av labels**

Flere issues er skrevet på ulik måte og varierer i detaljnivå, noe som gjør det mindre oversiktlig hva som faktisk må gjøres; reviewers mente at noen issues kunne hatt mer generelle og tydeligere beskrivelser for bedre styring av arbeidet. Hugo15 anbefaler også å bruke minst én label per issue/pull request for å raskt angi type og prioritet, og foreslo at issue-titler kan få mer utfyllende tekst (for eksempel hva som konkret mangler under "final touches"). Drew og Fiona påpekte at en felles mal eller system for hvordan issues skal se ut ville øke konsistensen og redusere forvirring. Implementer gjerne en issue-template og en obligatorisk label-policy for å gjøre arbeidsflyten mer forutsigbar.

Reviewer(s): [Drew](#bruk-av-git-drew), [Fiona](#bruk-av-git-fiona), [Hugo15](#bruk-av-git-hugo15)

   
**Språkinkonsistens i issues og commits**

Teksten på både issues og commit-meldinger veksler mellom norsk og engelsk, noe som skaper inkonsistens i prosjektet og kan gjøre det vanskeligere for både samarbeidspartnere og automatiserte verktøy å lese historikken. Drew og Fiona anbefaler å bestemme seg for ett språk (norsk eller engelsk) og holde seg konsekvent til dette gjennom hele repoet for bedre lesbarhet og standardisering. En klar språkpolicy bør kommuniseres til alle i gruppa og eventuelt håndheves gjennom maler eller CI-sjekker. Dette vil gjøre både onboarding og løpende samarbeid enklere.

Reviewer(s): [Drew](#bruk-av-git-drew), [Fiona](#bruk-av-git-fiona)

   
**Uspesifikke pull request-kommentarer og uklar ekstern kommunikasjon**

Det er bra at gruppa bruker pull requests og at flere godkjenner endringer, men Drew mener at kommentarene i PR-ene ofte kunne vært mer spesifikke og handlingsrettede, noe som ville gjøre review-prosessen mer effektiv. Fiona påpekte at det er vanskelig å vite om diskusjon og kommentarer har foregått utenfor GitHub, noe som svekker sporbarheten og kan skjule viktige beslutninger. Forbedringsforslag inkluderer å gi konkrete, linje-spesifikke kommentarer i PR-er, unngå å flytte diskusjoner utenfor GitHub uten å referere dem i PR-en, og sikre at godkjennelser og avklaringer er dokumentert i PR-tråden. Dette vil gi bedre dokumentasjon av beslutninger og enklere oppfølging av endringsønsker.

Reviewer(s): [Drew](#bruk-av-git-drew), [Fiona](#bruk-av-git-fiona)

   
**Direkte commits til main og ønske om utviklingsbranch**

Hugo15 observerte at det ser ut som det har blitt committet direkte i main uten merge, noe som kan gjøre main ustabil og vanskelig å garantere som en produksjonsklar gren. Han foreslår å innføre en "develop" branch hvor alt løpende arbeid skjer, og kun merge til main når arbeidet er ferdig og testet, for å holde main stabil. Å etablere en enkel branching-strategi (f.eks. feature-branches → develop → main) vil redusere risikoen for feil på main og forbedre samarbeidsflyten. Dette er et konkret og enkelt grep som kan implementeres raskt for bedre stabilitet.

Reviewer(s): [Hugo15](#bruk-av-git-hugo15)

---

## Utforming og interaksjon

**Søkeopplevelse og manglende autofullfør**

Søket krever at brukeren skriver bynavn på en ikke-intuitiv måte (måtte tidligere bruke "_" i stedet for mellomrom) og tilbyr ingen forslag eller autofullfør, noe som gjør det vanskelig å finne ressurser uten dokumentasjon. Dette skjer i søkefeltet når brukeren forsøker å finne steder som består av flere ord eller forkortelser, og det mangler også tilbakemelding dersom søket gir treff eller ikke. Problemet reduserer oppdagbarheten og fører til frustrasjon for nye brukere. Forslagene var å automatisk bytte ut mellomrom med "_" eller, enda bedre, akseptere mellomrom og legge til en dropdown/autofullfør med forslag og piltastnavigering for å gjøre søket mer brukervennlig.

Reviewer(s): [Stefan27](#utforming-og-interaksjon-stefan27), [Fiona](#utforming-og-interaksjon-fiona), [Frank](#utforming-og-interaksjon-frank), [Lane11](#utforming-og-interaksjon-lane11)

----

**Filtervisning og persistens fungerer ikke konsekvent**

Filtre påvirker hvilke butikker som vises, men filterpanelet og UI viser ikke alltid hvilke filtre som faktisk er aktive — etter å ha lukket, åpnet eller reloadet siden kan filtrene være lagret i oversikten men ikke anvendt på resultatene. Dette oppstår i filterkomponenten og ved oppfriskning eller restart av siden, og kan føre til at brukeren ser alle butikker selv om et filter ser ut til å være aktivt, eller at nullstillingsfunksjonen kun påvirker visningen av filterpanelet. Konsekvensen er forvirring om hva som vises og hvorfor, og tap av tillit til filtrets funksjonalitet. Anbefalte tiltak er å sikre at filter-tilstanden både reflekteres i UI og faktisk anvendes på resultatsettet, at nullstill fungerer som forventet ved å fjerne filtrene fra søkeresultatet, og at persistert tilstand inkluderer både UI- og anvendt-staten.

Reviewer(s): [Drew](#utforming-og-interaksjon-drew), [Fiona](#utforming-og-interaksjon-fiona), [Hugo15](#utforming-og-interaksjon-hugo15), [Frank](#utforming-og-interaksjon-frank)

----

**Oppstart og oppdagbarhet — ingen butikker vises før søk**

Når brukeren kommer inn på siden vises ingen butikker før de selv aktivt utfører et søk, noe som gjør førsteinntrykket utydelig og krever ekstra handling fra brukeren. Dette gjelder startsiden og gjør at nye brukere ikke umiddelbart forstår at de må søke for å få opp ressurser. Manglende synlige alternativer eller eksempler svekker oppdagbarheten og øker terskelen for bruk. Forslagene var å vise forslag eller populære lokasjoner ved oppstart, ha en tydelig instruksjon eller forhåndsutfylte eksempler, og eventuelt legge til en dropdown ved søk for å hjelpe brukeren å finne steder.

Reviewer(s): [Fiona](#utforming-og-interaksjon-fiona), [Stefan27](#utforming-og-interaksjon-stefan27), [Lane11](#utforming-og-interaksjon-lane11)

----

**Navigasjonskontroller og tastaturnavigasjon**

Posisjonen til pilene for å navigere mellom butikker flytter seg med lengden på butikkens navn, og dette gjør det ubehagelig å scrolle gjennom mange ressurser; samtidig savnes støtte for piltaster for å bla mellom butikker. Problemet opptrer i navigasjonskomponentene som brukes til å gå fram og tilbake mellom ressursene, og det gir en mindre stabil og tilgjengelig navigasjonsopplevelse. Dette påvirker flyten når man skal gjennomse flere butikker og gjør funksjonen mindre effektiv. Løsningen er å gjøre navigasjonskontrollene mer stabile i layouten og legge til tastaturnavigasjon (piltaster) for enklere og mer tilgjengelig bruk.

Reviewer(s): [Frank](#utforming-og-interaksjon-frank), [Fiona](#utforming-og-interaksjon-fiona)

----

**Tilgjengelighet, responsivt design og generelle UX-forbedringer**

Applikasjonen fungerer godt funksjonelt, men det er potensial for forbedringer innen tilgjengelighet, responsivt design og enkelte UX-detaljer som vil løfte kvaliteten ytterligere. Disse utfordringene gjelder helhetsopplevelsen på tvers av komponenter og skjermstørrelser, og kan påvirke brukere med ulike behov og enheter. Å forbedre kontraster, fokusindikatorer, responsiv oppførsel og sikre at interaksjoner fungerer godt på mobil vil gjøre løsningen mer robust og inkluderende. Anbefalingen var å gjennomgå tilgjengelighetsretningslinjer, teste responsivt oppsett og finpusse små UX-elementer.

Reviewer(s): [Thea](#utforming-og-interaksjon-thea)

----

**Terminologi, lokaliserings- og statusinkonsistens**

Det er inkonsistens i ordbruk og visning av status, for eksempel at utvalgsbetegnelser vises som både "middels" og "medium", at kortet bruker "størrelse" mens selecten bruker "utvalg", og at statusen "Åpen?" noen steder vises på engelsk selv om resten er på norsk. Dette forekommer i butikk-kortene og i filter/select-komponenten og gjør informasjonen mindre klar og kan redusere troverdighet. I tillegg ble det observert at kortene viser butikker som åpne selv utenfor åpningstid, noe som kan gi feilinformasjon. Forslaget er å standardisere terminologien på norsk, oversette status til "åpent"/"stengt" og rette logikken som bestemmer åpen/stengt-status slik at visningen reflekterer riktig tilstand.

Reviewer(s): [Fiona](#utforming-og-interaksjon-fiona)

----

---

## React

**App-komponenten gjør for mye — del opp logikk og bruk hooks/Context**

App.tsx bærer for mye ansvar for søk, filtrering og visning, noe som gjør koden tung å lese og vanskelig å gjenbruke. Flere steder nevnes også prop-drilling som kan løses ved å flytte relatert state ut av App og inn i små, gjenbrukbare hooks eller ved å bruke Context for delt state. Dette påvirker både vedlikeholdbarhet og testbarhet, og gjør det enklere å introdusere feil når logikk ligger sentralt i én fil. Anbefalingen er å splitte funksjonaliteten i egne komponenter (f.eks. SearchForm, Filter-komponenter), flytte logikk til custom hooks og bruke Context der mange komponenter trenger samme state, slik flere av dere foreslo.
Reviewer(s): [Stefan27](#react-stefan27), [Fiona](#react-fiona), [Thea](#react-thea), [Hugo15](#react-hugo15)

**Forbedre typesikkerhet — unngå "any" og styrk TypeScript-bruken**

Flere komponenter bruker typen any (bl.a. DropdownContentProps), noe som svekker fordelen ved TypeScript og kan skjule typefeil til runtime. Dette forekommer i enkelte props- og state-definisjoner og gjør koden mindre robust og vanskeligere å refaktorere trygt. Bedre, mer spesifikke typer og eventuelt enkel runtime-validering vil øke sikkerheten og klarheten i komponentene. Forslagene er å fjerne any, definere konkrete typer for props/state og vurdere enklere valideringsmekanismer der input kan være usikker.
Reviewer(s): [Stefan27](#react-stefan27), [Fiona](#react-fiona), [Hugo15](#react-hugo15)

**Ujevn filnavngivning og eksportstrategi — standardiser prosjektet**

Det er inkonsistente navnekonvensjoner i prosjektet (noen filer starter med stor bokstav, andre med liten) og flere anbefaler å velge én eksportstrategi for konsistens. Slike uoverensstemmelser går igjen i komponentnavn og filnavn og gjør det vanskeligere for nye bidragsytere å navigere og følge prosjektets stil. Dette påvirker lesbarheten og kan føre til import-feil eller forvirring ved skalering. Tiltakene som foreslås er å etablere og anvende en konsistent navnekonvensjon (f.eks. PascalCase for komponenter), og å beslutte én eksportstil (named vs default) gjennom hele koden.
Reviewer(s): [Thea](#react-thea), [Fiona](#react-fiona), [Stefan27](#react-stefan27)

**Tester ligger spredt — samle testene i en egen mappe**

Testfiler ligger blant komponentene i stedet for i en dedikert testmappe, noe som gjør prosjektstrukturen mindre ryddig og gjør det vanskeligere å finne og kjøre tester samlet. Denne plasseringen kan også føre til at tester blir oversett eller rotet til ved refaktorering. Det anbefales å flytte testene til en egen mappe (eller følge prosjektets teststrukturkonvensjon) for bedre organisering og enklere vedlikehold. Dette vil også hjelpe CI-oppsett og nye utviklere å finne testene raskere.
Reviewer(s): [Hugo15](#react-hugo15)

**Fjern ubruket kode og imports**

Det finnes ubruket kode og imports i prosjektet som bidrar til kodebloat og kan skape forvirring om hva som faktisk brukes. Slike rester kan øke byggetiden og skjule omstruktureringer eller feil som burde vært fjernet. En gjennomgang for å fjerne dead code og ubrukte imports vil gjøre codebasen renere og enklere å vedlikeholde. Dette bør gjøres løpende og gjerne som del av code review-prosessen.
Reviewer(s): [Thea](#react-thea)

**Sikre useEffect-cleanup og optimaliser re-renders**

Noen useEffect-brukere trenger bedre cleanup og det er risiko for unødvendige re-renders i enkelte komponenter. Manglende cleanup kan føre til minnelekkasjer eller uventet atferd ved avmontering, mens hyppige re-renders kan påvirke ytelsen i større lister eller komplekse UI. Forslagene er å sikre korrekt cleanup i alle effekter, og å bruke optimaliseringer som React.memo og useCallback der det gir gevinst for å redusere unødvendige oppdateringer. Dette vil forbedre både stabilitet og ytelse.
Reviewer(s): [Stefan27](#react-stefan27)

**Tilgjengelighet (ARIA) bør forbedres i interaktive elementer**

Noen interaktive komponenter bruker ARIA, men mangler viktige attributter som aria-selected på aktive elementer i dropdowns og aria-label på knapper, noe som svekker tilgjengeligheten. Dette gjør det vanskeligere for brukere med hjelpemidler å forstå hvilke elementer som er aktive eller hva knappene gjør. Å legge til disse attributtene og gjennomgå komponentene med et11y-sjekk vil gjøre applikasjonen mer tilgjengelig for alle brukere. Små ARIA-forbedringer er en rask vei til bedre brukeropplevelse for personer som benytter skjermlesere.
Reviewer(s): [Fiona](#react-fiona)

---

## Generell vurdering av løsninger

**Generell positiv tilbakemelding**

Tilbakemeldingen sier at nettsiden er veldig bra, uten at det pekes på konkrete feil eller forbedringspunkter. Dette gjelder helhetsinntrykket av løsningen og tyder på at design, funksjonalitet og brukervennlighet fungerer godt for denne brukeren. Mangelen på spesifikke forslag gjør det vanskelig å vite hvilke detaljer som kan videreutvikles, men den positive vurderingen styrker prosjektets troverdighet og bekrefter at nåværende retning fungerer. Det kan likevel være nyttig å innhente mer detaljert brukerfeedback for å finne eventuelle mindre forbedringsmuligheter.

Reviewer(s): [Lane11](#generell-vurdering-av-l-sninger-lane11)

---

## Testing

**Lav testdekning og behov for flere tester**

Det er et gjennomgående inntrykk at testdekningen er lav og at testmengden bør utvides utover de få eksisterende testene, slik at videreutvikling blir tryggere. Dette gjelder hele test-suiten og flere komponenter i applikasjonen, ikke bare enkelte filer eller mocks. Lav dekning kan gjøre det vanskelig å fange regresjoner når ny funksjonalitet legges til eller endres, og reduserer tilliten ved deploy. Forslaget er å prioritere å skrive flere enhets- og komponenttester for kjerneområder før ny funksjonalitet bygges ut for å øke dekningen og stabiliteten.

Reviewer(s): [Thea](#testing-thea), [Hugo15](#testing-hugo15), [Drew](#testing-drew), [Fiona](#testing-fiona), [Lane11](#testing-lane11)

---

**Manglende snapshot-testing**

Flere anmeldere påpeker at snapshot-tester ikke er tatt i bruk i prosjektet, og at slike tester kan være nyttige for å fange uventede endringer i komponenters rendring. Uten snapshot-tester kan visuelle regresjoner eller utilsiktede endringer i markup lettere slumpe gjennom koden. Anbefalingen er å legge inn snapshot-tester der de gir verdi — særlig for presentasjonskomponenter med stabil output — samtidig som man vurderer når snapshots faktisk gir mening for vedlikehold.

Reviewer(s): [Thea](#testing-thea), [Fiona](#testing-fiona), [Hugo15](#testing-hugo15), [Frank](#testing-frank)

---

**Manglende dekning av spesifikke UI-interaksjoner og visuelle tilstander**

Flere anmeldelser peker på at viktige interaksjoner og visuelle tilstander ikke er godt nok dekket, eksempelvis filtrering, navigasjon, hamburgermeny og enklere komponenter. Dette gjelder tester som simulerer brukerinteraksjoner og sjekker visuelle eller tilstandsmessige endringer i brukergrensesnittet. Manglende slike tester øker risikoen for at brukeropplevelsen brytes ved endringer, særlig i kritiske flyter. Løsningen er å legge til flere komponent- og integrasjonstester med realistic userEvent-simuleringer og fokus på filtrerings- og navigasjonsflyter for å sikre at UI oppfører seg som forventet.

Reviewer(s): [Fiona](#testing-fiona), [Drew](#testing-drew), [Hugo15](#testing-hugo15), [Lane11](#testing-lane11)

---

**Uklart om manuelt testing av responsivt design**

Det fremgår ikke av dokumentasjonen at gruppen har testet applikasjonen manuelt for responsivt design, og flere anmeldere savner denne informasjonen. Uten dokumentasjon blir det uklart om ulike skjermstørrelser og breakpoints er verifisert, noe som kan føre til uoppdagede UI-problemer på mobile enheter. Det anbefales å dokumentere hvilke manuelle viewport-tester som er gjort, eventuelt legge til automatiserte viewport-tester eller beskrive testprosedyyrer i README slik at responsivitetspåliteligheten blir tydelig for andre utviklere og sensorer.

Reviewer(s): [Drew](#testing-drew), [Fiona](#testing-fiona)

---


# Original Feedback

## REST API

<a id="rest-api-drew"></a>
**Reviewer Drew:**

> Data hentes på en ryddig måte, med fetch, og har også feilhåndtering. Feilhåndteringen kaster bare en generell feilmelding dersom noe skulle gå galt. Kan være lurt å legge til mer info, f.eks. API-svar eller en tekstmelding, slik at det blir enklere å debugge. 

<a id="rest-api-thea"></a>
**Reviewer Thea:**

> Fin proxy-arkitektur. Smart bruk av TanStack Query. God separation of concerns. Solid testing med MSW.
> 
> Dere kan gjøre brukeropplevelsen bedre ved errors. Nå var det ingen debouncing/rate limiting, det kan dere gjerne fikse. Filtering skjer kun på cached data.

<a id="rest-api-stefan27"></a>
**Reviewer Stefan27:**

> FastAPI-proxy skjuler API-nøkkel, bruker miljøvariabler/CORS og mapper feil til riktige HTTP-koder. Frontend kaller via miljøstyrt base-URL, URL-encoder riktig og utnytter TanStack Query for caching/conditional fetch. MSW gir realistisk testing. 
> 

<a id="rest-api-fiona"></a>
**Reviewer Fiona:**

> Dere bruker .env og load_dotenv\(\) riktig. Det gir god sikkerhet og fleksibilitet, veldig bra. Dere holder api nøkkelen skjult og bruker et endepunkt \(/api/stores\). Dere fanger opp både ReadTimeout og RequestError, og returnerer HTTP feilkoder. Responsen fra /api/stores er rask og inneholder strukturert JSON, bra. 
> 
> Det tok litt lang tid å finne riktig api nøkkel. Vurder å legge inn lenken til vinmonopolet sin api side og en kort beskrivelse av hvordan man får tilgang i README.

<a id="rest-api-hugo15"></a>
**Reviewer Hugo15:**

> Bruken av REST API er løst på en ryddig måte ved at kallet er kapslet inn i en egen funksjon og håndteres med React Query, som gir caching, feilhåndtering og støtte for loading-tilstand. Løsningen fungerer godt.

<a id="rest-api-frank"></a>
**Reviewer Frank:**

> API-et henter klart og tydelig butikker basert på navn. Det er bra bruk av encodeURIComponent for å ta hensyn til om det er spesielle tegn.

<a id="rest-api-lane11"></a>
**Reviewer Lane11:**

> God bruk av rest api, og god løsning. Det er også god bruk av caching og query.

---

## Dokumentasjon

<a id="dokumentasjon-drew"></a>
**Reviewer Drew:**

> Gruppa har en detaljert readme som blant annet beskriver installering og kjøring av prosjektet, arbeidsflyt, prosjektstruktur, hvilke teknologier som er brukt, nettsidens funksjonaliteter og testing, bruk av AI. Denne readme-fila gjør at man får en god oversikt over prosjektet, og vet alt man burde vite før man kjører eventuelle kommandoer i terminalen. 
> 
> Readme-fila inneholder kanskje litt overflødig informasjon. "Workflow", "Project structure", "Features" og "inteded use" kunne for eksempel blitt utelatt. Jeg savner derimot litt informasjon om hva som faktisk testes når man kjører "npm run test".

<a id="dokumentasjon-thea"></a>
**Reviewer Thea:**

> Veldig god dokumentasjon! Den var ryddig, nøyaktig og god å lese. Til neste gang kan dere gjerne sette vm-linken øverst:\)

<a id="dokumentasjon-stefan27"></a>
**Reviewer Stefan27:**

> Jeg har ingenting å utsette på dokumentasjonen deres.

<a id="dokumentasjon-fiona"></a>
**Reviewer Fiona:**

> Dokumentasjonen er god og dekker mange viktige deler av koden og kodeprosessen: installasjon, prosjektstruktur, teknologi, funksjonalitet og arbeidsflyt. Den gir et godt innblikk i hvordan prosjektet er satt opp og hvordan det skal brukes.
> 
> For at dokumentasjonen skal være enda mer effektiv og profesjonell, er det noen områder som kan forbedres:
> Legg inn lenken til vinmonopolets api side og en enkel fremgangsmåte. Dette gjør installasjonen enklere for folk utenfor gruppen. Det er flere skrivefeil, som for eksempel "enviroment" og "genereate". Gå over teksten og rett opp alle skrivefeilene. Det er litt gjentagelse i teksten, noen av delene er mulig å sette sammen under samme punkt. Prosjektstrukturen bør bli satt opp underhverandre så det er enkelt å se hva som ligger inne i hvilke mapper. Bruk gjerne punktlister og underoverskrifter oftere for å bryte opp teksten så den blir enklere å lese.
> 
> Alt i alt har dere med det viktigste, men det kan forbedres

<a id="dokumentasjon-hugo15"></a>
**Reviewer Hugo15:**

> Dokumentasjonen er ryddig bygget opp med overskrifter, punktlister og seksjoner for installasjon, workflow, prosjektstruktur, teknologier og funksjonalitet. 
> Installasjonsinstruksjoner er enkle å forstå og trinnene gjør det enklere å komme seg gjennom.
> tydelig forklart hva brukeren kan gjøre og hva som blir lagret mellom bruk. 

<a id="dokumentasjon-frank"></a>
**Reviewer Frank:**

> Veldig oversiktlig og deskriptiv dokumentasjon. Her forklarer de alt som er innenfor kravene og mer. Har bare ros å gi på dette.

<a id="dokumentasjon-lane11"></a>
**Reviewer Lane11:**

> Dokumentasjonen er tydelig, strukturert og lesbar.

---

## HTML, CSS, Typescript

<a id="html--css--typescript-drew"></a>
**Reviewer Drew:**

> Bruk av HTML er ryddig, med bruk av elementer som header, dropdown og button, i stedet for bare div. Det er bra at gruppa bruker aria-attributter, slik at skjermleseren får mer informasjon om hva de ulike elementene gjør, og det gir brukere som ikke kan se skjermen en bedre opplevelse.
> 
> Når det kommer til CSS er det bra at gruppa bruker media-queries for god responsivitet. Det er også god bruk av klasser for struktur. I tillegg er det bra at gruppa har lagd egne CSS-filer for de ulike react-komponentene \(f.eks dropdownmenu\). Selv om dette strengt tatt ikke er nødvendig i et så lite prosjekt, er det en god vane å gjøre dette, og ikke minst ryddig. 
> 
> Det er bra at koden er modulisert i ulike komponenter i stedet for én stor fil, og bra at gruppa bruker riktige typer i koden i stedet for any. Noe kode som er kommentert ut kunne blitt fjernet.

<a id="html--css--typescript-thea"></a>
**Reviewer Thea:**

> God ryddig bruk av HTML, men i dropdown.tsx, kunne det vært bedre håndtering av fokus. 
> .card er definert dobbelt i css. 
> I typescript kunne feilhåndteringen vært mer detaljert.
> Ellers bra css og typescript.

<a id="html--css--typescript-stefan27"></a>
**Reviewer Stefan27:**

> Her har jeg ikke noen tilbakemeldinger. Dere har løst det på en veldig god måte!

<a id="html--css--typescript-fiona"></a>
**Reviewer Fiona:**

> HTML strukturen er ryddig og med god oppdeling i komponenter. Mange av filene er veldig små, så kunne vært en mulighet å samle komponentene som angår det samme i samme fil. Et eksempel er alle dropdown filene. "dropdown.css" er helt tom.
> Dere bruker elementer som for eksemel <header> og <button> som er bra. 
> 
> Pass på at alle knapper har passende aria-label for bedre tilgjengelighet. 
> 
> Som nevnt tidligere er det litt dårlig kontrast mellom noen av elementene på siden \(logo - bakgrunn og søkknapp\). Det er også forskjellig boarder-radius og font \(nevnt under utforming og stiling\). Bytt ut de faste verdiene med fleksibile enheter som %, em eller rem. Legg inn litt design i select for "Velg type" i filteroversikten.
> 
> Noen steder i koden endrer dere på stylingen utenfor CSS filene. Anbefaler å ha all styling i CSS filer slik at det er enklere å finne og gjøre endringer på.
> 
> 
> Dere har noen tomme / nesten tomme filer som bør fjernes. De filene dere ikke bruker og kode som er kommentert ut gjør koden vanskeligere å lese og holde styr på.

<a id="html--css--typescript-hugo15"></a>
**Reviewer Hugo15:**

> Gruppen har gjort en god jobb med å strukturere koden med semantiske elementer som <main>, <section> og ligende noe som styrker tilgjengeligheten, men det brukes fortsatt flere <div> elementer, disse kunne vært erstattet med mer meningsfulle elementer, for eksempel <header> for å øke tilgjengeligheten på siden. CSS er ryddig organisert i egne filer per komponent, med hover-effekter og noe responsivitet, selv om jeg kunne ønsket litt mer, men fargebruken kunne vært mer konsekvent og knappene, spesielt navigasjonsknappene, burde justeres i størrelse for bedre balanse. TypeScript-koden er solid, med gode props-typer, bruk av hooks og React Query.

<a id="html--css--typescript-frank"></a>
**Reviewer Frank:**

> Med tanke på HTML har dere brukt masse forskjellige elementer, men det ser ut som dere har brukt noen divs, og det uten id. Ellers er strukturen oversiktlig.
> 
> CCS er bra struktrert med god bruk av root. 
> 
> Godt strukturert implementasjon med typescript også. God bruk av aria-attributter for tilgjengelighet. React Query bruk er også positivt her.

<a id="html--css--typescript-lane11"></a>
**Reviewer Lane11:**

> Det er god bruk av html, css og typescript. 

---

## Responsivt design

<a id="responsivt-design-drew"></a>
**Reviewer Drew:**

> Gruppa har løst kravet om responsivt design, da siden og de fleste ulike komponentene på den tilpasses skjermen når den blir mindre, men jeg savner dette på listen som kommer opp når man trykker på "bla gjennom". Denne listen tilpasses ikke skjermen slik den burde på verken mobil eller pc.

<a id="responsivt-design-thea"></a>
**Reviewer Thea:**

> Dere viser en grunnleggende forståelse for responsive teknikker. Smart bruk av flexbox i header-komponenten! Gode mobile-tilpasninger for søkebar!
> 
> Dere har kun 2 breakingpoints, dere kunne gjerne hatt flere. Dropdownposisjoneringen kan jobbes mer med. Det hadde vært fint med testing på flere skjermstørrelser.

<a id="responsivt-design-stefan27"></a>
**Reviewer Stefan27:**

> Responsivt design er løst på en god måte. Applikasjonen er ryddig og fin ved alle skjermstørrelser.

<a id="responsivt-design-fiona"></a>
**Reviewer Fiona:**

> Nettsiden bruker auto tilpassning, og mangler bruk av media queries. Det bør være egne queries for å tilpasse utseende til ulike størrelser \(pc, tablet og mobil\). Filter-popover har for eksempel en satt width. Denne endrer seg ikke uansett hvor stor skjermen er. Dere har lagt inn at search-form endres når skjermen er mindre enn 520px. Dette fungerer fint, men anbefaler å gjøre det når siden bytte mellom tablet og mobil\(758px - 480px\).
> 
> CSS filene er delt opp per komponent, noe som gjør det enkelt å isolere og teste endringer
> 
> Forbedringsforslag: legg til media queries for blant annet header, card og search-input. Bruk størrelsene 1024px, 758px og 480px \(standard størrelser for pc, tablet og mobil\). Endre faste verdier til å være fleksibile \(%, em, rem osv.\), eller hvertfall endre dem når bredden går fra en til en annen.

<a id="responsivt-design-hugo15"></a>
**Reviewer Hugo15:**

> når jeg minkser siden ser det ut til at den er responsivt. For eksempel blir søk knappen flytten under søkefeltet for at det skal se bedre ut. Dropdown derimot viser at ikke alt er responsivt, ved å trykke på dropdown på en mobil vil føre til at rundt halvparten av den havner utenfor skjermen og man kan begynne å scrolle bortover. 
> 
> tekstboksen for ressursen blir også veldig most mellom de to navigasjons komponentene. En mulig løsning kunne vært å heve navigasjon over tekstboksen slikt at den kan bruke hele skjermen mens navigasjon var mellom for eksempel "butikker" for å spare plass. 

<a id="responsivt-design-frank"></a>
**Reviewer Frank:**

> Applikasjonen er veldig responsiv og tilpasser seg alle type vinduer på mobil, nettbrett og pcer. Positivt at dere fikk søk-knappen til å være under søkefeltet om en minimerer vinduet nok.

<a id="responsivt-design-lane11"></a>
**Reviewer Lane11:**

> Det er bra responsivt design, det passer bra til pc-skjermen når jeg er på nettsiden.

---

## Utforming og stiling

<a id="utforming-og-stiling-drew"></a>
**Reviewer Drew:**

> Applikasjonen er enkel og oversiktlig, layouten er lett å forstå, med søkefelt øverst, filter-knapp og resultat under. Vinglass-logoen og stjernen for favoritt er intuitive og gir en visuell forankring til innholdet. 
> 
> Det er grei bruk av farger - jeg liker bruken av mørkegrønn til overskriften/logoen og lysegrønn til innholdet som dukker opp - men det kunne gjerne vært én egen farge til knappene. Disse kunne for eksempel vært i en litt lysere grønn, eller til og med rød, for å matche logoen. Det viktigste er at knappene skiller seg ut. Den hvite filter-knappen blir litt borte under det hvite søkefeltet. I tillegg synes jeg filter- og bla gjennom-knappen er malplasserte, disse ville jeg plassert og designet på en annen måte. En idé er å droppe bla gjennom-knappen helt, og heller vise listen over de ulike polene et annet sted på siden. 
> 
> Pilene for å bla mellom butikker ser litt rare ut. Selve pilene kan gjerne forstørres, legges i sirkler eller gjøres mer visuelt attraktive ved bruk av farger f. eks. 
> 
> Ressursene som hentes kunne også blitt gjort mer kort-aktig, ved å ikke la den lysegrønne boksen gå over hele bredden på skjermen, og f.eks. legge til små ikoner, fet skrift for butikknavn, og grå tekst for metadata.
> 

<a id="utforming-og-stiling-thea"></a>
**Reviewer Thea:**

> Dere har laget en minimalistisk, enkel løsning. Veldig kul idé, men jeg synes dere kunne lagt litt mer detaljer og tid i designet. Jeg likte logoen veldig godt, og fin plassering av komponentene på siden! Men gjerne litt mer farger eller noe mer som skjer. Kontrasten mellom grønnfargen og logoen ble litt svak.

<a id="utforming-og-stiling-stefan27"></a>
**Reviewer Stefan27:**

> Generelt har applikasjonen alt den skal ha. Den er litt lite intuitiv og det kunne ha blitt lagt ned litt mer innsats i det estetiske. 

<a id="utforming-og-stiling-fiona"></a>
**Reviewer Fiona:**

> Kontrasten mellom logoen og bakgrunnen er for liten. Det burde være en lysere bakgrunn eller ha en hvit kant rundt skriften "PolPal". Kontrasten mellom search-button og "Søk" er litt for liten. Gjør bakgrunnen på knappen litt mørkere \(trenger ikke veldig stor forskjell\). Anbefaler å gjøre navigeringsknappene maks like høy som butikk tekst boksen \("card"\). Mangler styling på select til "Velg type" i filteroversikten.
> 
> "border-radius" er veldig forskjellig på de ulike delene, prøv å få det til å henge litt sammen. Knapper kan ha lik radius, mens hovedboksene med bakgrunn kan ha lik. Dere bruker forskjellige typer font for skrift nå, vurder å bruke samme \(tittel og filter valgene er i TImes new Roman, knappene er i Arial og butikkinformasjonen er i Helvetica\).

<a id="utforming-og-stiling-hugo15"></a>
**Reviewer Hugo15:**

> Gruppen har laget en ryddig og oversiktlig layout med sentrering og faste seksjoner. Det er god avstand mellom komponentene, og fargebruken deler siden inn i tre tydelige områder som gjør den lett å orientere seg i. Noen forbedringspunkter kan være å endre knappene fra blå til en grønnfarge som passer bedre med resten av siden, og å gjøre navigasjonsknappene mindre slik at kortene får mer plass og oppmerksomhet. 

<a id="utforming-og-stiling-frank"></a>
**Reviewer Frank:**

> Alle funksjoner er intuitivt plassert, og elsker de store pilene for å gå frem og tilbake mellom ressurser. Noe å pirke på er at headeren tar halve plassen på pc-skjermen, kanskje den kunne vært mindre?

<a id="utforming-og-stiling-lane11"></a>
**Reviewer Lane11:**

> Det er brukt gode farge og det er et godt skille mellom hva som er knapp og ikke og det er enkelt å lese tekst. Det er grei størrelse på alle bokser og containers. Kunne kanskje hatt gul farge for stjerne istedenfor svart.

---

## Web storage API

<a id="web-storage-api-drew"></a>
**Reviewer Drew:**

> Gruppa bruker sessionstorage til alt brukeren skriver inn i søkefeltet, noe som passer veldig bra. Localstorage brukes til filter og lagring av favoritter. Her kunne gruppa vurdert bruk av kun sessionstorage til filtrering, slik at filtre man tidligere har satt på ikke fortsatt er huket av etter man lukker og åpner applikasjonen igjen. Det var kun et krav at filtrene fortsatt skulle være på etter reload av siden, ikke etter lukking og åpning igjen. 

<a id="web-storage-api-thea"></a>
**Reviewer Thea:**

> God bruk av error handling og fallbacks. Smart med lazy initialization. 
> God separation av localStorage vs sessionStorage.
> 
> Inkonsistent storage-strategi for relaterte data.
> Det er ingen brukerkontroll over lagret data, det kunne vørt fint til videre utvikling.
> Dere har lagt opp til muligheter for brukerpreferanser som ikke blir benyttet. Det kunne også vært utviklet videre.

<a id="web-storage-api-stefan27"></a>
**Reviewer Stefan27:**

> Dere skiller riktig mellom localStorage \(persistente valg/favoritter\) og sessionStorage \(søkeord/resultat-cache\), har try/catch med fornuftige fallbacks, konsistente nøkler og effektiv Set-bruk for favoritter. Dere kan vurdere å konsolidere all lagring i små utils/hooks \(felles key-konstanter, parsing/serialisering\), legg på validering av parsed data, cache-invalidering \(TTL/versjonering\) og enkel opprydding, håndter quota-feil, og vurder storage-event for tab-synk. Dette gir mindre duplisering, enklere testing og mer robust state på tvers av sesjoner og faner.
> 

<a id="web-storage-api-fiona"></a>
**Reviewer Fiona:**

> Dere bruker både sessionStorage og localStorage. Favoritter lagres i localStorage, noe som gjør at de huskes mellom økter. sessionStorage brukes til å lagre søkeord og resultater, slik at data ikke går tapt ved sideoppdatering
> 
> Filterstatus lagres ikke i noen storage, bare i React state. Etter refreshing vises tidligere filtervalg i oversikten, men de er ikke aktive. Dette gir et misvisende inntrykk av at filtreringen fortsatt gjelder. Her kunne det vært nyttig å lagre både filterstatus og aktivt søkeord sammen. 
> 
> Butikk-kortene viser alltid at butikken er åpen

<a id="web-storage-api-hugo15"></a>
**Reviewer Hugo15:**

> Gruppen lagrer favoritter i local storage på en god måte. Hvis brukeren lukker applikasjonen vil siden huske hvilke butikker har blitt favoritisert.
> Sessionstorage husker hvilkebyer brukeren har søkt på, noe som gjør at hvis siden relodes vil framdeles butikkene i byen du orginalt søkte på vises.
> et forbedringpotensiale kunne vært å også lagre det i søkefeltet, men det fungerer selv om det ikke er noe der. 

<a id="web-storage-api-frank"></a>
**Reviewer Frank:**

> Dere bruker localStorage til ting som er mer permanente \(favoritter og filtervalg\) og sessionStorage til midlertidige ting \(søk og siste resultater\). Det er litt vanskelig å holde oversikt på hvor data er faktisk lagret. En mulighet er å lage en egen usePersistentState hook som kapsler inn denne logikken.

<a id="web-storage-api-lane11"></a>
**Reviewer Lane11:**

> Det er brukt localstorage med json. Det er blitt brukt effektivt og hensiktmessig.

---

## Bruk av git

<a id="bruk-av-git-drew"></a>
**Reviewer Drew:**

> Gruppa har lagd issues inne på github for de tingene som skulle gjøres i prosjekt 1. Disse kunne inneholdt en litt bedre beskrivelse av hva som skulle gjøres, og kanskje vært litt mer generelle. Det gjør ting mye mer oversiktlig inne i github. I tillegg burde gruppa bestemt seg på forhånd om de vil skrive issuene på norsk eller engelsk.  
> 
> Det er bra når gruppa bruker f.eks. "feat", "fix" og "build" foran i commit-meldingene sine. Slik ser man enkelt hva slags type endringer som er blitt gjort, og git blir ryddigere. Det er forøvrig ikke alle commitmeldingene som ser slik ut, så det kunne vært bedre. 
> 
> Gruppas commit-meldinger er både på norsk og engelsk. Det er greit å bestemme seg for kun ett språk, slik blir det ryddigere. 
> 
> I tillegg ser jeg ingen commit meldinger som inneholder "co-authored". Dette er greit å ha med i commit-meldingene sine dersom man har parprogrammert.
> 
> Det er bra at gruppa legger inn kommentarer på pull requests inne i github, og at de sørger for at noen andre enn den som commitet godkjenner pull-requesten. Når det er sagt, kunne kommentarene vært litt mer spesifikke.

<a id="bruk-av-git-thea"></a>
**Reviewer Thea:**

> God bruk av Git! Dette er en ryddig og oversiktlig kodebase med gode commitmeldinger, men dere kunne brukt conventional commits mer regelmessig for et enda ryddigere resultat.

<a id="bruk-av-git-stefan27"></a>
**Reviewer Stefan27:**

> Git historikken deres ser bra ut. Dere har et fornuftig antall issues og pull request med tanke på arbeidsmengden. 

<a id="bruk-av-git-fiona"></a>
**Reviewer Fiona:**

> Issues er skrevet på veldig forskjellig måte. Dere bruker både Fixing, fix:, engelske setninger og norske setninger. Prøv å ha et fast system på hvordan issues skal se ut. 
> 
> I commitsene bruker dere hovedsakelig fix:, add:, add/fix: osv, men noen steder bytter dere over til fortid \(fixed: i steden for fix:\). Alle commits bør skrives som noe man skal gjøre, ikke noe man har gjort.
> 
> Dere har brukt mange branches og gitt hverandre codereviews. Veldig bra. 
> 
> Det er vanskelig å vite om dere har gitt hverandre kommentarer utenfor github, finner bare at dere har lest gjennom og syntes koden er bra

<a id="bruk-av-git-hugo15"></a>
**Reviewer Hugo15:**

> Gruppen har brukt issues, pull requests og pull reviews. 
> Gruppen bruker labels noen gangen, et forbedringspunkt vil være å ha minst en label på hver issue og pull request. Dette vil gjøre det enklere å forstå hva slags type issue det er. 
> Issues er beskrivende nok slikt at det er enkelt å forstå, kan også legge til mer informasjon, for eksempel issue #53 final touches, beskriv hva dere vet mangler.
> alle untatt 1 issue er lokket som enten betyr at dere enda mangler noe eller har glemt å lokke den.
> 
> Hvis det jeg ser er riktig har dere commited noe i main som ikke er en merge. framover er det lurt å unngå å commite direkte i main, selv om det er en liten ting. Et tisp kan være å lage en "develop" branch hvor alt dere gjør havner i "develop" og når dere er ferdige. Dette vil gjøre at main alltid vil være stabil, mens dere arbeider og tester i "develop"

<a id="bruk-av-git-frank"></a>
**Reviewer Frank:**

> Bruk av git er gjort perfekt med aktivt bruk av issues og deskriptive commit, pull requests og branches. Med tanke på branching ser det ut som alle har jobbet i sin egen branch for å fikse eller implementere ting, også blir alle pushene rewiewet grundig. Her imponeres det!

<a id="bruk-av-git-lane11"></a>
**Reviewer Lane11:**

> Det god bruk av issues og pull requests. Det er også bra det lager nye branches for hver issue. Kunne kanskje skrevet hvilken fil dere gjorde endringer i når dere skrive commiten deres.

---

## Utforming og interaksjon

<a id="utforming-og-interaksjon-drew"></a>
**Reviewer Drew:**

> Gruppa har laget en nettside PolPal som henter ressurser fra vinmonopolet sitt api, som viser butikknavn, adresse og by for ulike vinmonopoler i Norge, i tillegg til om polet er stort/lite og om det er åpent/stengt akkurat nå. Du får opp en ressurs ved å søke på en by, og du kan da bla frem og tilbake mellom de ulike vinmonopolene som finnes i denne byen. I tillegg kan du få opp en liste for alle polene i byen og trykke på et spesifikt pol \(hoppe til en spesifikk ressurs\). 
> 
> Et annet krav for innleveringen var at en bruker skal kunne gjøre et valg som påvirker utvalget av det som presenteres og hvordan det presenteres. Disse valgene skal også huskes selv om siden reloades \(persistens\). Gruppa har laget filtre for ressursene som presenteres; favoritt, open og vareutvalg, hvor brukeren da kan velge om de ønsker at polene som vises skal være en av deres favoritter, om de skal være åpne, og hva slags vareutvalg de skal ha \(stort, medium eller lite\). Valgte filtre påvirker hva som presenteres, men ikke hvordan. Når siden reloades, huskes valgene som brukeren har tatt. Valgene om filter huskes også dersom siden avsluttes og startes på nytt, men dette var ikke et krav.
> 
> Gruppa har også løst kravet om at en bruker skal kunne velge favoritter, ved at man trykker på en stjerne under informasjonen om polet man ønsker som favoritt. Disse favorittene huskes også selv om siden avsluttes og startes på nytt. 
> 
> Alt i alt har gruppa løst kravene for hvordan ressurser skal presenteres og interageres med på en god måte, men kunne gjort noe mer med hvordan utvalget av ressurser presenteres når brukeren bruker filtrene.  

<a id="utforming-og-interaksjon-thea"></a>
**Reviewer Thea:**

> Dere har laget en solid applikasjon som oppfyller kravene for hvordan ressursene presenteres og interageres med. Bruken av TanStack Query, storage APIs, og testoppsett var spesielt bra! Dere har litt forbedringspotensiale i tilgjengelighet, responsivt design, og noen UX-detaljer. Med forbedringer på disse områdene vil prosjektet være på et meget høyt nivå.
> 
> 

<a id="utforming-og-interaksjon-stefan27"></a>
**Reviewer Stefan27:**

> Dere har gjort det oppgaven ber om. Man får presentert en og en ressurs, og kan bla mellom ressursene. Det er også mulig å søke opp lokasjoner og favorisere butikker. Disse favorittene lagres dersom siden reloades. 
> 
> Det er litt lite intuitivt hvordan man får opp disse ressursene uten å lese dokumentasjonen. Jeg savner også en form for bekreftelse på at det man søker på finnes i databasen, altså at dersom jeg skriver osl så kommer oslo opp som et forslag.  

<a id="utforming-og-interaksjon-fiona"></a>
**Reviewer Fiona:**

> Når brukeren kommer inn på siden vises det ingen butikker. Brukeren må selv søke på kjøpesenterene/stedene hvor vinmonopolene ligger. Hvis brukeren søker på et navn som består av flere ord må de skrive med _ og ikke mellomrom \(eksempel: mo i rana\). Dette er ikke åpenbart for brukeren. Dere har alerede med at brukeren kan skrive med både store og små bokstaver i tillegg til å bruke enter. Forslag til endring: legg inn at mellomrom i input blir byttet ut med "_". hadde vært fint om brukeren kan bruke piltastene til å bla gjennom butikkene
> 
> Hvis brukeren søker på et sted med flere butikker kan de bla gjennom butikkene. Når man kommer helt til enden begynner den fra begynnelsen. Veldig bra.
> 
> Brukeren får presentert en og en ressurs og kan enkelt hoppe til den butikken de vil fra listen. 
> 
> Favoritt knappen fungerer og de favoritiserte butikken blir husket hvis siden blir refreshet. Hvis siden blir lukket og åpnes på nytt husker ikke siden hva søkeordet var, som vil si at den ikke viser noen butikker. Hvis man søker på stedet man hadde favoritisert tidligere er det fortsatt favoritisert.
> 
> Filteret fungerer, men det er noen feil. Hvis brukeren nullstiller og lukker filteret, for så å åpne filteret igjen er filtrene som er aktive ikke lenger synelige. Her burde det vært sånn at når man nullstiller blir filteret fjernet fra hvilke butikker som er synelig og ikke bare nullstille filteroversikten. Når man endrer på filteret og lukker det, burde de filtrene som er aktive fortsatt være synelige i filteroversikten når man åpner den på nytt. 
> Når brukeren refresher siden er filteret lagret i filteroversikten, men det er ikke aktivt. Dette vil si at den viser alle butikkene uten filteret. Søkeordet man har brukt for å få opp butikker, er aktivt selv om man krysser ut navnet. Dette bør endres på
> 
> På butikk-kortene står det at alle butikkene er åpne selv om de er stengt i virkeligheten \(testet etter stengetid\). I "Velg type" selecten står det "middels utvalg" mens på butikk-kortet står det "medium". Det er også brukt order "størrelse" på kortet, men "utvalg" i selecten. Prøv å bruke like navn. Under butikk informasjonen står alt på norsk uten om statusen etter "Åpen?". Dette bør gjøres om til å vise norske ord \("åpent" / "stengt"\).

<a id="utforming-og-interaksjon-hugo15"></a>
**Reviewer Hugo15:**

> Gruppen har implementert en løsning som viser brukeren en og en butikk. Brukeren kan bruke navigasjonskomponentene til å bevege seg fram og tilbake, eller så kan brukeren velge en spesifik brutikk gjennom dropdown listen. 
> 
> Brukeren kan filtrere basert på favorit, status \(open\) og vareutvalg. brukeren kan velge blandt tre størrelser på vareutvalget. Hvis bruker lukker og åpner siden vil filtreringen bevares, men vil ikke bli vist på den måten. Altså hvis jeg velger å bare se favoritter også lukker siden når jeg da åpner opp siden vil filter vises bare for favoritter, men alle butikker blir vist. 
> 
> Favoritter blir også brukt, løsningen tydelig og tilgjengelig, favorittvalg blir lagret selv om brukeren lukker og åpner opp siden. 

<a id="utforming-og-interaksjon-frank"></a>
**Reviewer Frank:**

> Dere har alle de funksjonelle kravene med filtrering, presentering og favoritter løst på en god måte. Informasjonen om disse valgene lagres selvom en reloader eller avslutter nettleseren. 
> 
> Søken feiler med å fetche om en spør etter noe med mellomrom som f. eks. Oslo City. Dette fikses med å ha en underscore istedenfor mellomrommet, men det trekker. At plasseringen på pilene for å gå fram og tilbake er avhengig om hvor stort navnet til polet er oppleves negativt om en prøver å scrolle gjennom mange ressurser. En til liten pirk er meldingen man får "Ingen treff med valgte filtre" første gang man besøker nettsida.

<a id="utforming-og-interaksjon-lane11"></a>
**Reviewer Lane11:**

> Bra utforming og interaksjon.  Det er en visuell struktur og god kontrast mellom tekst og bakgrunn. Det er også enkelt å navigere seg, men savnet en dropdown når du søker etter sted, slik at man slipper å skrive hele navnet til et sted. Det er bra dere har tatt med fargeendring over knappene for å tydeliggjøre at man kan trykke på den. 

---

## React

<a id="react-drew"></a>
**Reviewer Drew:**

> Prosjektet har god struktur med tydelige mapper. Fint med en egen mappe for hooks og for komponentene, og selve komponentene blir heller ikke for store. Bra bruk av state og props.

<a id="react-thea"></a>
**Reviewer Thea:**

> God forståelse av hooks \(useState, useEffect, useMemo\), solid TypeScript-bruk i enkelte komponenter. Smart localStorage-integration, bra bruk av TanStack Query.
> 
> Savner en mer konsistent filnavngiving og komponentstruktur og bedre komponent-separasjon. Fiks unused code og imports.

<a id="react-stefan27"></a>
**Reviewer Stefan27:**

> Solid React-grunnmur med modulære komponenter, ryddige hooks og god TanStack Query-bruk. Dere burde nok velge én eksportstrategi, flytte relatert state ut av App til små hooks og bruke Context der dere har prop-drilling. Forbedre typesikkerhet \(unngå any, konsistent PascalCase, ev. enkel runtime-validering\), sikre korrekt useEffect-cleanup, og optimaliser re-renders med React.memo/useCallback. Vurder også å splitte ut byggesteiner \(f.eks. egen SearchForm\) for bedre gjenbruk.

<a id="react-fiona"></a>
**Reviewer Fiona:**

> Dere bruker useState fra sessionStorage og localStorage, noe som er bra for når brukeren refresher siden. Dere bruker props på en bra måte med "type" definisjoner. 
> 
> Dere har en god mappestruktur som gjør det enkelt å finne fram \(eks. components, hooks, styles og assets\). Dere burde gå over alle filene og endre på navnene så de har lik stil i hele mappen. Nå har noen av filene stor forbokstav først i navnet, mens andre har liten. App komponenten deres gjør det meste av arbeidet, vurder å fordele logikken for søk, filtrering og visning i egne komponenter.
> 
> 
> Forbedringsforslag: unngå å bruke "any" i DropdownContentProps, det er bedre å bruke en mer spesifikk type. Dere bruker "aria" noen steder, men vurder å legge til "aria-selected" på aktive elementer i dropdown og "aria-label" på knapper. 

<a id="react-hugo15"></a>
**Reviewer Hugo15:**

> Gruppen har brukt React på en god måte med tydelig delte komponenter, fornuftig bruk av state og hooks, og en egen hook for favoritter som lagrer data i localStorage. Props er godt typet, men enkelte steder brukes any. Filstrukturen er ganske ryddig, men App.tsx inneholder mye logikk som kunne vært delt opp i egne filer for å gjøre koden mer oversiktlig. Totalt sett er bruken av React solid.
> Noe jeg merket var at testene ikke ligger i en egen mappe, men bare er plassert balndt komponentne. Det gruppen brude ha gjort var å plassert testene i en egen mappe for å gjøre strukturen enda mer ryddig. 

<a id="react-frank"></a>
**Reviewer Frank:**

> Det er godt gjennomtenkt bruk av state, props og hooks her. Selve strukturen på mappene er også oversiktlig og stemmer overrens med hvordan en bruker React. 

<a id="react-lane11"></a>
**Reviewer Lane11:**

> De har aktivt brukt pros, state og hooks. Komponentene er godt organisert og mappestrukturen i prosjektet er også godt organisert

---

## Generell vurdering av løsninger

<a id="generell-vurdering-av-l-sninger-lane11"></a>
**Reviewer Lane11:**

> Veldig bra nettside 

---

## Testing

<a id="testing-drew"></a>
**Reviewer Drew:**

> Jeg ser blant annet i handlers.ts i test-mappen at gruppa bruker mocking, og unngår dermed faktiske rest-api kall når testene kjøres. Dette gjelder også for de andre testene. 
> 
> Det brukes også snapshot under testing av FavoriteToggle. Dette er også et eksempel på komponenttesting. Kunne hatt flere komponenttester, f.eks på hamburgermeny.
> 
> Det står ikke noe i dokumentasjonen om gruppa har testet applikasjonen manuelt for responsivt design, men ut fra beskrivelsen av applikasjonen så stemmer min utprøving med det applikasjonen er ment å gjøre. 

<a id="testing-thea"></a>
**Reviewer Thea:**

> Veldig bra MSW mocking oppsett! God infrastruktur med Vitest. God mock-handling.
> 
> Dere har svært lav testdekningsgrad, så denne har stort potensiale dersom dere skal videreutvikle appen. Jeg klarer heller ikke å finne noen snapshot tester.

<a id="testing-stefan27"></a>
**Reviewer Stefan27:**

> Testoppsettet er moderne og solid. Vitest + jsdom, ryddig MSW-oppsett med riktig lifecycle/cleanup, god bruk av Testing Library \(getByRole, userEvent\) og realistiske API-mocker. 

<a id="testing-fiona"></a>
**Reviewer Fiona:**

> Testene viser god forståelse for komponenttesting og mocking. Favorittknappen er testet med realistisk brukerinteraksjon, og API kall er effektivt mocket med MSW for å unngå faktiske nettverkskall. Det gir raske tester. Alle testene kjører uten å feile. 
> 
> Det mangler snapshot-testing og mer dekning av visuell tilstand og interaksjon, spesielt for filtrering og navigasjon. Det er ikke dokumentert at responsivt design er testet manuelt. Testene dekker mye, men anbefaler å utvide for å dekke mer

<a id="testing-hugo15"></a>
**Reviewer Hugo15:**

> Gruppen har laget tre tester som dekker enkelte komponenter, og de bruker mocking slik at testene kan kjøres uten faktiske API-kall, noe som er bra. Samtidig ser jeg at det ikke er tatt i bruk snapshot-tester, slike tester kan være nyttige for å sikre at komponentene alltid rendres likt med samme input. Fremover vil det være lurt å utvide testdekningen til flere komponenter, og bruke snapshot-tester der det gir mening.

<a id="testing-frank"></a>
**Reviewer Frank:**

> Testene ligger rett ved testa komponent som er regnet som en god practice. I tillegg er setupet i sin egen mappe som gjør selve testene enda mer oversiktlige. Fra dokumentasjonen og utføringen virker det som dere har testa grundig gjennom lokalt. 
> 
> Testene i seg selv bruker mocking, testing av prop og state og bruker interasksjon og alle passer når jeg tester. Spesielt bra med user-events for realistisk brukerinteraksjon. Noe som mangler er en test med snapshot.

<a id="testing-lane11"></a>
**Reviewer Lane11:**

> Det er lagt til gode tester filbehandling og rest api. Kunne hatt noen tester for enkelkomponenter.

---

