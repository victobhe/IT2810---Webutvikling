
# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite and how to start working on the project.

## Required programs
Make sure this is installed.
- [node 24.6.0](https://nodejs.org/en)
- [python 3.13.3](https://www.python.org/downloads/)

## Setup and installation

Open visual studio code, press Ctrl + Shift + P and enter "git clone for URL". Paste in the HTTPS link and select the folder which the project will be in. Now you have access to the project files.

Next step is to install node, the node modules, set up your own enviroment for the "web server" and install the required libraries for the python back-end.

1. First step is to run the command ```npm install``` in the vscode terminal. You also need to install TanStack query packages ```npm install @tanstack/react-query```. Now you have the required node packages.

2. Second step is to set up the enviroment for the "web server". type in these commands
```cd back-end```,
```python -m venv .venv```,
```.venv\Scripts\activate```
This is to contain the packages needed to run the "web server". This makes it so the workspace is clean. You also need to update the .gitignore file so you later wont push this to the other team members.

3. Third step is to install the required libraries/packages.
```pip install -r requirements.txt```

4. Fourth step is to configure the .env files. For it all to work, you need to set up the enviroment variables needed for the project. These are sensitive files so just ask another team member(Simen) for this.

5. Fifth step is to run the "web server" containing the data and the "front-end webpage" that show the data.
```uvicorn main:app --reload --port 8000```

6. Open a new terminal and run:
```npm run dev```



## workflow

No-one shall push directly to main. Follow these steps when you are developing the website.

1. Create an issue on github. Make it descriptive. What it is fixing. Who is currently responsible for it and anything else which the person finds natural to add.

2. Now that an issue has been made, you can make a branch specifically for that issue. Still on the github issue website, check the right corner. It shall say something about creating a branch for this issue. Press it and follow the steps. (switch to the branch that has been made for the issue). There you can work on the issue.

3. When you are finished with the issue, create a pull request into main on the github website. Have another team member look at your work and discuss it. If it looks alright, leave a review so it can be merged and accepted. This is also on the website.

note: NTNU will not let you push directly to main 

## Project structure:
back-end/
  main.py
  requirements.txt
  .env.example

Forste_prosjekt/
  ...
node_modules/
  ...
public/
  ...

src/
  assets/
  components/
    api_call.tsx
    Card.tsx
    FavoriteToggle.tsx
    Footer.tsx
    HamburgerMeny.tsx
    Header.tsx
  hooks/
    useGavorites.tsx
  styles/
    card.css
    footer.css
    hamburgerMeny.css
    header.css
  Test/
    App.test.tsx
    api_call.test.ts
    App.integration.test.tsx
    FavoriteToggle.test.tsx
    HamburgerMeny.test.tsx
    handlers.ts
    setup.ts
    testServer.ts


  App.css
  App.tsx
  index.css
  main.tsx
  



## Technologies Used

React (TypeScript + Vite)
TanStack Query for fetching and caching API data
HTML Web Storage API (Session and Local)
Vitest for testing
ESLint and Prettier for linting and formating (and make the code pretty)
Plain CSS for styling


## Features

- presenting resources one at a time with navigation controls.
- Filter/sort functionality with presistance.
- Favorite system with presistence (local Storage).
- Responsive design for desktop and mobile.
- Accessible HTML structure following WCAG.


## Testing

We use Vitest + React Testing Library.
Tests are mocked – they do not call live APIs.
Example: FavoriteToggle toggles state and persists to localStorage.
- TO RUN tests:
'''npm run test'''

## Contributors

Simen Logstein
Sander Bratvold
Victor Beisland Hessevaagbakke
Kyrre Bell-Mathiesen

## Intended use

The website is designed as an university project for learning web development in React and typescript.
With the purpose of demonstrating:
- How to fetch and display data from a REST API
- How users can navigate through resources one at a time
- How to filter, sort, and favorite, with preferences saved using local- and session storage.
- How to build a responsive and user friendly interface


## How to use/functionality

The main goal of this website is to showcase the different Vinmonopol stores in a Norwegian city based on different criterias. 

Users can: 
Navigate forward/backward through items one by one
Jump direclty to a specific resource

By using the "filter" button you can choose between: "Favoritt", "Open" and "vareutvalg". When selecting one or more of this criterias, you filter out all irrelevant options, making it easier to find Vinmonopol stores that fit your needs. 

The website will also remember your preferences between use. For example, by using the "favoritt" function (clicking on the star icon), you are able to save your favorite Vinmonopol stores. 

## Use of AI

As a group, we have limited experience with web development, so the use of AI throughout this project has been paramount. That beeing said AI has not souly been used to generate core functionality code directly.
Rather we have tried to use AI to; Genereate ideas for project structure and documentation, Provided coding guidance and explanations of concepts, and suggested improvements to accesability, readability and testing.


# Choices and solutions

"Favoritt"
When using the "Favoritt" function - you have to also use the searchbar to see any results. 
Example: To see all of your favorite stores in Oslo you have to filter on "Favoritt" and type in Oslo in the search bar. This is because when making the API-call you have to specify a city (or a key word) in order to get any results.

To add/remove favorite stores you simply have to press the star icon beside the store.

"Displaying each element one by one"
We opted to use, big (easy to spot) arrows to navigate backwards and forwards through each element. This is both for better readability and accesability. 




## VM HOST

http://it2810-14.idi.ntnu.no/project1/

