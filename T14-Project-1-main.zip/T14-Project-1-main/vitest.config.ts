import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'

// Vitest config: testing only
export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/setupTest.ts'],
    globals: true,
    css: true,
    restoreMocks: true,
    clearMocks: true,
  },
})