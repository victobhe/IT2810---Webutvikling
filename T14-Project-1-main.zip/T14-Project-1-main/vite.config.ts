import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Vite config: dev server, build, proxy etc.
export default defineConfig({
  base: '/project1/',
  plugins: [react()],
  server: {
    proxy: {
      // Forward /api calls to your backend
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
    },
  },
})

