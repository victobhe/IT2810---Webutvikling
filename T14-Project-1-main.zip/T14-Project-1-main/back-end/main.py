import os
from typing import Optional

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv() #leser .env filen. Slipper å hardkode nøkkelen inn i python

POLET_API_KEY = os.getenv("POLET_API_KEY") #henter api key fra .env filen
PORT = int(os.getenv("PORT", "8000"))
ALLOWED_ORIGINS = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "").split(",") if o.strip()]

if not POLET_API_KEY:
    raise RuntimeError("POLET_API_KEY is not set. Put it in backend/.env")

app = FastAPI(title="Polet Proxy")

# CORS for your frontend origin(s)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS or ["http://localhost:5173"], #Dette er porten til Vite som nettsiden hostes på.
    allow_credentials=True,
    allow_methods=["GET"],
    allow_headers=["*"],
)

BASE_URL = "https://apis.vinmonopolet.no"

# Shared client with timeout
client = httpx.Client(timeout=httpx.Timeout(10.0, connect=5.0))

@app.get("/api/stores")
def get_stores(storeNameContains: str, page: Optional[int] = None, size: Optional[int] = None):
    """
    Proxy til Vinmonopolet Stores API.
    Eksempel: /api/stores?storeNameContains=ski
    """
    try:
        params = {"storeNameContains": storeNameContains}
        if page is not None:
            params["page"] = page
        if size is not None:
            params["size"] = size

        r = client.get(
            f"{BASE_URL}/stores/v0/details",
            params=params,
            headers={
                "Content-Type": "application/json",
                "Ocp-Apim-Subscription-Key": POLET_API_KEY,
            },
        )
        if r.status_code >= 400:
            raise HTTPException(status_code=r.status_code, detail=r.text)
        return r.json()
    except httpx.ReadTimeout:
        raise HTTPException(status_code=504, detail="Upstream timeout")
    except httpx.RequestError as e:
        raise HTTPException(status_code=502, detail=f"Upstream error: {e!s}")
