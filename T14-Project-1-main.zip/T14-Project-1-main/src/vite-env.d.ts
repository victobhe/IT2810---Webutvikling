/// <reference types="vite/client" />

// Optional: declare your env var for TS
interface ImportMetaEnv {
  readonly VITE_API_BASE?: string
}
interface ImportMeta {
  readonly env: ImportMetaEnv
}
