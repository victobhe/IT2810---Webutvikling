import { useCallback, useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import searchStores from "./components/api_call";
import Header from "./components/header";
import Card from "./components/card";
import useFavorites from "./hooks/useFavorites";
import "./App.css";
import { type Filters, type Choice } from "./components/HamburgerMeny";
import Logo from "./assets/PolPal.logo.png";
import Dropdown from "./components/dropdown";
import DropdownItem from "./components/dropdownItem";
import { type SortOption } from "./components/SortPopover";
import type { Store } from "./types/store";

type SizedChoice = Exclude<Choice, "Alle butikker">;

const sizeToCats: Record<SizedChoice, number[]> = {
  "Lite utvalg": [1, 2],
  "Middels utvalg": [3, 4],
  "Stort utvalg": [5, 6],
};

function sizeLabelFromCategory(cat: number | string | undefined) {
  const n = Number(cat);
  if (n === 1 || n === 2) return "liten";
  if (n === 3 || n === 4) return "medium";
  if (n === 5 || n === 6) return "stor";
  return "ukjent";
}

const SORT_STORAGE_KEY = "ss:sort-option";
const SORT_OPTIONS: SortOption[] = ["default", "name-asc", "name-desc", "size-desc", "size-asc"];
const nameCollator = new Intl.Collator("nb", { sensitivity: "base" });

function normalizeSortOption(value: unknown): SortOption {
  return SORT_OPTIONS.includes(value as SortOption) ? (value as SortOption) : "default";
}

function getCategoryValue(cat: number | string | undefined) {
  const n = Number(cat);
  return Number.isFinite(n) ? n : 99;
}

const statusTranslations: Record<string, string> = {
  open: "Åpen",
  closed: "Stengt",
  "closing soon": "Stenger snart",
  "opening soon": "Åpner snart",
  "temporarily closed": "Midlertidig stengt",
};

function translateStatus(status: string | undefined) {
  if (!status) return "";
  const normalized = status.toLowerCase();
  return statusTranslations[normalized] ?? status;
}

function storeMatchesFilters(
  store: Store,
  filterSet: Filters,
  favoriteChecker: (id: string) => boolean
) {
  if (filterSet.option1 && !favoriteChecker(store.storeId)) return false;
  if (filterSet.option2 && store.status?.toLowerCase() !== "open") return false;
  const choice = filterSet.Choice;
  if (choice !== "Alle butikker") {
    const cats = sizeToCats[choice];
    const catNum = Number(store.category);
    if (!cats.includes(catNum)) return false;
  }
  return true;
}


export default function App() {
  useEffect(() => {
  const handleKeyDown = (event: KeyboardEvent) => {
    if (event.key === "ArrowRight") {
      handleNextClick();
    } else if (event.key === "ArrowLeft") {
      handleLastClick();
    }
  };

  window.addEventListener("keydown", handleKeyDown);
  return () => window.removeEventListener("keydown", handleKeyDown);
}, [handleNextClick, handleLastClick]);

  const [query, setQuery] = useState<string>(() => {
    const saved = sessionStorage.getItem("ss:query") ?? "";
    const fallback = "Trondheim";
    return saved.trim() ? saved : fallback;
  });
  useEffect(() => {
    sessionStorage.setItem("ss:query", query);
  }, [query]);

  const [cachedResults, setCachedResults] = useState<Store[] | null>(() => {
    try {
      const raw = sessionStorage.getItem("ss:lastResults");
      return raw ? (JSON.parse(raw) as Store[]) : null;
    } catch {
      return null;
    }
  });
  // const lastSearch = sessionStorage.getItem("ss:lastSearch") ?? "";
  const [hasSearched, setHasSearched] = useState(() => query.trim().length > 0);

  const [filters, setFilters] = useState<Filters>({
    option1: false,
    option2: false,
    Choice: "Alle butikker",
  });
  const [sortOption, setSortOption] = useState<SortOption>(() => {
    if (typeof window === "undefined") return "default";
    try {
      const saved = sessionStorage.getItem(SORT_STORAGE_KEY);
      return normalizeSortOption(saved ?? "default");
    } catch {
      return "default";
    }
  });

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      sessionStorage.setItem(SORT_STORAGE_KEY, sortOption);
    } catch {
      // ignore storage errors
    }
  }, [sortOption]);

  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  const { isFavorite, toggleFavorite, favoritesArray } = useFavorites();

  const matchesFilterSet = useCallback(
    (store: Store, filterSet: Filters) => storeMatchesFilters(store, filterSet, isFavorite),
    [isFavorite]
  );

  const { data, error, isLoading, isFetching } = useQuery<Store[], Error>({
    queryKey: ["stores", query],
    queryFn: () => searchStores(query),
    enabled: hasSearched && query.trim().length > 0,
    staleTime: 60_000,
    retry: 1,
  });

  const sourceList = data ?? cachedResults ?? [];

  const canApplyFilters = useCallback(
    (candidate: Filters) => {
      if (!sourceList.length) return true;
      return sourceList.some((store) => matchesFilterSet(store, candidate));
    },
    [matchesFilterSet, sourceList]
  );

  const finalList = useMemo(() => {
    const baseList = showFavoritesOnly
      ? favoritesArray
      : sourceList.filter((s) => matchesFilterSet(s, filters));

    if (sortOption === "default") {
      return showFavoritesOnly ? [...baseList] : baseList;
    }

    const sorted = [...baseList];
    sorted.sort((a, b) => {
      const nameCompare = nameCollator.compare(a.storeName, b.storeName);
      const sizeCompare = getCategoryValue(a.category) - getCategoryValue(b.category);

      switch (sortOption) {
        case "name-asc":
          return nameCompare;
        case "name-desc":
          return -nameCompare;
        case "size-asc":
          return sizeCompare !== 0 ? sizeCompare : nameCompare;
        case "size-desc":
          return sizeCompare !== 0 ? -sizeCompare : nameCompare;
        default:
          return 0;
      }
    });
    return sorted;
  }, [showFavoritesOnly, favoritesArray, sourceList, filters, matchesFilterSet, sortOption]);

  useEffect(() => {
    if (!hasSearched || showFavoritesOnly || !data) return;
    try {
      sessionStorage.setItem("ss:lastResults", JSON.stringify(data));
      setCachedResults(data);
    } catch {
      // ignore storage error
    }
  }, [data, hasSearched, showFavoritesOnly]);

  const [cardIndex, setCardIndex] = useState(0);
  const hasNext = cardIndex < finalList.length - 1;

  function handleNextClick() {
    setCardIndex(hasNext ? cardIndex + 1 : 0);
  }

  function handleLastClick() {
    setCardIndex(cardIndex === 0 ? finalList.length - 1 : cardIndex - 1);
  }

  function handleToggleFavoritesView() {
    if (!favoritesArray.length && !showFavoritesOnly) {
      return;
    }
    setShowFavoritesOnly((prev) => !prev);
    setCardIndex(0);
  }

  let dropdownIndex = 0;
  const [open, setOpen ] = useState(false)

  const activeStore = finalList[cardIndex];
  const statusText = translateStatus(activeStore?.status);
  const cardContent = activeStore ? (
    <Card
      storeName={activeStore.storeName}
      address={activeStore.address?.street}
      city={activeStore.address?.city}
      type={<em>{sizeLabelFromCategory(activeStore.category)}</em>}
      open={statusText ? <strong>{statusText}</strong> : null}
      favoriteActive={isFavorite(activeStore.storeId)}
      favoriteToggle={() => toggleFavorite(activeStore)}
    />
  ) : null;

  return (
    <main>
      <Header
        title=""
        logo={Logo}
        onSearch={(q) => {
          const v = q.trim();
          setShowFavoritesOnly(false);
          setQuery(v);
          setHasSearched(v.length > 0);
          sessionStorage.setItem("ss:lastSearch", v);
        }}
        onFiltersChange={(f) => {
          setShowFavoritesOnly(false);
          setFilters(f);
        }}
        canApplyFilters={canApplyFilters}
        onSortChange={setSortOption}
        sortValue={sortOption}
        setIndex={setCardIndex}
        filterPopoverTargetId="filter-popover-root"
        onToggleFavoritesView={handleToggleFavoritesView}
        favoritesActive={showFavoritesOnly}
        favoriteCount={favoritesArray.length}
      />

      <Dropdown open={open} toggle={setOpen} count={finalList.length} content={
        <>
          {finalList.map((s) => (
            <DropdownItem key={s.storeId} onClick={setCardIndex} cardIndex={dropdownIndex++} toggle={setOpen}>
              {dropdownIndex} - {s.storeName} 
            </DropdownItem>
          ))}
        </>
      }/>

        <section className="search-results-wrapper">
          <div
            id="filter-popover-root"
            className="filter-popover-root"
            aria-hidden="true"
          />

        {/* HamburgerMeny styrer filtrene → varsler App via onChange */}
        {/* <HamburgerMeny onChange={setFilters} /> */}

        {isLoading && <div>Laster...</div>}
        {error && <div>Feil: {error.message}</div>}

        {!isLoading && !error && (
          <section aria-labelledby="butikker-heading">
            {isFetching && <small>Oppdaterer…</small>}

            <h1 id="butikker-heading">Butikker</h1>

            {finalList.length > 0 ? (
              <section
                id="card"
                aria-roledescription="carousel"
                aria-label="Butikkvisning"
              >
                <nav className="cardNavWrapper" aria-label="Bla gjennom butikker">
                  <button className="cardNav" onClick={handleLastClick}>
                    &lt;
                  </button>
                </nav>

                <article>
                  {cardContent}
                </article>

                <nav className="cardNavWrapper" aria-label="Bla gjennom butikker">
                  <button className="cardNav" onClick={handleNextClick} >
                    &gt;
                  </button>
                </nav>
              </section>
            ) : (
              <p>Ingen treff med valgte filtre.</p>
            )}
          </section>
        )}
      </section>
    </main>
  );
}
