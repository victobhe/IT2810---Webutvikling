import { http, HttpResponse } from 'msw'

// Match any origin -> avoids BASE issues (localhost, vite dev, etc.)
export const handlers = [
  http.get('*/api/stores', ({ request }) => {
    const url = new URL(request.url)
    const q = (url.searchParams.get('storeNameContains') || '').toLowerCase()
    const data = [
      { storeId: '1', storeName: 'Ski Vinmonopol',  address: { city: 'Ski' } },
      { storeId: '2', storeName: 'Oslo City',       address: { city: 'Oslo' } },
      { storeId: '3', storeName: 'Trondheim Torg',  address: { city: 'Trondheim' } },
    ].filter(s => s.storeName.toLowerCase().includes(q))
    return HttpResponse.json(data)
  }),
]
