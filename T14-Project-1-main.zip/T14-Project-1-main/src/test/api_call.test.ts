import { expect, test } from 'vitest'
import searchStores from '../components/api_call'

// Test to determine whether the api_call works as expected.

test('searchStores returns mocked results from MSW', async () => {
  const data = await searchStores('Ski')
  expect(Array.isArray(data)).toBe(true)
  expect(data.length).toBeGreaterThan(0)
  expect(data[0]).toHaveProperty('storeId')
  expect(data[0].storeName.toLowerCase()).toContain('ski')
})


