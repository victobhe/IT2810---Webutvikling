import { render, screen } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import App from '../App'

test('renders app shell (search input is visible)', () => {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })

  render(
    <QueryClientProvider client={qc}>
      <App />
    </QueryClientProvider>
  )

  // if your input has type="search"
  const search = screen.getByRole('searchbox')       // ✅ not 'textbox'
  expect(search).toBeInTheDocument()
  expect(search).toBeVisible()
})
