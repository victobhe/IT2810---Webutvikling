// FavoriteToggle button
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import FavoriteToggle from "../components/FavToggle";

test("calls onToggle when clicked", async () => {
  const onToggle = vi.fn();
  const user = userEvent.setup();

  render(<FavoriteToggle active={false} onToggle={onToggle} />);

  const btn = screen.getByRole("button", { name: /legg til i favoritter/i });
  expect(btn).toBeInTheDocument();


  await user.click(btn);
  expect(onToggle).toHaveBeenCalledTimes(1);
});
