import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, vi } from 'vitest'
import HamburgerMeny from '../components/HamburgerMeny'

function mountPopoverHost() {
  const host = document.createElement('div')
  host.id = 'filter-popover-root'
  document.body.appendChild(host)
  return host
}

afterEach(() => {
  const host = document.getElementById('filter-popover-root')
  host?.remove()
})

test('activating open-filter shows “Åpen” chip and triggers onChange', async () => {
  mountPopoverHost()
  const onChange = vi.fn()
  const user = userEvent.setup()

  render(<HamburgerMeny popoverTargetId="filter-popover-root" onChange={onChange} />)

  const filterButton = screen.getByRole('button', { name: /filter/i })
  await user.click(filterButton)

  const openCheckbox = await screen.findByRole('checkbox', { name: /åpne butikker/i })
  await user.click(openCheckbox)
  await user.click(screen.getByRole('button', { name: /bruk filtre/i }))

  expect(onChange).toHaveBeenCalledWith({
    option1: false,
    option2: true,
    Choice: 'Alle butikker',
  })
  expect(filterButton).toHaveTextContent(/1 aktive/i)

  // Reopen to verify chip label is localized
  await user.click(filterButton)
  expect(await screen.findByText('Åpen')).toBeInTheDocument()
})
