import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import App from '../App'

const createClient = () =>
  new QueryClient({ defaultOptions: { queries: { retry: false } } })

function renderApp() {
  // Fresh storage to keep state from leaking between runs
  sessionStorage.clear()
  localStorage.clear()

  const client = createClient()
  return render(
    <QueryClientProvider client={client}>
      <App />
    </QueryClientProvider>
  )
}

test('searching for a store shows results from the API', async () => {
  const user = userEvent.setup()
  renderApp()

  const input = screen.getByPlaceholderText(/søk på pol/i)
  await user.clear(input)
  await user.type(input, 'Ski')
  const searchButton = screen.getByRole('button', { name: /^søk$/i })
  await user.click(searchButton)

  // Heading should be present after search
  expect(await screen.findByRole('heading', { name: /butikker/i })).toBeVisible()
  // MSW handler returns Ski Vinmonopol when searching for "Ski"
  expect(
    await screen.findByText(/butikknavn:\s*vinmonopolet\s+ski vinmonopol/i)
  ).toBeInTheDocument()
})
