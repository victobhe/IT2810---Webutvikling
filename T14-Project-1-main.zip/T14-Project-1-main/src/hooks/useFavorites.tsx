import { useEffect, useMemo, useState } from "react";
import type { Store } from "../types/store";

const LEGACY_KEY = "favStoreIds";
const STORAGE_KEY = "favStores:v2";
type FavoriteMap = Record<string, Store>;

function readInitialFavorites(): FavoriteMap {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as FavoriteMap;
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        return parsed;
      }
    }

    const legacyRaw = localStorage.getItem(LEGACY_KEY);
    const legacyIds: string[] = legacyRaw ? JSON.parse(legacyRaw) : [];
    if (legacyIds.length) {
      return legacyIds.reduce<FavoriteMap>((acc, id) => {
        acc[id] = { storeId: id, storeName: "Favoritt" };
        return acc;
      }, {});
    }
  } catch {
    // ignore corrupted storage
  }
  return {};
}

export default function useFavorites() {
  const [favorites, setFavorites] = useState<FavoriteMap>(() => readInitialFavorites());

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(favorites));
    localStorage.removeItem(LEGACY_KEY);
  }, [favorites]);

  const isFavorite = (id: string) => Boolean(favorites[id]);

  const toggleFavorite = (store: Store) => {
    setFavorites((prev) => {
      if (prev[store.storeId]) {
        const { [store.storeId]: _removed, ...rest } = prev;
        return rest;
      }
      return {
        ...prev,
        [store.storeId]: {
          storeId: store.storeId,
          storeName: store.storeName,
          status: store.status,
          category: store.category,
          address: store.address,
        },
      };
    });
  };

  const clearFavorites = () => setFavorites({});

  const favoritesArray = useMemo(() => Object.values(favorites), [favorites]);

  return { isFavorite, toggleFavorite, clearFavorites, favoritesArray };
}

