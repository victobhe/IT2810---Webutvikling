export interface Store {
  storeId: string;
  storeName: string;
  status?: string;
  category?: number | string;
  address?: {
    street?: string;
    postalCode?: string;
    city?: string;
  };
}

