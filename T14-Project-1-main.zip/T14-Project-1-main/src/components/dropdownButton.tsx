import React from "react";
import "../styles/DropdownButton.css";

type DropdownButtonProps = {
  toggle: () => void;
  isOpen?: boolean;
  resultCount?: number;
};

const DropdownButton: React.FC<DropdownButtonProps> = ({ toggle, isOpen, resultCount = 0 }) => {
  const hasResults = resultCount > 0;

  return (
    <button
      type="button"
      className={`dropdown-btn${isOpen ? " dropdown-btn--open" : ""}`}
      onClick={toggle}
      aria-haspopup="listbox"
      aria-expanded={isOpen}
    >
      <div className="dropdown-btn__labels">
        <span className="dropdown-btn__eyebrow">Bla igjennom</span>
        <strong className="dropdown-btn__title">
          {hasResults ? `${resultCount} butikker funnet` : "Ingen treff ennå"}
        </strong>
        <p className="dropdown-btn__hint">
          {hasResults ? "Velg en butikk fra listen" : "Søk eller juster filter for å se listen"}
        </p>
      </div>
      <span className="dropdown-btn__chevron" aria-hidden="true">
        <svg width="18" height="18" viewBox="0 0 24 24" role="presentation">
          <path
            d="M6 9l6 6 6-6"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
    </button>
  );
};

export default DropdownButton;
