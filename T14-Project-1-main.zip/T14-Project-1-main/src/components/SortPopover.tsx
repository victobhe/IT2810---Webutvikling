import React, { useEffect, useId, useRef, useState } from "react";
import { createPortal } from "react-dom";
import "../Styles/hamburgerMeny.css";

export type SortOption = "default" | "name-asc" | "name-desc" | "size-desc" | "size-asc";

type SortPopoverProps = {
  value: SortOption;
  onChange?: (value: SortOption) => void;
  popoverTargetId?: string;
};

const sortChoices: Array<{
  value: SortOption;
  title: string;
  description: string;
  shortLabel: string;
}> = [
  {
    value: "default",
    title: "Standard rekkefølge",
    description: "Vis treffene i den rekkefølgen de ble hentet.",
    shortLabel: "Ingen sortering",
  },
  {
    value: "name-asc",
    title: "Navn A-Å",
    description: "Sorter alfabetisk fra A til Å.",
    shortLabel: "Navn A-Å",
  },
  {
    value: "name-desc",
    title: "Navn Å-A",
    description: "Sorter alfabetisk fra Å til A.",
    shortLabel: "Navn Å-A",
  },
  {
    value: "size-desc",
    title: "Størst vareutvalg",
    description: "Butikker med størst vareutvalg først.",
    shortLabel: "Størst først",
  },
  {
    value: "size-asc",
    title: "Minst vareutvalg",
    description: "Start med de minste butikkene.",
    shortLabel: "Minst først",
  },
];

const SortPopover: React.FC<SortPopoverProps> = ({
  value,
  onChange,
  popoverTargetId = "filter-popover-root",
}) => {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<SortOption>(value);

  const popoverId = useId();
  const wrapperRef = useRef<HTMLElement | null>(null);
  const popoverContentRef = useRef<HTMLElement | null>(null);
  const firstFocusableRef = useRef<HTMLInputElement | null>(null);
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const [popoverHost, setPopoverHost] = useState<HTMLElement | null>(null);
  const [overlayRoot, setOverlayRoot] = useState<HTMLElement | null>(null);

  useEffect(() => {
    if (typeof document === "undefined" || !popoverTargetId) {
      setPopoverHost(null);
      return;
    }
    setPopoverHost(document.getElementById(popoverTargetId));
  }, [popoverTargetId]);

  useEffect(() => {
    if (typeof document === "undefined") return;
    setOverlayRoot(document.body);
  }, []);

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (!open) return;
      const target = e.target as Node;
      const insideTrigger = wrapperRef.current?.contains(target);
      const insidePopover = popoverContentRef.current?.contains(target);
      if (insideTrigger || insidePopover) return;
      setOpen(false);
    }
    function onEsc(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("click", onDocClick);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("click", onDocClick);
      document.removeEventListener("keydown", onEsc);
    };
  }, [open]);

  useEffect(() => {
    if (open) {
      setDraft(value);
      firstFocusableRef.current?.focus();
    } else {
      buttonRef.current?.focus();
    }
  }, [open, value]);

  const currentChoice =
    sortChoices.find((choice) => choice.value === value) ?? sortChoices[0];
  const draftChoice =
    sortChoices.find((choice) => choice.value === draft) ?? sortChoices[0];
  const statusLabel = currentChoice.shortLabel;
  const isActive = value !== "default";

  function toggleOpen() {
    setOpen((prev) => !prev);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    onChange?.(draft);
    setOpen(false);
  }

  function handleClear() {
    setDraft("default");
  }

  const popover = (
    <section
      id={popoverId}
      role="dialog"
      aria-label="Sorter treffene"
      aria-modal="false"
      className={`filter-popover${popoverHost ? " overlay-popover" : ""}`}
      ref={(node) => {
        popoverContentRef.current = node;
      }}
    >
      <header className="filter-popover__header">
        <div>
          <h2>Bestem rekkefølgen</h2>
          <p className="filter-popover__subhead">
            Velg hvordan butikkene skal listes
          </p>
        </div>
        <button
          type="button"
          className="filter-popover__close"
          onClick={() => setOpen(false)}
          aria-label="Lukk sortering"
        >
          &times;
        </button>
      </header>

      <div className="filter-popover__badges" aria-live="polite">
        <span className="filter-popover__badge filter-popover__badge--muted">
          {currentChoice.shortLabel}
        </span>
      </div>

      <form onSubmit={handleSubmit}>
        <fieldset className="filter-fieldset">
          <legend className="visually-hidden">Velg sortering</legend>
          <section className="filter-group">
            <header>
              <h3>Sortering av treff</h3>
              <p>Endre rekkefølgen uten å påvirke filtrene.</p>
            </header>

            {sortChoices.map((choice, index) => (
              <label
                key={choice.value}
                className="checkbox-item filter-card"
              >
                <input
                  ref={index === 0 ? firstFocusableRef : null}
                  type="radio"
                  name="sort-option"
                  value={choice.value}
                  checked={draft === choice.value}
                  onChange={() => setDraft(choice.value)}
                />
                <div>
                  <strong>{choice.title}</strong>
                  <p>{choice.description}</p>
                </div>
              </label>
            ))}
          </section>
        </fieldset>

        <section className="filter-actions" aria-label="Sorteringshandlinger">
          <p className="filter-actions__summary">
            {draft === "default"
              ? "Ingen sortering valgt"
              : `Viser ${draftChoice.shortLabel.toLowerCase()}`}
          </p>
          <div className="filter-actions__buttons">
            <button type="submit" className="btn primary">
              Bruk sortering
            </button>
            {/* <button
              type="button"
              className="btn ghost"
              onClick={() => setOpen(false)}
            >
              Lukk
            </button> */}
            <button
              type="button"
              className="btn linklike"
              onClick={handleClear}
            >
              Nullstill
            </button>
          </div>
        </section>
      </form>
    </section>
  );

  return (
    <section className="filter-container" ref={wrapperRef} aria-label="Sorter">
      <button
        ref={buttonRef}
        type="button"
        className={`btn filter-btn${isActive ? " filter-btn--active" : ""}`}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={popoverId}
        onClick={toggleOpen}
      >
        <span className="filter-btn__icon" aria-hidden="true">
          <svg width="20" height="20" viewBox="0 0 24 24" focusable="false">
            <path
              d="M6 7h12M6 12h8M6 17h4"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>
        </span>
        <span className="filter-btn__text">
          <span className="filter-btn__label">Sorter</span>
          <span className="filter-btn__status">{statusLabel}</span>
        </span>
      </button>

      {open && overlayRoot
        ? createPortal(
            <div className="filter-backdrop" onClick={() => setOpen(false)} />,
            overlayRoot
          )
        : null}

      {open && popoverHost ? createPortal(popover, popoverHost) : open && popover}
    </section>
  );
};

export default SortPopover;
