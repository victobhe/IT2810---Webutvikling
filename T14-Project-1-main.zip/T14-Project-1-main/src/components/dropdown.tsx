import React, { useEffect, useRef, type Dispatch, type SetStateAction } from "react";
import DropdownButton from "./dropdownButton";
import DropdownContent from "./dropdownContent";

type DropdownProps = {
  content: React.ReactNode;
  open: boolean;
  toggle: Dispatch<SetStateAction<boolean>>;
  count?: number;
};

const Dropdown: React.FC<DropdownProps> = ({ content, open, toggle, count = 0 }) => {
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    function onDocClick(event: MouseEvent) {
      if (!dropdownRef.current) return;
      if (!dropdownRef.current.contains(event.target as Node)) {
        toggle(false);
      }
    }

    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, [toggle]);

  const toggleDropdown = () => toggle((prev) => !prev);

  return (
    <section className="dropdown-shell" ref={dropdownRef} aria-label="Bla gjennom butikker">
      <DropdownButton toggle={toggleDropdown} isOpen={open} resultCount={count} />
      <DropdownContent content={content} open={open} count={count} onClose={() => toggle(false)} />
    </section>
  );
};

export default Dropdown;
