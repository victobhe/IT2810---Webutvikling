import React from "react";

// Restrict possible values to your three categories
type Size = "liten" | "medium" | "stor" | ""; // "" = Alle

interface SizeFilterProps {
  value: Size;
  onChange: (value: Size) => void;
}

const SizeFilter: React.FC<SizeFilterProps> = ({ value, onChange }) => {
  return (
    <div>
      <label htmlFor="size-filter">Velg størrelse: </label>
      <select
        id="size-filter"
        value={value}
        onChange={(e) => onChange(e.target.value as Size)}
      >
        <option value="">Alle</option>
        <option value="liten">Liten</option>
        <option value="medium">Medium</option>
        <option value="stor">Stor</option>
      </select>
    </div>
  );
};

export default SizeFilter;
