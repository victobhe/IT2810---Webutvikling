import React from "react";
import "../Styles/card.css";

type FavoriteToggleProps = {
  active: boolean;
  onToggle: () => void;
};

const FavoriteToggle: React.FC<FavoriteToggleProps> = ({ active, onToggle }) => {
  const label = active ? "Fjern fra favoritter" : "Legg til i favoritter";
  const icon = active ? "★" : "☆";

  return (
    <button
      type="button"
      className="star-button"
      aria-label={label}
      title={label}
      onClick={onToggle}
    >
      {icon}
    </button>
  );
};

export default FavoriteToggle;
