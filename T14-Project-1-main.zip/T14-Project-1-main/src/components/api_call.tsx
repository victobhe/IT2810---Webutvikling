export async function searchStores(query: string) {
  // Rydd opp base – ignorer tomme verdier og placeholders
  const raw = (import.meta.env.VITE_API_BASE ?? '').trim();
  const base =
    !raw || raw.includes('<real-api-host>') ? '' : raw.replace(/\/+$/, '');

  const url = `${base}/api/stores?storeNameContains=${encodeURIComponent(query)}`;
  console.log("Ny build kjører")
  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error(`Proxy error: ${res.status}`);
  return res.json();
}

export default searchStores;