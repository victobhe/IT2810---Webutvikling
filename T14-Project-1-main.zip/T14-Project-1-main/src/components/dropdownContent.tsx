import React from "react";
import "../Styles/DropdownContent.css";

type DropdownContentProps = {
  content: React.ReactNode;
  open: boolean;
  count?: number;
  onClose?: () => void;
  emptyMessage?: string;
};

const DropdownContent: React.FC<DropdownContentProps> = ({
  content,
  open,
  count = 0,
  onClose,
  emptyMessage = "Ingen butikker å vise enda. Prøv et søk eller oppdater filtrene.",
}) => {
  const hasContent = count > 0;

  return (
    <section
      className={`dropdown-content${open ? " content-open" : ""}`}
      role="dialog"
      aria-modal="false"
      aria-hidden={!open}
    >
      <header className="dropdown-panel__header">
        <div>
          {/* <p className="dropdown-panel__eyebrow">Butikker</p> */}
          <h3>
            {hasContent
              ? `Velg blant ${count} ${count === 1 ? "butikk" : "butikker"}`
              : "Ingen treff å bla gjennom"}
          </h3>
          <p>
            {hasContent
              ? "Klikk på en butikk for å hoppe direkte til kortet."
              : emptyMessage}
          </p>
        </div>
        <button
          type="button"
          className="dropdown-panel__close"
          onClick={onClose}
          aria-label="Lukk liste"
        >
          &times;
        </button>
      </header>

      <div className="dropdown-panel__body" role="listbox">
        {hasContent ? (
          content
        ) : (
          <p className="dropdown-panel__empty">{emptyMessage}</p>
        )}
      </div>
    </section>
  );
};

export default DropdownContent;
