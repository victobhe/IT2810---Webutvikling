import React from "react";

type FooterProps = {
  title: string;
  subtitle?: string;
};

export const footer: React.FC<FooterProps> = ({ title, subtitle }) => {
  return (
    <footer>
      <h1>{title}</h1>
      {subtitle && <p>{subtitle}</p>}
    </footer>
  );
};

export default footer;