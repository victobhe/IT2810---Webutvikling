import React from "react";
import FavoriteToggle from "./FavToggle";
import "../Styles/card.css";

type CardProps = {
  storeName: string;
  address?: string;
  city?: string;
  type?: React.ReactNode;
  open: React.ReactNode;
  favoriteActive: boolean;
  favoriteToggle: () => void;
};

const Card: React.FC<CardProps> = ({
  storeName,
  address,
  city,
  type,
  open,
  favoriteActive,
  favoriteToggle,
}) => {
  return (
    <div className="card">
      <div className="card-header">
        <p>Butikknavn: Vinmonopolet {storeName}</p>
        <FavoriteToggle active={favoriteActive} onToggle={favoriteToggle} />
      </div>
      <div className="card-body">
        <p>Adresse: {address}</p>
        <p>By: {city}</p>
        <p>Størrelse: {type}</p>
        <p>Åpen?: {open}</p>
      </div>
    </div>
  );
};

export default Card;
