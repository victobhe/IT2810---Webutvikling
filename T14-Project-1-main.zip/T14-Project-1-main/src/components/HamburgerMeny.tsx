import React, { useEffect, useId, useRef, useState } from "react";
import { createPortal } from "react-dom";
import "../Styles/hamburgerMeny.css";

export type Choice = "Alle butikker" | "Lite utvalg" | "Middels utvalg" | "Stort utvalg";

export type Filters = {
  option1: boolean; // Favoritt
  option2: boolean; // Open
  Choice: Choice;
};

type ActiveChip = {
  id: string;
  label: string;
  onRemove: () => void;
};

export type HamburgerMenyProps = {
  onChange?: (filters: Filters) => void;
  popoverTargetId?: string;
  canApplyFilters?: (filters: Filters) => boolean;
};

const STORAGE_KEY = "filters";

function normalizeChoice(v: unknown): Choice {
  const s = String(v ?? "").toLowerCase().trim();
  if (s === "lite utvalg") return "Lite utvalg";
  if (s === "middels utvalg" || s === "medium utvalg") return "Middels utvalg";
  if (s === "stort utvalg") return "Stort utvalg";
  return "Alle butikker";
}

const HamburgerMeny: React.FC<HamburgerMenyProps> = ({
  onChange,
  popoverTargetId = "filter-popover-root",
  canApplyFilters,
}) => {
  const [open, setOpen] = useState(false);

  const [filters, setFilters] = useState<Filters>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      const parsed: (Partial<Filters> & { Enabled?: boolean }) | null = saved ? JSON.parse(saved) : null;
      const storedChoice = normalizeChoice(parsed?.Choice);
      const shouldDisableChoice = parsed?.Enabled === false;
      return {
        option1: parsed?.option1 ?? false,
        option2: parsed?.option2 ?? false,
        Choice: shouldDisableChoice ? "Alle butikker" : storedChoice,
      };
    } catch {
      return {
        option1: false,
        option2: false,
        Choice: "Alle butikker",
      };
    }
  });

  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filters));
  }, [filters]);

  const popoverId = useId();
  const wrapperRef = useRef<HTMLElement | null>(null);
  const popoverContentRef = useRef<HTMLElement | null>(null);
  const firstFocusableRef = useRef<HTMLInputElement | null>(null);
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const [popoverHost, setPopoverHost] = useState<HTMLElement | null>(null);
  const [overlayRoot, setOverlayRoot] = useState<HTMLElement | null>(null);

  useEffect(() => {
    if (typeof document === "undefined" || !popoverTargetId) {
      setPopoverHost(null);
      return;
    }
    setPopoverHost(document.getElementById(popoverTargetId));
  }, [popoverTargetId]);

  useEffect(() => {
    if (typeof document === "undefined") return;
    setOverlayRoot(document.body);
  }, []);

  // close when clicking outside or ESC
  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (!open) return;
      const target = e.target as Node;
      const insideTrigger = wrapperRef.current?.contains(target);
      const insidePopover = popoverContentRef.current?.contains(target);
      if (insideTrigger || insidePopover) return;
      setOpen(false);
    }
    function onEsc(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("click", onDocClick);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("click", onDocClick);
      document.removeEventListener("keydown", onEsc);
    };
  }, [open]);

  // Focus-handling
  useEffect(() => {
    if (open) firstFocusableRef.current?.focus();
    else buttonRef.current?.focus();
  }, [open]);

  const activeChips = [
    filters.option1 && {
      id: "favorite",
      label: "Favoritt",
      onRemove: () => setFilters((f) => ({ ...f, option1: false })),
    },
    filters.option2 && {
      id: "open",
      label: "Åpen",
      onRemove: () => setFilters((f) => ({ ...f, option2: false })),
    },
    filters.Choice !== "Alle butikker" && {
      id: "assortment",
      label: filters.Choice,
      onRemove: () => setFilters((f) => ({ ...f, Choice: "Alle butikker" })),
    },
  ].filter(Boolean) as ActiveChip[];

  const activeBadges = activeChips.map((chip) => chip.label);
  const activeCount = activeBadges.length;
  const canApplyCurrentFilters = canApplyFilters ? canApplyFilters(filters) : true;

  function toggle() {
    setOpen((v) => !v);
  }

  function apply(e: React.FormEvent) {
    e.preventDefault();
    if (!canApplyCurrentFilters) {
      setErrorMessage("Ingen butikker matcher disse filtrene. Juster valgene dine.");
      return;
    }
    onChange?.(filters);
    setOpen(false);
  }

  useEffect(() => {
    if (canApplyCurrentFilters) {
      setErrorMessage("");
    }
  }, [canApplyCurrentFilters]);

  function clearAll() {
    setFilters({
      option1: false,
      option2: false,
      Choice: "Alle butikker",
    });
  }

  const popover = (
    <section
      id={popoverId}
      role="dialog"
      aria-label="Filtervalg"
      aria-modal="false"
      className={`filter-popover${popoverHost ? " overlay-popover" : ""}`}
      ref={(node) => {
        popoverContentRef.current = node;
      }}
    >
      <header className="filter-popover__header">
        <div>
          <h2>Finjuster treffene</h2>
          <p className="filter-popover__subhead">
            Kombiner favoritter, åpne butikker og størrelsen på vareutvalget før du blar videre.
          </p>
        </div>
        <button
          type="button"
          className="filter-popover__close"
          onClick={() => setOpen(false)}
          aria-label="Lukk filter"
        >
          ×
        </button>
      </header>

      <section className="filter-popover__badges" aria-live="polite">
        {activeChips.length ? (
          activeChips.map((chip) => (
            <div key={chip.id} className="filter-popover__badge">
              <span>{chip.label}</span>
              <button
                type="button"
                className="badge-close-btn"
                aria-label={`Fjern ${chip.label}`}
                onClick={(event) => {
                  event.stopPropagation();
                  chip.onRemove();
                }}
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
          ))
        ) : (
          <span className="filter-popover__badge filter-popover__badge--muted">
            Ingen aktive filtre
          </span>
        )}
      </section>

      <form onSubmit={apply}>
        <fieldset className="filter-fieldset">
          <legend className="visually-hidden">Velg filtre</legend>

          <section className="filter-group">
            <header>
              <h3>Hurtigvalg</h3>
              <p>Marker favoritter og finn åpne butikker først.</p>
            </header>

            <label className="checkbox-item filter-card">
              <input
                ref={firstFocusableRef}
                type="checkbox"
                checked={filters.option1}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, option1: e.target.checked }))
                }
              />
              <div>
                <strong>Favoritter</strong>
                <p>Vis bare pol du har merket som favoritt.</p>
              </div>
            </label>

            <label className="checkbox-item filter-card">
              <input
                type="checkbox"
                checked={filters.option2}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, option2: e.target.checked }))
                }
              />
              <div>
                <strong>Åpne butikker</strong>
                <p>Skip køen og få kun de som er åpne nå.</p>
              </div>
            </label>
          </section>

          {/* "Vareutvalg" with dropdown menu */}
          <div className="filter-divider" role="presentation">
            <span>Vareutvalg</span>
          </div>
          <section className="filter-group">
            <header>
              <h3>Størrelse på vareutvalg</h3>
              <p>Velg butikkstørrelse for å begrense treff eller behold alle butikker.</p>
            </header>

            <label className="select-row filter-card filter-card--select">
              <span className="select-label">Velg type</span>
              <select
                value={filters.Choice}
                onChange={(e) =>
                  setFilters((f) => ({
                    ...f,
                    Choice: e.target.value as Choice,
                  }))
                }
              >
                <option value="Alle butikker">Alle butikker</option>
                <option value="Lite utvalg">Lite utvalg</option>
                <option value="Middels utvalg">Middels utvalg</option>
                <option value="Stort utvalg">Stort utvalg</option>
              </select>
            </label>
          </section>
        </fieldset>

        <section className="filter-actions" aria-label="Filter handlinger">
          <p
            className={`filter-actions__summary${
              !canApplyCurrentFilters ? " filter-actions__summary--error" : ""
            }`}
          >
            {!canApplyCurrentFilters
              ? "Ingen butikker matcher disse filtrene."
              : activeBadges.length > 0
              ? `${activeBadges.length} aktive ${
                  activeBadges.length === 1 ? "filter" : "filtre"
                }`
              : "Ingen aktive filtre"}
          </p>
          {errorMessage && (
            <p className="filter-actions__error" role="alert">
              {errorMessage}
            </p>
          )}
          <div className="filter-actions__buttons">
            <button
              type="submit"
              className="btn primary"
              disabled={!canApplyCurrentFilters}
            >
              Bruk filtre
            </button>
            {/* <button type="button" className="btn ghost" onClick={() => setOpen(false)}>
              Ferdig
            </button> */}
            <button type="button" className="btn linklike" onClick={clearAll}>
              Nullstill alt
            </button>
          </div>
        </section>
      </form>
    </section>
  );

  return (
    <section className="filter-container" ref={wrapperRef} aria-label="Filter">
      <button
        ref={buttonRef}
        type="button"
        className={`btn filter-btn${activeCount ? " filter-btn--active" : ""}`}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={popoverId}
        onClick={toggle}
      >
        <span className="filter-btn__icon" aria-hidden="true">
          <svg width="18" height="18" viewBox="0 0 24 24" focusable="false">
            <path
              d="M4 5h16l-6 7v5l-4 2v-7L4 5z"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
        <span className="filter-btn__text">
          <span className="filter-btn__label">Filter</span>
          <span className="filter-btn__status">
            {activeCount > 0 ? `${activeCount} aktive` : "Ingen filtre"}
          </span>
        </span>
      </button>

      {open && overlayRoot
        ? createPortal(
            <div className="filter-backdrop" onClick={() => setOpen(false)} />,
            overlayRoot
          )
        : null}

      {open && popoverHost
        ? createPortal(popover, popoverHost)
        : open && popover}
    </section>
  );
};

export default HamburgerMeny;
