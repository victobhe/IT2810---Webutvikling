import React, { useEffect, useState } from "react";
import "../Styles/header.css";
import HamburgerMeny, { type Filters } from "../components/HamburgerMeny";
import SortPopover, { type SortOption } from "./SortPopover";

const logoSrc = `${import.meta.env.BASE_URL}PolPal.logo.png`;

interface HeaderProps {
  title?: string;
  logo?: string;
  onSearch?: (query: string) => void;
  onFiltersChange?: (filters: Filters) => void;
  canApplyFilters?: (filters: Filters) => boolean;
  onSortChange?: (value: SortOption) => void;
  sortValue?: SortOption;
  setIndex: (index: number) => void;
  filterPopoverTargetId?: string;
  onToggleFavoritesView?: () => void;
  favoritesActive?: boolean;
  favoriteCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  title = "Søk",
  logo,
  onSearch,
  onFiltersChange,
  canApplyFilters,
  onSortChange,
  sortValue = "default",
  setIndex,
  filterPopoverTargetId,
  onToggleFavoritesView,
  favoritesActive = false,
  favoriteCount = 0,
}) => {
  const [query, setQuery] = useState("");

  useEffect(() => {
    sessionStorage.setItem("ss:query", query);
  }, [query]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formattedQuery = query.replace(/\s+/g, "_");
    onSearch?.(formattedQuery);
    setIndex(0);
  };

  const favoritesDisabled =
    (!favoriteCount && !favoritesActive) || !onToggleFavoritesView;

  return (
    <header className="header">
      <section className="header-top">
        {logo && <img src={logoSrc} alt={`${title} logo`} className="logo" />}
        <h1>{title}</h1>
      </section>

      <section className="search-and-filter">
        <form className="search-form" onSubmit={handleSubmit} role="search">
          <fieldset className="search-row">
            <legend className="visually-hidden">Søk</legend>
            <label htmlFor="search-input" className="visually-hidden">
              Søk på Pol
            </label>
            <input
              id="search-input"
              type="search"
              placeholder="Søk på Pol..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="search-input"
            />
            <button type="submit" className="search-button">
              Søk
            </button>
          </fieldset>
        </form>

        <div className="filter-controls">
          <section className="filter-container" aria-label="Favoritter">
            <button
              type="button"
              className={`btn filter-btn${
                favoritesActive ? " filter-btn--active" : ""
              }`}
              onClick={() => onToggleFavoritesView?.()}
              aria-pressed={favoritesActive}
              disabled={favoritesDisabled}
            >
              <span className="filter-btn__icon filter-btn__icon--star" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" focusable="false">
                  <path
                    d="M12 3.5l2.35 4.76 5.26.77-3.8 3.74.9 5.24L12 15.9 7.29 18.01l.9-5.24-3.8-3.74 5.26-.77z"
                    fill="currentColor"
                  />
                </svg>
              </span>
              <span className="filter-btn__text">
                <span className="filter-btn__label">Favoritter</span>
                <span className="filter-btn__status">
                  {favoritesActive
                    ? "Viser favoritter"
                    : favoriteCount > 0
                    ? `${favoriteCount} lagret`
                    : "Ingen favoritter"}
                </span>
              </span>
            </button>
          </section>

          <HamburgerMeny
            popoverTargetId={filterPopoverTargetId}
            canApplyFilters={canApplyFilters}
            onChange={(filters) => {
              onFiltersChange?.(filters);
              onSearch?.(query.trim());
              setIndex(0);
            }}
          />

          <SortPopover
            popoverTargetId={filterPopoverTargetId}
            value={sortValue}
            onChange={(value) => {
              onSortChange?.(value);
              setIndex(0);
            }}
          />
        </div>
      </section>
    </header>
  );
};

export default Header;
