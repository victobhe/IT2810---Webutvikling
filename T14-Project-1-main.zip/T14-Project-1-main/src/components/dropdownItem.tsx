import React, { type Dispatch, type SetStateAction } from 'react'
import '../Styles/DropdownItem.css'

type dropdownItemProps = {
  children: any;
  onClick: (index: number) => void;
  cardIndex: number;
  toggle: Dispatch<SetStateAction<boolean>>;
}

const DropdownItem: React.FC<dropdownItemProps> = ({ children, onClick, cardIndex, toggle }) => {
  
  const handleClick = () => {
    onClick(cardIndex);
    toggle(false);
  }
  
  return (
    <button className='dropdown-item' type="button" onClick={handleClick} role="option">
      {children}
    </button>
  )
}

export default DropdownItem
