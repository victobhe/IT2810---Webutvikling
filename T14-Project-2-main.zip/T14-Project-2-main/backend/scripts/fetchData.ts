import "dotenv/config";
import { MongoClient } from "mongodb";
import sharp from "sharp";
import fetch from "node-fetch";
import fs from "fs/promises";
import path from "path";

const API_URL = "https://www.themealdb.com/api/json/v1/1/search.php?s=";
const UPLOADS_DIR =
  process.env.UPLOADS_DIR ??
  path.join(process.cwd(), "backend", "public", "uploads");

const uri = process.env.MONGO_URI ?? "mongodb://localho st:27017";
const dbName = process.env.MONGO_DB ?? "project2";

type ImageFormat = "jpg" | "webp";
type VariantDescriptor = {
  format: ImageFormat;
  width: number;
  url: string;
};

type Meal = {
  idMeal: string;
  strMeal: string;
  strCategory: string | null;
  strInstructions: string | null;
  strMealThumb: string | null;
};

type SeedDishDoc = {
  _id: string;
};

async function downloadBuffer(url: string): Promise<Buffer> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to download image: ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

async function buildVariants(
  buf: Buffer,
  id: string,
): Promise<VariantDescriptor[]> {
  const dishDir = path.join(UPLOADS_DIR, id);
  await fs.mkdir(dishDir, { recursive: true });

  const sizes = [400, 800, 1200];
  const formats: Array<"jpeg" | "webp"> = ["jpeg", "webp"];

  const variants: VariantDescriptor[] = [];
  for (const w of sizes) {
    for (const fmt of formats) {
      const ext: ImageFormat = fmt === "jpeg" ? "jpg" : "webp";
      const filename = `${id}_${w}.${ext}`;
      const outPath = path.join(dishDir, filename);
      await sharp(buf)
        .resize({ width: w })
        .toFormat(fmt, { quality: 80 })
        .toFile(outPath);

      variants.push({
        format: ext,
        width: w,
        url: `/uploads/${id}/${filename}`,
      });
    }
  }
  return variants;
}

async function main() {
  const client = new MongoClient(uri);
  await client.connect();
  const db = client.db(dbName);
  const col = db.collection<SeedDishDoc>("dishes");

  await col.createIndexes([
    { key: { title: "text", instructions: "text", category: "text" } },
    { key: { createdAt: -1, _id: 1 } },
  ]);

  const res = await fetch(API_URL);
  const data = (await res.json()) as { meals?: Meal[] };

  for (const meal of data.meals ?? []) {
    const id = meal.idMeal;
    const title = meal.strMeal;
    const category = meal.strCategory ?? null;
    const instructions = meal.strInstructions ?? null;
    const imgUrl = meal.strMealThumb;

    let variants: VariantDescriptor[] = [];
    if (imgUrl) {
      try {
        const buf = await downloadBuffer(imgUrl);
        variants = await buildVariants(buf, id);
      } catch (e) {
        console.warn("Bilde feilet for", id, e);
      }
    }

    await col.updateOne(
      { _id: id },
      {
        $set: {
          title,
          category,
          instructions,
          timeMinutes: null,
          image: { alt: title, variants },
          createdAt: new Date(),
        },
      },
      { upsert: true },
    );

    console.log("✅", title);
  }

  await client.close();
  console.log("Ferdig seed!");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
