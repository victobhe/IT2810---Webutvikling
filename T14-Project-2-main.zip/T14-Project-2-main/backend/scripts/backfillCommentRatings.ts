import "dotenv/config";
import { Collection, MongoClient, ObjectId } from "mongodb";

type CommentDoc = {
  _id: ObjectId;
  recipeId: string;
  userId: ObjectId;
};

type RatingDoc = {
  recipeId: string;
  userId: ObjectId;
  value: number;
};

const DEFAULT_URI = "mongodb://localhost:27017";
const DEFAULT_DB = "project2";
const BATCH_SIZE = 250;

const processBatch = async (
  docs: CommentDoc[],
  ratingsCol: Collection<RatingDoc>,
  commentsCol: Collection<CommentDoc>,
) => {
  if (docs.length === 0) return 0;
  const recipeIds = Array.from(new Set(docs.map((doc) => doc.recipeId)));
  const userIds = Array.from(
    new Set(docs.map((doc) => doc.userId.toHexString())),
  ).map((id) => new ObjectId(id));
  const ratingDocs = await ratingsCol
    .find({ recipeId: { $in: recipeIds }, userId: { $in: userIds } })
    .toArray();
  const ratingMap = new Map(
    ratingDocs.map((rating) => [
      `${rating.recipeId}:${rating.userId.toHexString()}`,
      rating.value,
    ]),
  );
  const operations = docs.map((doc) => {
    const key = `${doc.recipeId}:${doc.userId.toHexString()}`;
    const rating = ratingMap.get(key) ?? null;
    return {
      updateOne: {
        filter: { _id: doc._id },
        update: { $set: { rating } },
      },
    };
  });
  if (operations.length === 0) {
    return 0;
  }
  await commentsCol.bulkWrite(operations, { ordered: false });
  return operations.length;
};

async function main() {
  const uri = process.env.MONGO_URI ?? DEFAULT_URI;
  const dbName = process.env.MONGO_DB ?? DEFAULT_DB;

  const client = new MongoClient(uri);
  await client.connect();
  const db = client.db(dbName);
  const commentsCol = db.collection<CommentDoc>("comments");
  const ratingsCol = db.collection<RatingDoc>("ratings");

  const cursor = commentsCol.find(
    { rating: { $exists: false } },
    { projection: { recipeId: 1, userId: 1 } },
  );
  let total = 0;
  let batch: CommentDoc[] = [];

  while (await cursor.hasNext()) {
    const doc = await cursor.next();
    if (!doc) continue;
    batch.push(doc);
    if (batch.length >= BATCH_SIZE) {
      total += await processBatch(batch, ratingsCol, commentsCol);
      batch = [];
    }
  }

  if (batch.length > 0) {
    total += await processBatch(batch, ratingsCol, commentsCol);
  }

  console.log(`Updated ${total} comments with rating snapshots.`);
  await client.close();
}

main().catch((err) => {
  console.error("Failed to backfill comment ratings", err);
  process.exit(1);
});
