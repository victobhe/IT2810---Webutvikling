import { MongoMemoryServer } from "mongodb-memory-server";
import { MongoClient, ObjectId, type Db } from "mongodb";
import {
  describe,
  it,
  beforeAll,
  afterAll,
  beforeEach,
  expect,
  vi,
} from "vitest";
import type { Request, Response } from "express";
import { resolvers, createCommentsLoader, type Ctx } from "../src/resolvers.ts";

const TEST_USER_ID = new ObjectId("507f1f77bcf86cd799439011");
const TEST_RECIPE_ID = "dish-1";

const makeCtx = (db: Db, user: Ctx["user"] = null): Ctx => {
  const res = { cookie: vi.fn() } as unknown as Response;
  return {
    db,
    req: {} as Request,
    res,
    user,
    commentsLoader: createCommentsLoader(db),
  };
};

describe("resolvers integration (GraphQL mutations)", () => {
  let mongo: MongoMemoryServer;
  let client: MongoClient;
  let db: Db;

  beforeAll(async () => {
    process.env.JWT_SECRET = "test-secret";
    mongo = await MongoMemoryServer.create();
    client = await MongoClient.connect(mongo.getUri(), {});
    db = client.db("project2-test");
  });

  afterAll(async () => {
    await client.close();
    await mongo.stop();
  });

  beforeEach(async () => {
    await db.dropDatabase();
    await db.collection("dishes").insertOne({
      _id: new ObjectId("64a1f7d2c5e4a13b2c4e9f01"),
      idMeal: TEST_RECIPE_ID,
      title: "Test Dish",
      createdAt: new Date(),
    });
  });

  it("validates signup input and sets a session cookie", async () => {
    const ctx = makeCtx(db);
    await expect(
      resolvers.Mutation.signup!(
        {},
        { email: "not-an-email", password: "123456" },
        ctx,
      ),
    ).rejects.toThrow(/invalid email/i);

    const result = await resolvers.Mutation.signup!(
      {},
      { email: "cook@example.com", password: "123456", name: "Cook" },
      ctx,
    );

    expect(result.user.email).toBe("cook@example.com");
    expect(ctx.res.cookie).toHaveBeenCalledWith(
      expect.stringContaining("auth"),
      expect.any(String),
      expect.any(Object),
    );
  });

  it("requires auth and an existing recipe when rating", async () => {
    const unauthCtx = makeCtx(db, null);
    await expect(
      resolvers.Mutation.rateRecipe!(
        {},
        { recipeId: TEST_RECIPE_ID, value: 5 },
        unauthCtx,
      ),
    ).rejects.toThrow(/authentication required/i);

    const authCtx = makeCtx(db, {
      id: TEST_USER_ID.toString(),
      email: "user@example.com",
      name: "User",
    });
    await expect(
      resolvers.Mutation.rateRecipe!(
        {},
        { recipeId: TEST_RECIPE_ID, value: 0 },
        authCtx,
      ),
    ).rejects.toThrow(/between 1 and 5/i);

    await expect(
      resolvers.Mutation.rateRecipe!(
        {},
        { recipeId: "missing", value: 4 },
        authCtx,
      ),
    ).rejects.toThrow(/recipe not found/i);
  });

  it("upserts ratings to keep a single user value", async () => {
    const ctx = makeCtx(db, {
      id: TEST_USER_ID.toString(),
      email: "user@example.com",
      name: "User",
    });

    const first = await resolvers.Mutation.rateRecipe!(
      {},
      { recipeId: TEST_RECIPE_ID, value: 3 },
      ctx,
    );
    expect(first.average).toBe(3);
    expect(first.count).toBe(1);

    const updated = await resolvers.Mutation.rateRecipe!(
      {},
      { recipeId: TEST_RECIPE_ID, value: 5 },
      ctx,
    );
    expect(updated.average).toBe(5);
    expect(updated.count).toBe(1);
  });

  it("enforces one comment per user per recipe and validates length", async () => {
    const ctx = makeCtx(db, {
      id: TEST_USER_ID.toString(),
      email: "user@example.com",
      name: "User",
    });

    const unauthCtx = makeCtx(db, null);
    await expect(
      resolvers.Mutation.addComment!(
        {},
        { recipeId: TEST_RECIPE_ID, body: "Nice" },
        unauthCtx,
      ),
    ).rejects.toThrow(/authentication required/i);

    await expect(
      resolvers.Mutation.addComment!(
        {},
        { recipeId: TEST_RECIPE_ID, body: "ok" },
        ctx,
      ),
    ).rejects.toThrow(/between/i);

    const first = await resolvers.Mutation.addComment!(
      {},
      { recipeId: TEST_RECIPE_ID, body: "Great recipe!" },
      ctx,
    );
    expect(first.body).toBe("Great recipe!");
    expect(first.recipeId).toBe(TEST_RECIPE_ID);

    await expect(
      resolvers.Mutation.addComment!(
        {},
        { recipeId: TEST_RECIPE_ID, body: "Second time" },
        ctx,
      ),
    ).rejects.toThrow(/already left a review/i);
  });

  it("allows deleting own comment and forbids others", async () => {
    const authorCtx = makeCtx(db, {
      id: TEST_USER_ID.toString(),
      email: "author@example.com",
      name: "Author",
    });

    const comment = await resolvers.Mutation.addComment!(
      {},
      { recipeId: TEST_RECIPE_ID, body: "Mine" },
      authorCtx,
    );

    const otherCtx = makeCtx(db, {
      id: new ObjectId("507f191e810c19729de860ea").toString(),
      email: "other@example.com",
      name: "Other",
    });

    await expect(
      resolvers.Mutation.deleteMyComment!(
        {},
        { commentId: comment.id },
        otherCtx,
      ),
    ).rejects.toThrow(/only delete your own/i);

    const deleted = await resolvers.Mutation.deleteMyComment!(
      {},
      { commentId: comment.id },
      authorCtx,
    );
    expect(deleted).toBe(true);

    const secondDelete = await resolvers.Mutation.deleteMyComment!(
      {},
      { commentId: comment.id },
      authorCtx,
    );
    expect(secondDelete).toBe(false);
  });

  it("surfaces database failures for mutations (network/DB resilience)", async () => {
    const brokenDb = {
      collection: () => {
        throw new Error("DB offline");
      },
    } as unknown as Db;

    const ctx = {
      db: brokenDb,
      req: {} as Request,
      res: {} as Response,
      user: {
        id: TEST_USER_ID.toString(),
        email: "user@example.com",
        name: "User",
      },
      commentsLoader: {} as Ctx["commentsLoader"],
    };

    await expect(
      resolvers.Mutation.rateRecipe!(
        {},
        { recipeId: TEST_RECIPE_ID, value: 4 },
        ctx,
      ),
    ).rejects.toThrow(/db offline/i);
  });
});
