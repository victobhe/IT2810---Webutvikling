import type { Request, Response } from "express";
import { ObjectId, type Db } from "mongodb";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import type { JwtPayload } from "jsonwebtoken";
import { GraphQLError } from "graphql";

export type AuthUser = {
  id: string;
  email: string;
  name?: string | null;
};

const AUTH_COOKIE = "auth_token";
const TOKEN_TTL_MS = 1000 * 60 * 60 * 24 * 30; // 30 days

const getJwtSecret = () => {
  const secret = process.env.JWT_SECRET;
  if (secret && secret.trim().length > 0) {
    return secret;
  }
  if ((process.env.NODE_ENV ?? "development") !== "production") {
    console.warn(
      "JWT_SECRET not set; falling back to insecure development secret.",
    );
    return "dev-insecure-secret";
  }
  throw new Error("JWT_SECRET must be set");
};

export const hashPassword = (password: string) => {
  return bcrypt.hash(password, 12);
};

export const verifyPassword = (password: string, hash: string) => {
  return bcrypt.compare(password, hash);
};

const signToken = (userId: string) => {
  const secret = getJwtSecret();
  return jwt.sign({ sub: userId }, secret, { expiresIn: TOKEN_TTL_MS / 1000 });
};

const decodeToken = (token: string) => {
  const secret = getJwtSecret();
  return jwt.verify(token, secret) as JwtPayload;
};

const useCrossSiteCookies = () => {
  const NODE_ENV = process.env.NODE_ENV ?? "development";
  const FRONTEND_HOST =
    process.env.CLIENT_ORIGIN ?? process.env.FRONTEND_URL ?? "";
  // if frontend host differs from backend host we need cross-site cookie behavior
  const crossSite = Boolean(
    FRONTEND_HOST && !FRONTEND_HOST.includes("localhost"),
  );
  return { isProd: NODE_ENV === "production", crossSite };
};

export const setAuthCookie = (res: Response, token: string) => {
  const { isProd, crossSite } = useCrossSiteCookies();
  res.cookie(AUTH_COOKIE, token, {
    httpOnly: true,
    sameSite: crossSite ? "none" : "lax",
    secure: isProd || crossSite,
    maxAge: TOKEN_TTL_MS,
  });
};

export const clearAuthCookie = (res: Response) => {
  const { isProd, crossSite } = useCrossSiteCookies();
  res.cookie(AUTH_COOKIE, "", {
    httpOnly: true,
    sameSite: crossSite ? "none" : "lax",
    secure: isProd || crossSite,
    maxAge: 0,
  });
};

export type UserDoc = {
  _id: ObjectId;
  email: string;
  passwordHash: string;
  name?: string | null;
  createdAt: Date;
};

const toAuthUser = (doc: UserDoc): AuthUser => ({
  id: doc._id.toString(),
  email: doc.email,
  name: doc.name ?? null,
});

export const getUserFromRequest = async (
  req: Request,
  db: Db,
): Promise<AuthUser | null> => {
  try {
    let token: string | null = null;

    if (req.cookies?.[AUTH_COOKIE]) {
      token = req.cookies[AUTH_COOKIE];
    } else if (
      typeof req.headers.authorization === "string" &&
      req.headers.authorization.startsWith("Bearer ")
    ) {
      token = req.headers.authorization.slice(7).trim();
    }

    if (!token) return null;

    const payload = decodeToken(token);
    if (!payload?.sub) return null;

    const user = await db
      .collection<UserDoc>("users")
      .findOne({ _id: new ObjectId(payload.sub) });
    if (!user) return null;
    return toAuthUser(user);
  } catch {
    return null;
  }
};

export const issueAuthSession = (res: Response, userId: string) => {
  const token = signToken(userId);
  setAuthCookie(res, token);
  return token;
};

export const requireAuth = (user: AuthUser | null) => {
  if (!user) {
    throw new GraphQLError("Authentication required", {
      extensions: { code: "UNAUTHENTICATED" },
    });
  }
  return user;
};

export { toAuthUser };
