import { ObjectId, Db } from "mongodb";
import type {
  Document as MongoDocument,
  Filter,
  Sort,
  OptionalUnlessRequiredId,
} from "mongodb";
import type { Request, Response } from "express";
import { GraphQLError } from "graphql";
import DataLoader from "dataloader";
import {
  type AuthUser,
  type UserDoc,
  requireAuth,
  hashPassword,
  verifyPassword,
  issueAuthSession,
  clearAuthCookie,
  toAuthUser,
} from "./auth.ts";

export type Ctx = {
  db: Db;
  req: Request;
  res: Response;
  user: AuthUser | null;
  commentsLoader: CommentsLoader;
};

type SortKind = "CREATED_AT" | "TITLE" | "TIME";
type SortDirection = "ASC" | "DESC";

type CursorToken = {
  sort: SortKind;
  direction: SortDirection;
  values: Record<string, string | number | null>;
};

type CursorFieldConfig = {
  field: string;
  key: string;
  order: 1 | -1;
  extract: (doc: DishDoc) => string | number | null;
  parse: (value: unknown) => unknown | null;
};

type SortMode = {
  kind: SortKind;
  direction: SortDirection;
  sortStage: Sort;
  cursorFields: CursorFieldConfig[];
};

type DishImageVariant = {
  format: "jpg" | "webp";
  width: number;
  url: string;
};

type DishImageDoc =
  | {
      alt?: string | null;
      variants?: DishImageVariant[] | null;
    }
  | string
  | null;

type DishDoc = {
  _id: ObjectId | string;
  idMeal?: string | null;
  title?: string | null;
  strMeal?: string | null;
  time?: number | null;
  timeMinutes?: number | null;
  time_minutes?: number | null;
  vegetarian?: boolean | null;
  vegitarian?: boolean | null;
  glutenFree?: boolean | null;
  glutenfree?: boolean | null;
  difficulty?: string | null;
  category?: string | null;
  strCategory?: string | null;
  area?: string | null;
  strArea?: string | null;
  instructions?: string | null;
  steps?: string[] | null;
  ingredients?: string[] | null;
  image?: DishImageDoc;
  strMealThumb?: string | null;
  strSource?: string | null;
  strYoutube?: string | null;
  createdAt?: Date | null;
};

type FavoriteDoc = {
  _id: ObjectId;
  userId: ObjectId;
  recipeId: string;
  createdAt: Date;
};

type RatingDoc = {
  _id: ObjectId;
  userId: ObjectId;
  recipeId: string;
  value: number;
  createdAt: Date;
  updatedAt: Date;
};

type CommentDoc = {
  _id: ObjectId;
  userId: ObjectId;
  recipeId: string;
  body: string;
  createdAt: Date;
  updatedAt: Date;
  rating?: number | null;
};

type CommentResult = {
  id: string;
  recipeId: string;
  body: string;
  createdAt: string;
  updatedAt: string;
  user: AuthUser;
  rating: number | null;
};

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MIN_PASSWORD_LENGTH = 6;
const MIN_COMMENT_LENGTH = 3;
const MAX_COMMENT_LENGTH = 1000;
const COMMENTS_PER_RECIPE = 20;

const sanitizeEmail = (email: string) => email.trim().toLowerCase();
const sanitizeName = (name?: string | null) => {
  if (typeof name !== "string") return null;
  const trimmed = name.trim();
  return trimmed.length > 0 ? trimmed : null;
};

const sanitizeComment = (body: string) => body.trim();

const toRecipeRating = (recipeId: string, average = 0, count = 0) => ({
  recipeId,
  average,
  count,
});

const isAbsoluteUrl = (value: string) =>
  /^https?:\/\//i.test(value) || value.startsWith("data:");

type RecipeFiltersInput = {
  q?: string | null;
  category?: string | null;
  area?: string | null;
  vegetarian?: boolean | null;
  glutenFree?: boolean | null;
  difficulty?: string[] | null;
  favorites?: boolean | null;
  searchIngredients?: boolean | null;
} | null;

// Whitelist av gyldige difficulty verdier
const VALID_DIFFICULTY_VALUES = new Set(["EASY", "MEDIUM", "HARD"]);

// Validerer og renser filter input fra klient
const validateAndSanitizeFilters = (
  filters: RecipeFiltersInput,
  user: AuthUser | null,
): RecipeFiltersInput => {
  if (!filters || typeof filters !== "object") {
    return null;
  }

  const validated: RecipeFiltersInput = {};

  // Validerer search term
  if (typeof filters.q === "string") {
    const trimmed = filters.q.trim();
    if (trimmed.length > 0 && trimmed.length <= 500) {
      validated.q = trimmed;
    }
  }

  // Validerer category
  if (typeof filters.category === "string") {
    const trimmed = filters.category.trim();
    if (trimmed.length > 0 && trimmed.length <= 100) {
      validated.category = trimmed;
    }
  }

  // Validerer area
  if (typeof filters.area === "string") {
    const trimmed = filters.area.trim();
    if (trimmed.length > 0 && trimmed.length <= 100) {
      validated.area = trimmed;
    }
  }

  // Validerer boolean filters
  if (filters.vegetarian === true) {
    validated.vegetarian = true;
  }

  if (filters.glutenFree === true) {
    validated.glutenFree = true;
  }

  if (filters.searchIngredients === true) {
    validated.searchIngredients = true;
  }

  // Validerer favorites filter - KREVER AUTH
  if (filters.favorites === true) {
    if (!user) {
      throw new GraphQLError("Authentication required to filter by favorites", {
        extensions: { code: "UNAUTHENTICATED" },
      });
    }
    validated.favorites = true;
  }

  // Validerer difficulty - STRENGT WHITELIST
  if (Array.isArray(filters.difficulty)) {
    const validDifficulties = filters.difficulty
      .filter((val): val is string => typeof val === "string")
      .map((val) => val.trim().toUpperCase())
      .filter((val) => VALID_DIFFICULTY_VALUES.has(val));

    if (validDifficulties.length > 0) {
      validated.difficulty = Array.from(new Set(validDifficulties));
    }
  }

  return Object.keys(validated).length > 0 ? validated : null;
};

type SortInput = {
  field?: string | null;
  direction?: string | null;
} | null;

type RecipesArgs =
  | {
      search?: string | null;
      filters?: RecipeFiltersInput;
      sort?: SortInput;
      first?: number | null;
      after?: string | null;
    }
  | undefined;

type RecipeArgs = { id: string };
type RecipeRatingArgs = { recipeId: string };
type RecipeUserStateArgs = { recipeId: string };
type CommentsArgs = {
  recipeId: string;
  first?: number | null;
  after?: string | null;
};

function decode(cursor?: string): CursorToken | null {
  if (!cursor) return null;
  try {
    const raw = Buffer.from(cursor, "base64").toString("utf8");
    const parsed = JSON.parse(raw) as Partial<CursorToken> & {
      values?: Record<string, unknown>;
    };
    if (!parsed || typeof parsed !== "object") {
      return null;
    }
    const sort = parsed.sort;
    if (sort !== "CREATED_AT" && sort !== "TITLE" && sort !== "TIME") {
      return null;
    }
    const directionRaw =
      typeof parsed.direction === "string"
        ? parsed.direction.toUpperCase()
        : "";
    const direction =
      directionRaw === "DESC" ? "DESC" : directionRaw === "ASC" ? "ASC" : null;
    if (!direction) return null;
    if (
      !parsed.values ||
      typeof parsed.values !== "object" ||
      Array.isArray(parsed.values)
    ) {
      return null;
    }
    const values: Record<string, string | number | null> = {};
    for (const [key, value] of Object.entries(parsed.values)) {
      if (
        typeof value === "string" ||
        typeof value === "number" ||
        value === null
      ) {
        values[key] = value;
      } else {
        return null;
      }
    }
    return { sort, direction, values };
  } catch {
    return null;
  }
}

function encode(token: CursorToken) {
  return Buffer.from(JSON.stringify(token)).toString("base64");
}

const getFieldValue = (doc: DishDoc, field: string): unknown =>
  (doc as Record<string, unknown>)[field];

const createStringCursorField = (
  field: string,
  key: string,
  order: 1 | -1,
): CursorFieldConfig => ({
  field,
  key,
  order,
  extract: (doc) => {
    const value = getFieldValue(doc, field);
    return typeof value === "string" ? value : null;
  },
  parse: (value) => {
    if (value === null) return null;
    return typeof value === "string" ? value : null;
  },
});

const createNumberCursorField = (
  field: string,
  key: string,
  order: 1 | -1,
): CursorFieldConfig => ({
  field,
  key,
  order,
  extract: (doc) => {
    const value = getFieldValue(doc, field);
    if (typeof value === "number" && Number.isFinite(value)) {
      return value;
    }
    return null;
  },
  parse: (value) => {
    if (value === null) return null;
    return typeof value === "number" && Number.isFinite(value) ? value : null;
  },
});

const SEARCH_RANK_FIELD = "__searchRank";

const toSortObject = (value: Sort): Record<string, 1 | -1> => {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, 1 | -1>;
  }
  return {};
};

const withSearchRankOrdering = (mode: SortMode): SortMode => {
  const baseSort = toSortObject(mode.sortStage);
  return {
    ...mode,
    sortStage: { [SEARCH_RANK_FIELD]: 1, ...baseSort },
    cursorFields: [
      createNumberCursorField(SEARCH_RANK_FIELD, SEARCH_RANK_FIELD, 1),
      ...mode.cursorFields,
    ],
  };
};

const createDateCursorField = (
  field: string,
  key: string,
  order: 1 | -1,
): CursorFieldConfig => ({
  field,
  key,
  order,
  extract: (doc) => {
    const value = getFieldValue(doc, field);
    if (value instanceof Date) {
      return value.toISOString();
    }
    if (typeof value === "string") {
      const date = new Date(value);
      if (!Number.isNaN(date.getTime())) {
        return date.toISOString();
      }
    }
    return null;
  },
  parse: (value) => {
    if (value === null || typeof value !== "string") return null;
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
  },
});

const createIdCursorField = (order: 1 | -1): CursorFieldConfig => ({
  field: "_id",
  key: "id",
  order,
  extract: (doc) => {
    if (doc._id instanceof ObjectId) return doc._id.toHexString();
    if (typeof doc._id === "string") return doc._id;
    return "";
  },
  parse: (value) => {
    if (typeof value !== "string") return null;
    return ObjectId.isValid(value) ? new ObjectId(value) : value;
  },
});

const NUMERIC_TYPES = [
  "double",
  "int",
  "long",
  "decimal",
  "decimal128",
] as const;

const coerceToNumber = (expression: MongoDocument): MongoDocument => ({
  $let: {
    vars: { value: expression },
    in: {
      $switch: {
        branches: [
          {
            case: { $in: [{ $type: "$$value" }, NUMERIC_TYPES] },
            then: { $toDouble: "$$value" },
          },
          {
            case: { $eq: [{ $type: "$$value" }, "string"] },
            then: {
              $let: {
                vars: {
                  numericMatch: {
                    $regexFind: {
                      input: { $trim: { input: "$$value" } },
                      regex: "(\\d+(?:\\.\\d+)?)",
                    },
                  },
                },
                in: {
                  $cond: [
                    {
                      $gt: [
                        {
                          $strLenCP: { $ifNull: ["$$numericMatch.match", ""] },
                        },
                        0,
                      ],
                    },
                    { $toDouble: "$$numericMatch.match" },
                    null,
                  ],
                },
              },
            },
          },
        ],
        default: null,
      },
    },
  },
});

const buildInferredTimeExpression = (): MongoDocument => ({
  $let: {
    vars: {
      stepCount: {
        $cond: [{ $isArray: "$steps" }, { $size: "$steps" }, 0],
      },
      instructionsLength: {
        $strLenCP: { $ifNull: ["$instructions", ""] },
      },
    },
    in: {
      $cond: [
        { $gt: ["$$stepCount", 0] },
        {
          $min: [
            240,
            {
              $max: [10, { $multiply: ["$$stepCount", 5] }],
            },
          ],
        },
        {
          $cond: [
            { $gt: ["$$instructionsLength", 0] },
            {
              $min: [
                240,
                {
                  $max: [
                    10,
                    {
                      $ceil: {
                        $divide: ["$$instructionsLength", 40],
                      },
                    },
                  ],
                },
              ],
            },
            10000,
          ],
        },
      ],
    },
  },
});

const buildTimeSortKeyExpression = (): MongoDocument => ({
  $let: {
    vars: {
      explicitTime: coerceToNumber({
        $ifNull: [
          "$time_minutes",
          {
            $ifNull: ["$time", "$timeMinutes"],
          },
        ],
      }),
      inferredTime: buildInferredTimeExpression(),
    },
    in: {
      $cond: [
        { $ne: ["$$explicitTime", null] },
        "$$explicitTime",
        "$$inferredTime",
      ],
    },
  },
});

const buildSortMode = (sortInput: SortInput | null): SortMode => {
  const field = normalize(sortInput?.field);
  if (field === "TITLE") {
    const direction: SortDirection =
      normalize(sortInput?.direction) === "DESC" ? "DESC" : "ASC";
    const order = direction === "DESC" ? -1 : 1;
    return {
      kind: "TITLE",
      direction,
      sortStage: { title: order, strMeal: order, _id: order },
      cursorFields: [
        createStringCursorField("title", "title", order),
        createStringCursorField("strMeal", "strMeal", order),
        createIdCursorField(order),
      ],
    };
  }
  if (field === "TIME") {
    const direction: SortDirection =
      normalize(sortInput?.direction) === "DESC" ? "DESC" : "ASC";
    const order = direction === "DESC" ? -1 : 1;
    return {
      kind: "TIME",
      direction,
      sortStage: {
        __timeSortKey: order,
        time_minutes: order,
        time: order,
        timeMinutes: order,
        _id: order,
      },
      cursorFields: [
        createNumberCursorField("__timeSortKey", "__timeSortKey", order),
        createNumberCursorField("time_minutes", "time_minutes", order),
        createNumberCursorField("time", "time", order),
        createNumberCursorField("timeMinutes", "timeMinutes", order),
        createIdCursorField(order),
      ],
    };
  }
  return {
    kind: "CREATED_AT",
    direction: "DESC",
    sortStage: { createdAt: -1, _id: -1 },
    cursorFields: [
      createDateCursorField("createdAt", "createdAt", -1),
      createIdCursorField(-1),
    ],
  };
};

const extractCursorValues = (
  mode: SortMode,
  doc: DishDoc,
): Record<string, string | number | null> => {
  const values: Record<string, string | number | null> = {};
  for (const field of mode.cursorFields) {
    const value = field.extract(doc);
    values[field.key] = value ?? null;
  }
  return values;
};

const buildCursorFilter = (
  mode: SortMode,
  token: CursorToken | null,
): MongoDocument | null => {
  if (!token) return null;
  if (token.sort !== mode.kind || token.direction !== mode.direction) {
    return null;
  }
  const parsedEntries: Array<{
    config: CursorFieldConfig;
    value: unknown | null;
  }> = [];
  for (const config of mode.cursorFields) {
    if (!(config.key in token.values)) {
      return null;
    }
    parsedEntries.push({
      config,
      value: config.parse(token.values[config.key]),
    });
  }
  const usableEntries = parsedEntries.filter(
    (
      entry,
    ): entry is {
      config: CursorFieldConfig;
      value: string | number | Date | ObjectId;
    } => entry.value !== null,
  );
  if (usableEntries.length === 0) {
    return null;
  }
  const clauses = usableEntries.map((entry, index) => {
    const equality: MongoDocument[] = [];
    for (let i = 0; i < index; i++) {
      const prior = usableEntries[i];
      equality.push({ [prior.config.field]: prior.value });
    }
    const operator = entry.config.order === 1 ? "$gt" : "$lt";
    return {
      $and: [
        ...equality,
        {
          [entry.config.field]: {
            [operator]: entry.value,
          },
        },
      ],
    };
  });
  return clauses.length > 0 ? { $or: clauses } : null;
};

const encodeCursorFromDoc = (mode: SortMode, doc: DishDoc): string | null => {
  const values = extractCursorValues(mode, doc);
  if (!values) return null;
  return encode({ sort: mode.kind, direction: mode.direction, values });
};

const coerceSearchTerm = (value?: string | null) =>
  typeof value === "string" ? value.trim() : "";

const pickSearchTerm = (primary?: string | null, fallback?: string | null) => {
  const first = coerceSearchTerm(primary);
  if (first.length > 0) return first;
  const second = coerceSearchTerm(fallback);
  return second.length > 0 ? second : null;
};

const pickId = (doc: DishDoc) => {
  if (typeof doc.idMeal === "string" && doc.idMeal.trim().length > 0) {
    return doc.idMeal.trim();
  }
  if (typeof doc._id === "string") return doc._id;
  return doc._id.toString();
};

const pickTitle = (doc: DishDoc) => {
  const candidates = [doc.title, doc.strMeal];
  for (const candidate of candidates) {
    if (typeof candidate === "string" && candidate.trim().length > 0) {
      return candidate.trim();
    }
  }
  return "Untitled Recipe";
};

const pickTime = (doc: DishDoc) => {
  const candidates = [doc.time_minutes, doc.time, doc.timeMinutes];
  for (const value of candidates) {
    if (typeof value === "number" && Number.isFinite(value)) {
      return Math.max(0, Math.floor(value));
    }
  }
  return null;
};

const pickBool = (value: unknown) => {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (["true", "1", "yes"].includes(normalized)) return true;
    if (["false", "0", "no"].includes(normalized)) return false;
  }
  if (typeof value === "number") {
    if (value === 0) return false;
    if (value === 1) return true;
  }
  return null;
};

const pickDifficulty = (value: unknown) => {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toUpperCase();
  const allowed = new Set(["EASY", "MEDIUM", "HARD"]);
  if (allowed.has(normalized)) return normalized as "EASY" | "MEDIUM" | "HARD";
  return normalized.length > 0 ? normalized : null;
};

const pickCategory = (doc: DishDoc) => {
  const candidates = [doc.category, doc.strCategory];
  for (const value of candidates) {
    if (typeof value === "string" && value.trim().length > 0) {
      return value.trim();
    }
  }
  return null;
};

const pickImage = (doc: DishDoc) => {
  const candidates: string[] = [];

  const pushCandidate = (value?: string | null) => {
    if (typeof value !== "string") return;
    const trimmed = value.trim();
    if (trimmed.length === 0) return;
    candidates.push(trimmed);
  };

  if (typeof doc.image === "string") {
    pushCandidate(doc.image);
  } else if (
    doc.image &&
    typeof doc.image === "object" &&
    "variants" in doc.image &&
    Array.isArray((doc.image as { variants?: DishImageVariant[] }).variants)
  ) {
    for (const variant of (doc.image as { variants?: DishImageVariant[] })
      .variants ?? []) {
      if (variant && typeof variant.url === "string") {
        pushCandidate(variant.url);
      }
    }
  }

  pushCandidate(doc.strMealThumb);

  const absolute = candidates.find(isAbsoluteUrl);
  if (absolute) return absolute;

  return candidates.length > 0 ? candidates[0] : null;
};

const pickInstructions = (doc: DishDoc, steps: string[]) => {
  if (
    typeof doc.instructions === "string" &&
    doc.instructions.trim().length > 0
  ) {
    return doc.instructions.trim();
  }
  if (steps.length > 0) {
    return steps.join("\n");
  }
  return null;
};

const toRecipe = (doc: DishDoc) => {
  const ingredients = Array.isArray(doc.ingredients)
    ? doc.ingredients.filter(
        (entry) => typeof entry === "string" && entry.trim().length > 0,
      )
    : [];
  const steps = Array.isArray(doc.steps)
    ? doc.steps.filter(
        (entry) => typeof entry === "string" && entry.trim().length > 0,
      )
    : [];

  const vegetarian = pickBool(doc.vegetarian ?? doc.vegitarian);
  const glutenFree = pickBool(doc.glutenFree ?? doc.glutenfree);

  return {
    id: pickId(doc),
    title: pickTitle(doc),
    time: pickTime(doc),
    vegetarian,
    glutenFree,
    difficulty: pickDifficulty(doc.difficulty),
    category: pickCategory(doc),
    area: typeof doc.strArea === "string" ? doc.strArea.trim() : null,
    source: typeof doc.strSource === "string" ? doc.strSource.trim() : null,
    youtube: typeof doc.strYoutube === "string" ? doc.strYoutube.trim() : null,
    instructions: pickInstructions(doc, steps),
    image: pickImage(doc),
    ingredients,
    steps,
    createdAt:
      doc.createdAt instanceof Date
        ? doc.createdAt.toISOString()
        : new Date().toISOString(),
  };
};

type RecipeResult = ReturnType<typeof toRecipe>;

const normalize = (value: unknown) =>
  typeof value === "string" ? value.toUpperCase() : "";
const escapeRegex = (value: string) =>
  value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const TRUTHY_MATCH_VALUES: Array<boolean | number | string> = [
  true,
  "true",
  "TRUE",
  "True",
  "yes",
  "YES",
  "Yes",
  1,
  "1",
];

const buildBooleanFieldClauses = (fields: (keyof DishDoc)[]) => {
  const clauses: Filter<DishDoc>[] = [];
  for (const field of fields) {
    for (const value of TRUTHY_MATCH_VALUES) {
      clauses.push({ [field]: value } as Filter<DishDoc>);
    }
  }
  return clauses;
};

const SEARCHABLE_TITLE_FIELDS: (keyof DishDoc)[] = ["title", "strMeal"];

const buildSearchRankExpression = (searchTerm: string): MongoDocument => {
  const trimmed = searchTerm.trim();
  if (trimmed.length === 0) {
    return { $literal: 4 };
  }

  const escaped = escapeRegex(trimmed);
  const exactRegex = new RegExp(`^${escaped}$`, "i");
  const prefixRegex = new RegExp(`^${escaped}`, "i");
  const boundaryRegex = new RegExp(`\\b${escaped}\\b`, "i");
  const partialRegex = new RegExp(escaped, "i");

  const buildRegexClauses = (regex: RegExp): MongoDocument => ({
    $or: SEARCHABLE_TITLE_FIELDS.map((field) => ({
      $regexMatch: {
        input: { $ifNull: [`$${String(field)}`, ""] },
        regex,
      },
    })),
  });

  const phraseRank: MongoDocument = {
    $switch: {
      branches: [
        { case: buildRegexClauses(exactRegex), then: 0 },
        { case: buildRegexClauses(prefixRegex), then: 1 },
        { case: buildRegexClauses(boundaryRegex), then: 2 },
        { case: buildRegexClauses(partialRegex), then: 3 },
      ],
      default: 4,
    },
  };

  const tokens = trimmed.split(/\s+/).filter((token) => token.length > 0);
  const tokenPenalty: MongoDocument =
    tokens.length === 0
      ? { $literal: 0 }
      : {
          $add: tokens.map((token) => {
            const tokenEscaped = escapeRegex(token);
            const tokenWordRegex = new RegExp(`\\b${tokenEscaped}\\b`, "i");
            const tokenPartialRegex = new RegExp(tokenEscaped, "i");
            return {
              $cond: [
                buildRegexClauses(tokenWordRegex),
                0,
                {
                  $cond: [buildRegexClauses(tokenPartialRegex), 1, 2],
                },
              ],
            };
          }),
        };

  return {
    $add: [{ $multiply: [phraseRank, 100] }, tokenPenalty],
  };
};

const ensureObjectId = (id: string) => {
  if (!ObjectId.isValid(id)) {
    throw new GraphQLError("Invalid identifier", {
      extensions: { code: "BAD_USER_INPUT" },
    });
  }
  return new ObjectId(id);
};

const getRecipeRatingStats = async (db: Db, recipeId: string) => {
  const ratingsCol = db.collection<RatingDoc>("ratings");
  const [result] = await ratingsCol
    .aggregate<{ _id: string; average: number; count: number }>([
      { $match: { recipeId } },
      {
        $group: {
          _id: "$recipeId",
          average: { $avg: "$value" },
          count: { $sum: 1 },
        },
      },
    ])
    .toArray();

  if (!result) {
    return toRecipeRating(recipeId, 0, 0);
  }
  return toRecipeRating(
    recipeId,
    Number(result.average ?? 0),
    Number(result.count ?? 0),
  );
};

const fetchFavoriteState = async (
  db: Db,
  userId: ObjectId,
  recipeId: string,
) => {
  const favoritesCol = db.collection<FavoriteDoc>("favorites");
  const favorite = await favoritesCol.findOne({ userId, recipeId });
  return Boolean(favorite);
};

const fetchMyRatingValue = async (
  db: Db,
  userId: ObjectId,
  recipeId: string,
) => {
  const ratingsCol = db.collection<RatingDoc>("ratings");
  const rating = await ratingsCol.findOne({ userId, recipeId });
  return rating?.value ?? null;
};

const hydrateComments = async (
  db: Db,
  docs: CommentDoc[],
): Promise<CommentResult[]> => {
  if (docs.length === 0) return [];
  const userIdStrings = Array.from(
    new Set(docs.map((doc) => doc.userId.toString())),
  );
  const userIds = userIdStrings.map((id) => new ObjectId(id));
  const recipeIds = Array.from(new Set(docs.map((doc) => doc.recipeId)));

  const users = await db
    .collection<UserDoc>("users")
    .find({ _id: { $in: userIds } })
    .toArray();

  const userMap = new Map(
    users.map((doc) => [doc._id.toString(), toAuthUser(doc)]),
  );
  const missingSnapshot = docs.filter(
    (doc) => !Object.prototype.hasOwnProperty.call(doc, "rating"),
  );
  let fallbackRatingsMap: Map<string, number> | null = null;

  if (missingSnapshot.length > 0) {
    const fallbackRecipeIds = Array.from(
      new Set(missingSnapshot.map((doc) => doc.recipeId)),
    );
    const fallbackUserIds = Array.from(
      new Set(missingSnapshot.map((doc) => doc.userId.toString())),
    ).map((id) => new ObjectId(id));
    const fallbackRatings = await db
      .collection<RatingDoc>("ratings")
      .find({
        recipeId: { $in: fallbackRecipeIds },
        userId: { $in: fallbackUserIds },
      })
      .toArray();
    fallbackRatingsMap = new Map(
      fallbackRatings.map((rating) => [
        `${rating.recipeId}:${rating.userId.toString()}`,
        rating.value,
      ]),
    );
  }

  return docs.map((doc) => {
    const ratingKey = `${doc.recipeId}:${doc.userId.toString()}`;
    const hasSnapshot = Object.prototype.hasOwnProperty.call(doc, "rating");
    const ratingValue = hasSnapshot
      ? (doc.rating ?? null)
      : (fallbackRatingsMap?.get(ratingKey) ?? null);
    return {
      id: doc._id.toString(),
      recipeId: doc.recipeId,
      body: doc.body,
      createdAt: doc.createdAt.toISOString(),
      updatedAt: doc.updatedAt.toISOString(),
      user: userMap.get(doc.userId.toString()) ?? {
        id: doc.userId.toString(),
        email: "unknown",
        name: null,
      },
      rating: ratingValue,
    };
  });
};

const fetchRecipesByIds = async (
  db: Db,
  ids: string[],
): Promise<Map<string, RecipeResult>> => {
  const trimmed = ids.map((id) => id.trim()).filter((id) => id.length > 0);
  if (trimmed.length === 0) {
    return new Map();
  }
  const uniqueIds = Array.from(new Set(trimmed));
  const objectIds = uniqueIds
    .filter((id) => ObjectId.isValid(id))
    .map((id) => new ObjectId(id));
  const filters: Filter<DishDoc>[] = [];
  if (uniqueIds.length > 0) {
    filters.push({ idMeal: { $in: uniqueIds } } as Filter<DishDoc>);
  }
  if (objectIds.length > 0) {
    filters.push({ _id: { $in: objectIds } } as Filter<DishDoc>);
  }
  if (filters.length === 0) {
    return new Map();
  }
  const query: Filter<DishDoc> =
    filters.length === 1 ? filters[0] : ({ $or: filters } as Filter<DishDoc>);
  const docs = await db.collection<DishDoc>("dishes").find(query).toArray();
  const result = new Map<string, RecipeResult>();
  for (const doc of docs) {
    const recipe = toRecipe(doc);
    result.set(recipe.id, recipe);
  }
  return result;
};

type CommentsLoader = DataLoader<string, CommentResult[]>;

export const createCommentsLoader = (db: Db): CommentsLoader => {
  return new DataLoader(async (keys) => {
    const normalizedKeys = keys.map((key) => key.trim());
    const searchKeys = normalizedKeys.filter((key) => key.length > 0);
    if (searchKeys.length === 0) {
      return normalizedKeys.map(() => []);
    }

    const pipeline = [
      { $match: { recipeId: { $in: searchKeys } } },
      { $sort: { _id: -1 } },
      { $group: { _id: "$recipeId", docs: { $push: "$$ROOT" } } },
      { $project: { docs: { $slice: ["$docs", COMMENTS_PER_RECIPE] } } },
    ];

    const grouped = await db
      .collection<CommentDoc>("comments")
      .aggregate<{ _id: string; docs: CommentDoc[] }>(pipeline)
      .toArray();

    const docsMap = new Map(
      grouped.map((entry) => [entry._id, entry.docs ?? []]),
    );
    const perRecipeCounts: number[] = [];
    const allDocs: CommentDoc[] = [];

    for (const key of normalizedKeys) {
      const docs = docsMap.get(key) ?? [];
      perRecipeCounts.push(docs.length);
      allDocs.push(...docs);
    }

    const hydrated = await hydrateComments(db, allDocs);
    const results: CommentResult[][] = [];
    let cursor = 0;
    for (const count of perRecipeCounts) {
      results.push(count > 0 ? hydrated.slice(cursor, cursor + count) : []);
      cursor += count;
    }

    return results;
  });
};

const buildRecipeLookupFilter = (id: string): Filter<DishDoc> => {
  const clauses: Filter<DishDoc>[] = [{ idMeal: id }];
  if (ObjectId.isValid(id)) {
    clauses.push({ _id: new ObjectId(id) });
  }
  if (clauses.length === 1) {
    return clauses[0];
  }
  return { $or: clauses } as Filter<DishDoc>;
};

const findRecipeDocumentById = async (
  db: Db,
  id: string,
): Promise<DishDoc | null> => {
  const query = buildRecipeLookupFilter(id);
  return db.collection<DishDoc>("dishes").findOne(query);
};

const ensureRecipeExists = async (db: Db, id: string) => {
  const doc = await findRecipeDocumentById(db, id);
  if (!doc) {
    throw new GraphQLError("Recipe not found", {
      extensions: { code: "NOT_FOUND" },
    });
  }
  return doc;
};

type RecipeWithRatingCache = {
  __ratingStatsPromise?: Promise<{
    recipeId: string;
    average: number;
    count: number;
  }>;
};

const getCachedRatingStats = (
  recipe: { id: string } & RecipeWithRatingCache,
  db: Db,
) => {
  if (!recipe.__ratingStatsPromise) {
    recipe.__ratingStatsPromise = getRecipeRatingStats(db, recipe.id);
  }
  return recipe.__ratingStatsPromise;
};

const clampLimit = (value?: number | null, fallback = 25) => {
  if (typeof value !== "number" || Number.isNaN(value)) return fallback;
  const normalized = Math.floor(value);
  if (normalized <= 0) return 1;
  if (normalized > 100) return 100;
  return normalized;
};

export const resolvers = {
  Query: {
    me: (_parent: unknown, _args: unknown, { user }: Ctx) => user ?? null,
    myProfile: async (
      _parent: unknown,
      args: { favoritesLimit?: number | null; commentsLimit?: number | null },
      { db, user }: Ctx,
    ) => {
      const current = requireAuth(user);
      const userId = new ObjectId(current.id);
      const favoritesCol = db.collection<FavoriteDoc>("favorites");
      const commentsCol = db.collection<CommentDoc>("comments");

      const favoritesLimit = clampLimit(args?.favoritesLimit, 25);
      const commentsLimit = clampLimit(args?.commentsLimit, 25);

      const [favoriteDocsRaw, commentDocsRaw, favoritesTotal, commentsTotal] =
        await Promise.all([
          favoritesCol
            .find({ userId })
            .sort({ createdAt: -1, _id: -1 })
            .limit(favoritesLimit + 1)
            .toArray(),
          commentsCol
            .find({ userId })
            .sort({ _id: -1 })
            .limit(commentsLimit + 1)
            .toArray(),
          favoritesCol.countDocuments({ userId }),
          commentsCol.countDocuments({ userId }),
        ]);

      const favoritesHasMore = favoriteDocsRaw.length > favoritesLimit;
      const commentsHasMore = commentDocsRaw.length > commentsLimit;

      const favoriteDocs = favoritesHasMore
        ? favoriteDocsRaw.slice(0, favoritesLimit)
        : favoriteDocsRaw;
      const commentDocs = commentsHasMore
        ? commentDocsRaw.slice(0, commentsLimit)
        : commentDocsRaw;

      const recipeIds = Array.from(
        new Set([
          ...favoriteDocs.map((doc) => doc.recipeId),
          ...commentDocs.map((doc) => doc.recipeId),
        ]),
      ).filter(
        (id): id is string => typeof id === "string" && id.trim().length > 0,
      );

      const recipeMap = await fetchRecipesByIds(db, recipeIds);
      const favorites = favoriteDocs
        .map((doc) => recipeMap.get(doc.recipeId))
        .filter((recipe): recipe is RecipeResult => Boolean(recipe));

      const hydratedComments = await hydrateComments(db, commentDocs);
      const comments = hydratedComments
        .map((comment) => {
          const recipe = recipeMap.get(comment.recipeId);
          if (!recipe) return null;
          return {
            id: comment.id,
            body: comment.body,
            createdAt: comment.createdAt,
            updatedAt: comment.updatedAt,
            rating: comment.rating ?? null,
            recipe,
          };
        })
        .filter(
          (
            entry,
          ): entry is {
            id: string;
            body: string;
            createdAt: string;
            updatedAt: string;
            rating: number | null;
            recipe: RecipeResult;
          } => Boolean(entry),
        );

      return {
        user: current,
        stats: {
          favorites: favoritesTotal,
          comments: commentsTotal,
        },
        favorites,
        favoritesHasMore,
        comments,
        commentsHasMore,
      };
    },
    recipes: async (_parent: unknown, args: RecipesArgs, { db, user }: Ctx) => {
      const col = db.collection<DishDoc>("dishes");
      const query: Filter<DishDoc> = {};

      // SIKKERHET: Validerer og renser filters fra klient
      let filters: RecipeFiltersInput;
      try {
        filters = validateAndSanitizeFilters(args?.filters ?? null, user);
      } catch (error) {
        if (error instanceof GraphQLError) {
          throw error;
        }
        throw new GraphQLError("Invalid filter parameters", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }

      const limit = Math.min(Math.max(args?.first ?? 20, 1), 100);
      const emptyConnection = () => ({
        items: [] as ReturnType<typeof toRecipe>[],
        pageInfo: {
          endCursor: null,
          hasNextPage: false,
          totalCount: 0,
        },
      });

      const searchTerm = pickSearchTerm(
        args?.search ?? null,
        filters?.q ?? null,
      );
      const includeIngredients = filters?.searchIngredients === true;
      if (searchTerm) {
        const terms = searchTerm.split(/\s+/).filter((term) => term.length > 0);

        if (terms.length > 0) {
          const orClauses: Filter<DishDoc>[] = [];
          for (const term of terms) {
            const pattern = escapeRegex(term);
            const regex = new RegExp(pattern, "i");
            orClauses.push({ title: regex }, { strMeal: regex });
            if (includeIngredients) {
              orClauses.push({
                ingredients: { $elemMatch: { $regex: regex } },
              });
            }
          }
          query.$and = [...(query.$and ?? []), { $or: orClauses }];
        }
      }

      if (filters?.category) {
        const category = filters.category.trim();
        if (category.length > 0) {
          query.$and = [
            ...(query.$and ?? []),
            {
              $or: [{ category }, { strCategory: category }],
            },
          ];
        }
      }

      if (filters?.area) {
        const area = filters.area.trim();
        if (area.length > 0) {
          const pattern = escapeRegex(area);
          const areaRegex = new RegExp(`^${pattern}$`, "i");
          query.$and = [
            ...(query.$and ?? []),
            {
              $or: [{ area: areaRegex }, { strArea: areaRegex }],
            },
          ];
        }
      }

      if (filters?.vegetarian) {
        query.$and = [
          ...(query.$and ?? []),
          { $or: buildBooleanFieldClauses(["vegetarian", "vegitarian"]) },
        ];
      }

      if (filters?.glutenFree) {
        query.$and = [
          ...(query.$and ?? []),
          { $or: buildBooleanFieldClauses(["glutenFree", "glutenfree"]) },
        ];
      }

      // Validerer difficulty verdier mot whitelist
      if (Array.isArray(filters?.difficulty) && filters.difficulty.length > 0) {
        const validDifficulties = filters.difficulty.filter((val) =>
          VALID_DIFFICULTY_VALUES.has(val),
        );
        if (validDifficulties.length > 0) {
          const difficultyMatch: Filter<DishDoc> = {
            $expr: {
              $in: [
                {
                  $cond: [
                    { $eq: [{ $type: "$difficulty" }, "string"] },
                    { $toUpper: { $trim: { input: "$difficulty" } } },
                    "$difficulty",
                  ],
                },
                validDifficulties,
              ],
            },
          };
          query.$and = [...(query.$and ?? []), difficultyMatch];
        }
      }

      const userObjectId = user ? new ObjectId(user.id) : null;
      const filterFavorites = Boolean(filters?.favorites);
      if (filterFavorites && !userObjectId) {
        return emptyConnection();
      }

      const sortInput = args?.sort ?? null;
      const baseSortMode = buildSortMode(sortInput);
      const sortMode = searchTerm
        ? withSearchRankOrdering(baseSortMode)
        : baseSortMode;
      const cursorToken = decode(args?.after ?? undefined);
      const cursorFilter = buildCursorFilter(sortMode, cursorToken);

      const canonicalIdExpr: MongoDocument = {
        $let: {
          vars: {
            mealId: {
              $trim: {
                input: {
                  $ifNull: ["$idMeal", ""],
                },
              },
            },
          },
          in: {
            $cond: [
              { $gt: [{ $strLenCP: "$$mealId" }, 0] },
              "$$mealId",
              { $toString: "$_id" },
            ],
          },
        },
      };

      const pipeline: MongoDocument[] = [
        { $match: query },
        { $addFields: { __canonicalId: canonicalIdExpr } },
      ];

      if (filterFavorites && userObjectId) {
        pipeline.push(
          {
            $lookup: {
              from: "favorites",
              let: { recipeId: "$__canonicalId" },
              pipeline: [
                {
                  $match: {
                    $expr: {
                      $and: [
                        { $eq: ["$userId", userObjectId] },
                        { $eq: ["$recipeId", "$$recipeId"] },
                      ],
                    },
                  },
                },
                { $limit: 1 },
              ],
              as: "__favoriteDocs",
            },
          },
          { $match: { "__favoriteDocs.0": { $exists: true } } },
          { $unset: "__favoriteDocs" },
        );
      }

      if (searchTerm) {
        pipeline.push({
          $addFields: {
            [SEARCH_RANK_FIELD]: buildSearchRankExpression(searchTerm),
          },
        });
      }

      if (sortMode.kind === "TIME") {
        pipeline.push({
          $addFields: {
            __timeSortKey: {
              $ifNull: [
                "$time_minutes",
                {
                  $ifNull: [
                    "$time",
                    {
                      $ifNull: ["$timeMinutes", buildTimeSortKeyExpression()],
                    },
                  ],
                },
              ],
            },
          },
        });
      }

      pipeline.push(
        { $sort: sortMode.sortStage },
        {
          $group: {
            _id: "$__canonicalId",
            doc: { $first: "$$ROOT" },
          },
        },
        { $replaceRoot: { newRoot: "$doc" } },
        { $unset: "__canonicalId" },
        {
          $facet: {
            items: [
              ...(cursorFilter ? [{ $match: cursorFilter }] : []),
              { $sort: sortMode.sortStage },
              { $limit: limit + 1 },
            ],
            total: [{ $count: "value" }],
          },
        },
      );

      const [result] = await col
        .aggregate<{ items: DishDoc[]; total: { value: number }[] }>(pipeline)
        .toArray();
      const docs = result?.items ?? [];
      const totalCount = result?.total?.[0]?.value ?? 0;
      const hasNext = docs.length > limit;
      const slice = hasNext ? docs.slice(0, limit) : docs;
      const lastDoc = slice[slice.length - 1];
      const endCursor =
        hasNext && lastDoc ? encodeCursorFromDoc(sortMode, lastDoc) : null;

      return {
        items: slice.map(toRecipe),
        pageInfo: {
          endCursor,
          hasNextPage: hasNext,
          totalCount,
        },
      };
    },
    recipe: async (_parent: unknown, { id }: RecipeArgs, { db }: Ctx) => {
      const col = db.collection<DishDoc>("dishes");
      const lookupId = ObjectId.isValid(id) ? new ObjectId(id) : id;
      const orCriteria: Filter<DishDoc>[] = [{ _id: lookupId }];
      if (typeof id === "string") {
        orCriteria.push({ idMeal: id });
      }
      const doc = await col.findOne({ $or: orCriteria });
      if (!doc) return null;
      return toRecipe(doc);
    },
    recipeUserState: async (
      _parent: unknown,
      { recipeId }: RecipeUserStateArgs,
      { db, user }: Ctx,
    ) => {
      const id = recipeId.trim();
      if (id.length === 0) {
        throw new GraphQLError("recipeId is required", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      if (!user) {
        return { isFavorite: false, myRating: null };
      }
      const userId = new ObjectId(user.id);
      const [isFavorite, myRating] = await Promise.all([
        fetchFavoriteState(db, userId, id),
        fetchMyRatingValue(db, userId, id),
      ]);
      return { isFavorite, myRating };
    },
    recipeRating: async (
      _parent: unknown,
      { recipeId }: RecipeRatingArgs,
      { db }: Ctx,
    ) => {
      const id = recipeId.trim();
      if (id.length === 0) {
        throw new GraphQLError("recipeId is required", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      return getRecipeRatingStats(db, id);
    },
    comments: async (
      _parent: unknown,
      { recipeId, first, after }: CommentsArgs,
      { db }: Ctx,
    ) => {
      const id = recipeId.trim();
      if (id.length === 0) {
        throw new GraphQLError("recipeId is required", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      const limit = Math.min(Math.max(first ?? 20, 1), 100);
      const commentsCol = db.collection<CommentDoc>("comments");
      const match: Filter<CommentDoc> = { recipeId: id };
      if (after && ObjectId.isValid(after)) {
        match._id = { $lt: new ObjectId(after) };
      }
      const docs = await commentsCol
        .find(match)
        .sort({ _id: -1 })
        .limit(limit)
        .toArray();
      return hydrateComments(db, docs);
    },
  },
  Mutation: {
    signup: async (
      _parent: unknown,
      args: { email: string; password: string; name?: string | null },
      { db, res }: Ctx,
    ) => {
      const email = sanitizeEmail(args.email ?? "");
      const password = args.password ?? "";
      if (!EMAIL_REGEX.test(email)) {
        throw new GraphQLError("Invalid email", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      if (password.length < MIN_PASSWORD_LENGTH) {
        throw new GraphQLError(
          `Password must be at least ${MIN_PASSWORD_LENGTH} characters`,
          {
            extensions: { code: "BAD_USER_INPUT" },
          },
        );
      }
      const usersCol = db.collection<UserDoc>("users");
      const existing = await usersCol.findOne({ email });
      if (existing) {
        throw new GraphQLError("Email already in use", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }

      const passwordHash = await hashPassword(password);
      const now = new Date();
      const name = sanitizeName(args.name);
      const insert = await usersCol.insertOne({
        email,
        passwordHash,
        name,
        createdAt: now,
      } as OptionalUnlessRequiredId<UserDoc>);

      const user: AuthUser = {
        id: insert.insertedId.toString(),
        email,
        name,
      };

      const token = issueAuthSession(res, user.id);
      return { user, token };
    },
    login: async (
      _parent: unknown,
      args: { email: string; password: string },
      { db, res }: Ctx,
    ) => {
      const email = sanitizeEmail(args.email ?? "");
      const password = args.password ?? "";
      if (!EMAIL_REGEX.test(email) || password.length === 0) {
        throw new GraphQLError("Invalid credentials", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      const usersCol = db.collection<UserDoc>("users");
      const userDoc = await usersCol.findOne({ email });
      if (!userDoc) {
        throw new GraphQLError("Invalid credentials", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      const valid = await verifyPassword(password, userDoc.passwordHash);
      if (!valid) {
        throw new GraphQLError("Invalid credentials", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      const user = toAuthUser(userDoc);
      const token = issueAuthSession(res, user.id);
      return { user, token };
    },
    logout: async (_parent: unknown, _args: unknown, { res }: Ctx) => {
      clearAuthCookie(res);
      return true;
    },
    updateMyProfile: async (
      _parent: unknown,
      { input }: { input: { name?: string | null; email?: string | null } },
      { db, user }: Ctx,
    ) => {
      const current = requireAuth(user);
      const userId = new ObjectId(current.id);
      const usersCol = db.collection<UserDoc>("users");
      const userDoc = await usersCol.findOne({ _id: userId });
      if (!userDoc) {
        throw new GraphQLError("User not found", {
          extensions: { code: "NOT_FOUND" },
        });
      }
      const updates: Partial<UserDoc> = {};
      let hasChanges = false;
      if (Object.prototype.hasOwnProperty.call(input, "name")) {
        updates.name = sanitizeName(input.name);
        hasChanges = true;
      }
      if (Object.prototype.hasOwnProperty.call(input, "email")) {
        if (
          typeof input.email !== "string" ||
          input.email.trim().length === 0
        ) {
          throw new GraphQLError("Email is required", {
            extensions: { code: "BAD_USER_INPUT" },
          });
        }
        const email = sanitizeEmail(input.email);
        if (!EMAIL_REGEX.test(email)) {
          throw new GraphQLError("Invalid email", {
            extensions: { code: "BAD_USER_INPUT" },
          });
        }
        if (email !== userDoc.email) {
          const existing = await usersCol.findOne({
            email,
            _id: { $ne: userId },
          });
          if (existing) {
            throw new GraphQLError("Email already in use", {
              extensions: { code: "BAD_USER_INPUT" },
            });
          }
          updates.email = email;
          hasChanges = true;
        }
      }
      if (!hasChanges) {
        return toAuthUser(userDoc);
      }
      await usersCol.updateOne({ _id: userId }, { $set: updates });
      const refreshed = await usersCol.findOne({ _id: userId });
      return toAuthUser(refreshed ?? userDoc);
    },
    changeMyPassword: async (
      _parent: unknown,
      {
        currentPassword,
        newPassword,
      }: { currentPassword: string; newPassword: string },
      { db, user }: Ctx,
    ) => {
      const current = requireAuth(user);
      const usersCol = db.collection<UserDoc>("users");
      const userId = new ObjectId(current.id);
      const userDoc = await usersCol.findOne({ _id: userId });
      if (!userDoc) {
        throw new GraphQLError("User not found", {
          extensions: { code: "NOT_FOUND" },
        });
      }
      if (!currentPassword || currentPassword.length === 0) {
        throw new GraphQLError("Current password is required", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      if (!newPassword || newPassword.length < MIN_PASSWORD_LENGTH) {
        throw new GraphQLError(
          `New password must be at least ${MIN_PASSWORD_LENGTH} characters`,
          {
            extensions: { code: "BAD_USER_INPUT" },
          },
        );
      }
      if (currentPassword === newPassword) {
        throw new GraphQLError(
          "New password must be different from the current password",
          {
            extensions: { code: "BAD_USER_INPUT" },
          },
        );
      }
      const valid = await verifyPassword(currentPassword, userDoc.passwordHash);
      if (!valid) {
        throw new GraphQLError("Current password is incorrect", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      const nextHash = await hashPassword(newPassword);
      await usersCol.updateOne(
        { _id: userId },
        { $set: { passwordHash: nextHash } },
      );
      return true;
    },
    deleteMyAccount: async (
      _parent: unknown,
      { password }: { password: string },
      { db, user, res }: Ctx,
    ) => {
      const current = requireAuth(user);
      if (!password || password.length === 0) {
        throw new GraphQLError("Password is required", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      const userId = new ObjectId(current.id);
      const usersCol = db.collection<UserDoc>("users");
      const userDoc = await usersCol.findOne({ _id: userId });
      if (!userDoc) {
        clearAuthCookie(res);
        return true;
      }
      const valid = await verifyPassword(password, userDoc.passwordHash);
      if (!valid) {
        throw new GraphQLError("Password is incorrect", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      await Promise.all([
        db.collection<FavoriteDoc>("favorites").deleteMany({ userId }),
        db.collection<RatingDoc>("ratings").deleteMany({ userId }),
        db.collection<CommentDoc>("comments").deleteMany({ userId }),
        usersCol.deleteOne({ _id: userId }),
      ]);
      clearAuthCookie(res);
      return true;
    },
    toggleFavorite: async (
      _parent: unknown,
      { recipeId }: { recipeId: string },
      { db, user }: Ctx,
    ) => {
      const current = requireAuth(user);
      const id = recipeId.trim();
      if (id.length === 0) {
        throw new GraphQLError("recipeId is required", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      const favoritesCol = db.collection<FavoriteDoc>("favorites");
      const userId = new ObjectId(current.id);
      const existing = await favoritesCol.findOne({ userId, recipeId: id });
      if (existing) {
        await favoritesCol.deleteOne({ _id: existing._id });
        return false;
      }
      await favoritesCol.insertOne({
        userId,
        recipeId: id,
        createdAt: new Date(),
      } as OptionalUnlessRequiredId<FavoriteDoc>);
      return true;
    },
    rateRecipe: async (
      _parent: unknown,
      { recipeId, value }: { recipeId: string; value: number },
      { db, user }: Ctx,
    ) => {
      const current = requireAuth(user);
      const id = recipeId.trim();
      if (id.length === 0) {
        throw new GraphQLError("recipeId is required", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      const ratingValue = Math.round(value);
      if (ratingValue < 1 || ratingValue > 5) {
        throw new GraphQLError("Rating must be between 1 and 5", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      await ensureRecipeExists(db, id);
      const ratingsCol = db.collection<RatingDoc>("ratings");
      const userId = new ObjectId(current.id);
      const now = new Date();
      await ratingsCol.updateOne(
        { userId, recipeId: id },
        {
          $set: { value: ratingValue, updatedAt: now },
          $setOnInsert: { createdAt: now },
        },
        { upsert: true },
      );
      return getRecipeRatingStats(db, id);
    },
    addComment: async (
      _parent: unknown,
      { recipeId, body }: { recipeId: string; body: string },
      { db, user }: Ctx,
    ) => {
      const current = requireAuth(user);
      const id = recipeId.trim();
      if (id.length === 0) {
        throw new GraphQLError("recipeId is required", {
          extensions: { code: "BAD_USER_INPUT" },
        });
      }
      const text = sanitizeComment(body ?? "");
      if (
        text.length < MIN_COMMENT_LENGTH ||
        text.length > MAX_COMMENT_LENGTH
      ) {
        throw new GraphQLError(
          `Comment must be between ${MIN_COMMENT_LENGTH} and ${MAX_COMMENT_LENGTH} characters`,
          { extensions: { code: "BAD_USER_INPUT" } },
        );
      }
      await ensureRecipeExists(db, id);
      const commentsCol = db.collection<CommentDoc>("comments");
      const userId = new ObjectId(current.id);
      const existing = await commentsCol.findOne({ recipeId: id, userId });
      if (existing) {
        throw new GraphQLError(
          "You have already left a review for this recipe. Delete it to share another one.",
          {
            extensions: { code: "BAD_USER_INPUT" },
          },
        );
      }
      const now = new Date();
      const ratingValue = await fetchMyRatingValue(db, userId, id);
      const insert = await commentsCol.insertOne({
        userId,
        recipeId: id,
        body: text,
        createdAt: now,
        updatedAt: now,
        rating: ratingValue ?? null,
      } as OptionalUnlessRequiredId<CommentDoc>);
      return {
        id: insert.insertedId.toString(),
        recipeId: id,
        body: text,
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
        user: current,
        rating: ratingValue,
      };
    },
    deleteMyComment: async (
      _parent: unknown,
      { commentId }: { commentId: string },
      { db, user }: Ctx,
    ) => {
      const current = requireAuth(user);
      const commentObjectId = ensureObjectId(commentId);
      const commentsCol = db.collection<CommentDoc>("comments");
      const existing = await commentsCol.findOne({ _id: commentObjectId });
      if (!existing) {
        return false;
      }
      if (existing.userId.toString() !== current.id) {
        throw new GraphQLError("You can only delete your own comments", {
          extensions: { code: "FORBIDDEN" },
        });
      }
      await commentsCol.deleteOne({ _id: existing._id });
      return true;
    },
  },
  Recipe: {
    averageRating: (
      recipe: { id: string } & RecipeWithRatingCache,
      _args: unknown,
      { db }: Ctx,
    ) => getCachedRatingStats(recipe, db).then((result) => result.average),
    ratingCount: (
      recipe: { id: string } & RecipeWithRatingCache,
      _args: unknown,
      { db }: Ctx,
    ) => getCachedRatingStats(recipe, db).then((result) => result.count),
    isFavorite: async (
      recipe: { id: string },
      _args: unknown,
      { db, user }: Ctx,
    ) => {
      if (!user) return false;
      return fetchFavoriteState(db, new ObjectId(user.id), recipe.id);
    },
    myRating: async (
      recipe: { id: string },
      _args: unknown,
      { db, user }: Ctx,
    ) => {
      if (!user) return null;
      return fetchMyRatingValue(db, new ObjectId(user.id), recipe.id);
    },
    comments: (
      recipe: { id: string },
      _args: unknown,
      { commentsLoader }: Ctx,
    ) => {
      const trimmedId = recipe.id.trim();
      if (trimmedId.length === 0) {
        return [];
      }
      return commentsLoader.load(trimmedId);
    },
  },
  Comment: {
    user: (comment: CommentResult) => comment.user,
    rating: (comment: CommentResult) => comment.rating ?? null,
  },
};
