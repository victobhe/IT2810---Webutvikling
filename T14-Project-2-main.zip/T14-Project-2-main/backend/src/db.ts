import { MongoClient, Db } from "mongodb";

let client: MongoClient | null = null;
let db: Db | null = null;

// Validate required env vars
function validateEnv() {
  const required = ["MONGO_URI", "MONGO_DB"];
  const missing = required.filter((key) => !process.env[key]);
  if (missing.length > 0) {
    throw new Error(
      `Missing required environment variables: ${missing.join(", ")}`,
    );
  }
}

export async function getDb(): Promise<Db> {
  if (db) return db;

  validateEnv();

  const uri = process.env.MONGO_URI!;
  const dbName = process.env.MONGO_DB!;

  try {
    client = new MongoClient(uri);
    await client.connect();
    console.log("Connected to MongoDB");

    // Test the connection
    await client.db(dbName).command({ ping: 1 });
    console.log("MongoDB connection validated");

    db = client.db(dbName);
    return db;
  } catch (err) {
    console.error("Failed to connect to MongoDB:", err);
    throw err;
  }
}

export async function closeDb() {
  if (client) {
    try {
      await client.close();
      console.log("MongoDB connection closed");
      client = null;
      db = null;
    } catch (err) {
      console.error("Error closing MongoDB connection:", err);
      throw err;
    }
  }
}
