import { gql } from "graphql-tag";

export const typeDefs = gql`
  type User {
    id: ID!
    email: String!
    name: String
  }

  type Comment {
    id: ID!
    recipeId: ID!
    body: String!
    createdAt: String!
    updatedAt: String!
    user: User!
    rating: Int
  }

  type UserProfileStats {
    favorites: Int!
    comments: Int!
  }

  type UserProfileComment {
    id: ID!
    body: String!
    createdAt: String!
    updatedAt: String!
    rating: Int
    recipe: Recipe!
  }

  type UserProfile {
    user: User!
    stats: UserProfileStats!
    favorites: [Recipe!]!
    favoritesHasMore: Boolean!
    comments: [UserProfileComment!]!
    commentsHasMore: Boolean!
  }

  type RecipeRating {
    recipeId: ID!
    average: Float!
    count: Int!
  }

  type RecipeUserState {
    isFavorite: Boolean!
    myRating: Int
  }

  type Recipe {
    id: ID!
    title: String!
    time: Int
    vegetarian: Boolean
    glutenFree: Boolean
    difficulty: String
    category: String
    area: String
    source: String
    youtube: String
    image: String
    instructions: String
    ingredients: [String!]
    steps: [String!]
    averageRating: Float!
    ratingCount: Int!
    isFavorite: Boolean!
    myRating: Int
    comments: [Comment!]!
  }

  type PageInfo {
    endCursor: String
    hasNextPage: Boolean
    totalCount: Int
  }

  type RecipeConnection {
    items: [Recipe!]!
    pageInfo: PageInfo!
  }

  input RecipeFiltersInput {
    q: String
    category: String
    area: String
    vegetarian: Boolean
    glutenFree: Boolean
    difficulty: [String!]
    favorites: Boolean
    searchIngredients: Boolean
  }

  input SortInput {
    field: String
    direction: String
  }

  input UpdateProfileInput {
    name: String
    email: String
  }

  type AuthPayload {
    user: User!
    token: String
  }

  type Query {
    me: User
    myProfile(favoritesLimit: Int = 25, commentsLimit: Int = 25): UserProfile!
    recipes(
      search: String
      filters: RecipeFiltersInput
      sort: SortInput
      after: String
      first: Int
    ): RecipeConnection
    recipe(id: ID!): Recipe
    recipeUserState(recipeId: ID!): RecipeUserState!
    recipeRating(recipeId: ID!): RecipeRating!
    comments(recipeId: ID!, first: Int = 20, after: ID): [Comment!]!
  }

  type Mutation {
    signup(email: String!, password: String!, name: String): AuthPayload!
    login(email: String!, password: String!): AuthPayload!
    logout: Boolean!
    updateMyProfile(input: UpdateProfileInput!): User!
    changeMyPassword(currentPassword: String!, newPassword: String!): Boolean!
    deleteMyAccount(password: String!): Boolean!
    toggleFavorite(recipeId: ID!): Boolean!
    rateRecipe(recipeId: ID!, value: Int!): RecipeRating!
    addComment(recipeId: ID!, body: String!): Comment!
    deleteMyComment(commentId: ID!): Boolean!
  }
`;
