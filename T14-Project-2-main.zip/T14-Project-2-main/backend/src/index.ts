import "dotenv/config";
import express, {
  type NextFunction,
  type Request,
  type Response,
  type RequestHandler,
} from "express";
import cors from "cors";
import bodyParser from "body-parser";
import { ApolloServer } from "@apollo/server";
import { expressMiddleware } from "@apollo/server/express4";
import { typeDefs } from "./schema.ts";
import { resolvers, createCommentsLoader } from "./resolvers.ts";
import type { Ctx } from "./resolvers.ts";
import { getDb, closeDb } from "./db.ts";
import path from "path";
import { fileURLToPath } from "url";
import { config } from "dotenv";
import { ApolloServerPluginLandingPageLocalDefault } from "@apollo/server/plugin/landingPage/default";
import cookieParser from "cookie-parser";
import { getUserFromRequest } from "./auth.ts";
import type { ExpressContextFunctionArgument } from "@apollo/server/express4";

// ESM __dirname shim
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

config({ path: path.resolve(__dirname, "../.env") });

// Validate env
const HOST = process.env.HOST ?? "0.0.0.0";
const PORT = Number(process.env.PORT ?? 3001);
const NODE_ENV = process.env.NODE_ENV ?? "development";

const ENABLE_GRAPHQL_PLAYGROUND = NODE_ENV !== "production";

// Basic request logging middleware
const requestLogger = (req: Request, res: Response, next: NextFunction) => {
  console.log(`${req.method} ${req.url}`);
  next();
};

const parseOrigins = (value?: string | null) => {
  if (!value) return [];
  return value
    .split(",")
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);
};

async function start() {
  try {
    // Initialize Express
    const app = express();

    // Add request logging in development
    if (NODE_ENV === "development") {
      app.use(requestLogger);
    }

    const allowedOrigins = Array.from(
      new Set([
        ...parseOrigins(process.env.CORS_ORIGINS),
        ...parseOrigins(process.env.CLIENT_ORIGIN ?? process.env.FRONTEND_URL),
        "http://localhost:5173",
        "http://127.0.0.1:5173",
      ]),
    );

    app.use(
      cors({
        origin: (origin, callback) => {
          if (!origin) return callback(null, true);
          const isAllowed = allowedOrigins.includes(origin);
          if (!isAllowed) {
            console.warn(`CORS blocked request from origin: ${origin}`);
          }
          callback(null, isAllowed);
        },
        credentials: true,
      }),
    );
    app.use(bodyParser.json({ limit: "10mb" }));
    app.use(cookieParser());

    // Test DB connection early
    await getDb();

    // Static files
    const publicDir =
      process.env.PUBLIC_DIR ?? path.join(__dirname, "..", "public");
    const uploadsDir =
      process.env.UPLOADS_DIR ?? path.join(publicDir, "uploads");

    app.use(express.static(publicDir));
    app.use("/uploads", express.static(uploadsDir));

    // Health check with DB status
    app.get("/health", async (_req: Request, res: Response) => {
      try {
        const db = await getDb();
        await db.command({ ping: 1 });
        res.json({ status: "healthy", mongo: "connected" });
      } catch (err) {
        console.log("Health check failed:", err);
        res.status(500).json({ status: "unhealthy", mongo: "disconnected" });
      }
    });

    // Setup Apollo Server
    const server = new ApolloServer<Ctx>({
      typeDefs,
      resolvers,
      introspection: ENABLE_GRAPHQL_PLAYGROUND,
      plugins: ENABLE_GRAPHQL_PLAYGROUND
        ? [ApolloServerPluginLandingPageLocalDefault()]
        : [],
    });
    await server.start();

    const graphqlMiddleware: RequestHandler = expressMiddleware<Ctx>(server, {
      context: async ({ req, res }: ExpressContextFunctionArgument) => {
        const db = await getDb();
        const typedReq = req as unknown as Request;
        const typedRes = res as unknown as Response;
        const user = await getUserFromRequest(typedReq, db);
        return {
          db,
          req: typedReq,
          res: typedRes,
          user,
          commentsLoader: createCommentsLoader(db),
        };
      },
    }) as unknown as RequestHandler;

    app.use("/graphql", graphqlMiddleware);

    // SPA fallback - must be after API routes
    app.get("*", (_req, res) => {
      res.sendFile(path.join(publicDir, "index.html"));
    });

    // Start server
    const httpServer = app.listen(PORT, HOST, () => {
      console.log(
        `Server running in ${NODE_ENV} mode at http://${HOST}:${PORT}/`,
      );
    });

    // Error handling
    httpServer.on("error", (err: NodeJS.ErrnoException) => {
      if (err?.code === "EADDRINUSE") {
        console.error(`Port ${PORT} is already in use`);
        process.exit(1);
      }
      console.error("Server error:", err);
    });

    // Graceful shutdown
    const shutdown = async (signal: string) => {
      console.log(`\n${signal} received. Starting graceful shutdown...`);

      // Close HTTP server first to stop accepting new requests
      httpServer.close(() => console.log("HTTP server closed"));

      try {
        await server.stop();
        console.log("Apollo server stopped");

        await closeDb();
        console.log("Database connections closed");

        process.exit(0);
      } catch (err) {
        console.error("Error during shutdown:", err);
        process.exit(1);
      }
    };

    process.on("SIGTERM", () => shutdown("SIGTERM"));
    process.on("SIGINT", () => shutdown("SIGINT"));
  } catch (err) {
    console.error("Failed to start server:", err);
    process.exit(1);
  }
}

// Start the application
start().catch((err) => {
  console.error("Unhandled error during startup:", err);
  process.exit(1);
});
