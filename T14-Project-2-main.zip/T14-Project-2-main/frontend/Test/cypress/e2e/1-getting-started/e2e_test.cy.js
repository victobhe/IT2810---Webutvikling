/// <reference types="cypress" />

const recipeListItems = [
  {
    id: "rec-1",
    title: "Autumn Delight",
    time: 75,
    vegetarian: true,
    glutenFree: false,
    difficulty: "MEDIUM",
    category: "4 servings",
    area: "Nordic",
    image: "/assets/logo.webp",
    averageRating: 4.4,
    ratingCount: 10,
    isFavorite: false,
  },
  {
    id: "rec-2",
    title: "Crispy Harvest Bites",
    time: 30,
    vegetarian: false,
    glutenFree: true,
    difficulty: "EASY",
    category: "Snacks",
    area: "American",
    image: "/assets/logo.webp",
    averageRating: 3.9,
    ratingCount: 6,
    isFavorite: true,
  },
];

const detailRecipe = {
  ...recipeListItems[0],
  instructions:
    "Roast the squash, simmer the broth, then blend everything until silky.",
  ingredients: ["2 cups roasted squash", "1 tbsp olive oil", "Salt and pepper"],
  steps: ["Prep ingredients", "Roast until golden", "Blend and serve"],
  source: "https://example.com/autumn-delight",
  averageRating: 4.4,
  ratingCount: 10,
  myRating: null,
  comments: [
    {
      id: "comment-existing",
      recipeId: "rec-1",
      body: "This recipe is incredible!",
      createdAt: "2024-09-01T12:00:00.000Z",
      updatedAt: "2024-09-01T12:00:00.000Z",
      user: { id: "guest-1", name: "Food Fan", email: "fan@example.com" },
    },
  ],
};

const recipesResponse = {
  data: {
    recipes: {
      items: recipeListItems,
      pageInfo: {
        endCursor: null,
        hasNextPage: false,
        totalCount: recipeListItems.length,
      },
    },
  },
};

const authUser = {
  id: "user-123",
  name: "Chef Cypress",
  email: "chef@example.com",
};

const PLACEHOLDER_IMAGE = "/assets/logo.webp";

const commentsResponse = {
  data: {
    comments: detailRecipe.comments,
  },
};

const browsingPageOneItems = Array.from({ length: 24 }, (_, index) => ({
  id: `browse-${index + 1}`,
  title: `Dish ${index + 1}`,
  time: 20 + index,
  vegetarian: index % 2 === 0,
  glutenFree: index % 3 === 0,
  difficulty: index % 2 === 0 ? "EASY" : "MEDIUM",
  category: "Dinner",
  area: index % 2 === 0 ? "Nordic" : "Asian",
  image: PLACEHOLDER_IMAGE,
  averageRating: 3.5 + (index % 2),
  ratingCount: 5 + index,
  isFavorite: index % 5 === 0,
}));

const browsingPageTwoItems = [
  {
    id: "browse-25",
    title: "Garden Salad",
    time: 15,
    vegetarian: true,
    glutenFree: true,
    difficulty: "EASY",
    category: "Salad",
    area: "Nordic",
    image: PLACEHOLDER_IMAGE,
    averageRating: 3.9,
    ratingCount: 3,
    isFavorite: false,
  },
  {
    id: "browse-26",
    title: "Festive Roast",
    time: 60,
    vegetarian: false,
    glutenFree: false,
    difficulty: "HARD",
    category: "Dinner",
    area: "American",
    image: PLACEHOLDER_IMAGE,
    averageRating: 4.0,
    ratingCount: 8,
    isFavorite: true,
  },
];

const BROWSING_PAGE_ONE_COUNT = browsingPageOneItems.length;
const TOTAL_BROWSING_COUNT =
  browsingPageOneItems.length + browsingPageTwoItems.length;

const browsingPageOneResponse = {
  data: {
    recipes: {
      items: browsingPageOneItems,
      pageInfo: {
        endCursor: "cursor-page-1",
        hasNextPage: true,
        totalCount: TOTAL_BROWSING_COUNT,
      },
    },
  },
};

const browsingPageTwoResponse = {
  data: {
    recipes: {
      items: browsingPageTwoItems,
      pageInfo: {
        endCursor: null,
        hasNextPage: false,
        totalCount: TOTAL_BROWSING_COUNT,
      },
    },
  },
};

const searchSoupResponse = {
  data: {
    recipes: {
      items: [
        {
          id: "search-1",
          title: "Soup Supreme",
          time: 50,
          vegetarian: false,
          glutenFree: true,
          difficulty: "HARD",
          category: "Soup",
          area: "Nordic",
          image: PLACEHOLDER_IMAGE,
          averageRating: 4.9,
          ratingCount: 22,
          isFavorite: true,
        },
      ],
      pageInfo: {
        endCursor: null,
        hasNextPage: false,
        totalCount: 1,
      },
    },
  },
};

const filteredRecipesResponse = {
  data: {
    recipes: {
      items: [
        {
          id: "filter-1",
          title: "Nordic Herb Stew",
          time: 30,
          vegetarian: true,
          glutenFree: true,
          difficulty: "EASY",
          category: "Dinner",
          area: "Nordic",
          image: PLACEHOLDER_IMAGE,
          averageRating: 4.2,
          ratingCount: 5,
          isFavorite: true,
        },
      ],
      pageInfo: {
        endCursor: null,
        hasNextPage: false,
        totalCount: 1,
      },
    },
  },
};

const emptySearchResponse = {
  data: {
    recipes: {
      items: [],
      pageInfo: {
        endCursor: null,
        hasNextPage: false,
        totalCount: 0,
      },
    },
  },
};

const resetApolloStore = () =>
  cy.window().then((win) => {
    const client = win.__APOLLO_CLIENT__;
    if (client?.resetStore) {
      return client.resetStore();
    }
    return null;
  });

describe("Cookbook end-to-end flow", () => {
  let currentUser = null;
  let shouldFailRating = false;

  const removeOverlays = () =>
    cy.window().then((win) => {
      const overlays = win.document.querySelectorAll(".modal-overlay");
      overlays.forEach((node) => node.parentElement?.removeChild(node));
    });

  const closeAnyModal = () =>
    cy.get("body").then(($body) => {
      const overlays = $body.find(".modal-overlay");
      if (overlays.length > 0) {
        cy.get(".modal__close").click({ force: true });
        cy.get(".modal-overlay").should("not.exist");
      } else {
        removeOverlays();
      }
    });

  beforeEach(() => {
    currentUser = null;
    shouldFailRating = false;
    closeAnyModal();

    cy.intercept("POST", "**/graphql", (req) => {
      const operation = req.body?.operationName;

      switch (operation) {
        case "Me": {
          req.alias = "gqlMe";
          req.reply({ data: { me: currentUser } });
          return;
        }
        case "Recipes": {
          const vars = req.body?.variables ?? {};
          const searchTerm =
            typeof vars.search === "string"
              ? vars.search.trim().toLowerCase()
              : "";
          const filters = vars.filters ?? {};
          const first = typeof vars.first === "number" ? vars.first : undefined;

          if (vars.after === "cursor-page-1") {
            req.alias = "gqlRecipesPage2";
            req.reply(browsingPageTwoResponse);
            return;
          }

          if (searchTerm === "soup") {
            req.alias = "gqlRecipesSearch";
            req.reply(searchSoupResponse);
            return;
          }
          if (searchTerm === "noresults") {
            req.alias = "gqlRecipesEmpty";
            req.reply(emptySearchResponse);
            return;
          }

          if (
            filters.vegetarian ||
            filters.favorites ||
            filters.searchIngredients ||
            (typeof filters.area === "string" && filters.area.trim() !== "")
          ) {
            req.alias = "gqlRecipesFilters";
            req.reply(filteredRecipesResponse);
            return;
          }

          if (first === 3) {
            req.alias = "gqlRecipes";
            req.reply(recipesResponse);
            return;
          }

          if (
            (filters.searchIngredients ||
              filters.vegetarian ||
              filters.favorites ||
              filters.area) &&
            !searchTerm
          ) {
            req.alias = "gqlRecipesFilters";
            req.reply(filteredRecipesResponse);
            return;
          }

          req.alias = "gqlRecipes";
          req.reply(browsingPageOneResponse);
          return;
        }
        case "GetRecipe": {
          req.alias = "gqlRecipeDetail";
          req.reply({ data: { recipe: detailRecipe } });
          return;
        }
        case "GetComments": {
          req.alias = "gqlComments";
          req.reply(commentsResponse);
          return;
        }
        case "Login": {
          currentUser = authUser;
          req.alias = "gqlLogin";
          req.reply({
            data: { login: { user: authUser, token: "fake-token" } },
          });
          return;
        }
        case "RateRecipe": {
          req.alias = "gqlRateRecipe";
          if (shouldFailRating) {
            req.reply({ forceNetworkError: true });
            return;
          }
          const value = req.body?.variables?.value ?? 5;
          req.reply({
            data: {
              rateRecipe: {
                recipeId: detailRecipe.id,
                average: value,
                count: detailRecipe.ratingCount + 1,
              },
            },
          });
          return;
        }
        case "AddComment": {
          req.alias = "gqlAddComment";
          const body = req.body?.variables?.body ?? "";
          const timestamp = new Date().toISOString();
          req.reply({
            data: {
              addComment: {
                id: `comment-${Date.now()}`,
                recipeId: detailRecipe.id,
                body,
                createdAt: timestamp,
                updatedAt: timestamp,
                user: currentUser ?? authUser,
              },
            },
          });
          return;
        }
        default: {
          req.reply({ data: {} });
        }
      }
    });
  });

  const openFirstRecipe = () => {
    cy.visit("/");
    cy.wait("@gqlRecipes");
    cy.get("article.recipe-card").first().click();
    cy.wait("@gqlRecipeDetail");
    cy.wait("@gqlComments");
  };

  const ensureNoOverlay = () => {
    cy.window().then((win) => {
      const overlays = win.document.querySelectorAll(".modal-overlay");
      overlays.forEach((node) => node.parentElement?.removeChild(node));
    });
  };

  it("fetches recipes with images and renders detailed data", () => {
    cy.visit("/");
    cy.wait("@gqlRecipes")
      .its("response.body.data.recipes.items")
      .should("have.length", recipeListItems.length);

    cy.get("article.recipe-card").should("have.length", recipeListItems.length);
    cy.get("article.recipe-card")
      .first()
      .within(() => {
        cy.contains(recipeListItems[0].title).should("be.visible");
        cy.get("img").should("have.attr", "src", recipeListItems[0].image);
      });

    cy.get("article.recipe-card")
      .last()
      .within(() => {
        cy.contains(recipeListItems[1].title).should("be.visible");
        cy.get("img").should("have.attr", "src", recipeListItems[1].image);
      });

    cy.get("article.recipe-card").first().click();
    cy.wait("@gqlRecipeDetail");
    cy.wait("@gqlComments");
    cy.url().should("include", `/recipe/${detailRecipe.id}`);
    cy.contains("h1", detailRecipe.title).should("be.visible");
    cy.get(`img[alt="${detailRecipe.title}"]`).should(
      "have.attr",
      "src",
      detailRecipe.image,
    );
    cy.get(".ingredients__list li").should(
      "have.length",
      detailRecipe.ingredients.length,
    );
    cy.get(".ingredients__list li")
      .first()
      .within(() => {
        cy.contains(".ingredients__amount", "2 cups").should("be.visible");
        cy.contains("span", "roasted squash", { matchCase: false }).should(
          "be.visible",
        );
      });
    cy.contains(detailRecipe.comments[0].body).should("be.visible");
  });

  it("logs in, rates a recipe, and posts a comment", () => {
    openFirstRecipe();

    cy.get("#review-comment").should("have.attr", "readonly");
    cy.contains("button", "Submit review").should("be.enabled");
    cy.contains(detailRecipe.comments[0].body).should("be.visible");

    ensureNoOverlay();
    cy.contains("button", "Log in").first().click({ force: true });
    cy.get("#login-email").type(authUser.email);
    cy.get("#login-password").type("super-secret");
    cy.get("#login-email")
      .closest("form")
      .contains("button", "Log in")
      .click({ force: true });

    cy.wait("@gqlLogin");
    cy.contains("button", "Log out").should("be.visible");

    cy.get("#review-comment").should("not.have.attr", "readonly");
    cy.contains("button", "Submit review").should("be.enabled");

    cy.get('.review-stars [data-star-value="5"]').click();

    const newComment = "Cypress end-to-end approval!";
    cy.get("#review-comment").clear().type(newComment);
    cy.contains("button", "Submit review").click();
    cy.wait("@gqlRateRecipe")
      .its("request.body.variables")
      .should("deep.include", {
        recipeId: detailRecipe.id,
        value: 5,
      });
    cy.wait("@gqlAddComment")
      .its("request.body.variables")
      .should("deep.include", { recipeId: detailRecipe.id, body: newComment });
    cy.contains("article", newComment).should("exist");
    cy.contains(
      ".toast__message span",
      "Thanks for sharing your review!",
    ).should("be.visible");
  });

  it("shows rating error feedback when the backend rejects the mutation", () => {
    shouldFailRating = true;
    openFirstRecipe();
    ensureNoOverlay();
    cy.contains("button", "Log in").first().click({ force: true });
    cy.get("#login-email").type(authUser.email);
    cy.get("#login-password").type("super-secret");
    cy.get("#login-email")
      .closest("form")
      .contains("button", "Log in")
      .click({ force: true });
    cy.wait("@gqlLogin");
    cy.get('.review-stars [data-star-value="4"]')
      .should("not.be.disabled")
      .click();
    cy.get("#review-comment").clear().type("Rating should fail");
    cy.contains("button", "Submit review").click();
    cy.wait("@gqlRateRecipe");
    shouldFailRating = false;
  });

  it("supports searching, filtering, and paginating the recipe list", () => {
    currentUser = authUser;

    cy.visit("/recipes");
    cy.wait("@gqlRecipes");
    cy.get("#recipe-list article").should(
      "have.length",
      BROWSING_PAGE_ONE_COUNT,
    );

    cy.get("#search-recipes").clear().type("Soup");
    cy.wait("@gqlRecipesSearch")
      .its("request.body.variables")
      .should("deep.include", { search: "Soup" });
    cy.get("#recipe-list article")
      .should("have.length", 1)
      .first()
      .should("contain.text", "Soup Supreme");

    resetApolloStore();
    cy.visit("/recipes");
    cy.get("#search-recipes").clear();

    cy.get("#search-ingredients-toggle").check({ force: true });
    cy.wait("@gqlRecipesFilters");

    cy.contains("button", "Vegetarian").click();
    cy.wait("@gqlRecipesFilters");

    cy.contains("button", "Gluten-free").click();
    cy.wait("@gqlRecipesFilters");

    cy.get('button[aria-label="Toggle origin filters"]').click();
    cy.get(".filter-dropdown__menu").within(() => {
      cy.contains("button", "Nordic").click();
    });
    cy.wait("@gqlRecipesFilters");
    cy.get("#recipe-list article")
      .should("have.length", 1)
      .first()
      .should("contain.text", "Nordic Herb Stew");

    cy.contains("button", "Reset filters").click();
    cy.get('button[aria-label="Toggle origin filters"]').should(
      "contain.text",
      "All origins",
    );
    cy.get("#recipe-list article").should("have.length.at.least", 1);

    cy.get("#search-recipes").clear().type("NoResults").type("{enter}");
    cy.wait("@gqlRecipesEmpty");
    cy.contains(
      "p",
      "No exact matches. Showing recipes with relaxed filters: Searching all recipes.",
    ).should("be.visible");

    // resetApolloStore();
    // cy.visit("/recipes");
    // cy.wait("@gqlMe");
    // cy.wait("@gqlRecipes").its("response.body.data.recipes.pageInfo.hasNextPage").should("be.true");
    // // cy.contains("button", "Load more dishes").should("be.visible").click();
    // cy.wait("@gqlRecipesPage2");
    // cy.get("#recipe-list article").should("have.length", TOTAL_BROWSING_COUNT);
  });
});
