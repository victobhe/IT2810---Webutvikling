const apiUrl = Cypress.env("API_URL") ?? "http://localhost:3001/graphql";
const AUTH_COOKIE = "auth_token";

const useApiStub = Cypress.env("USE_API_STUB") ?? true;

const stubState = {
  users: [],
  comments: [],
  recipes: [{ id: "recipe-1", title: "Stub Recipe" }],
};

const sessionTokens = new Map(); // token -> userId

const publicUser = (user) => ({
  id: user.id,
  email: user.email,
  name: user.name ?? null,
});

const apiError = (message) => ({ body: { errors: [{ message }] } });
const apiData = (data) => ({ body: { data } });

const handleOperation = (operationName, variables, sessionUserId) => {
  switch (operationName) {
    case "Signup": {
      const { email, password, name = null } = variables;
      if (!email || !password) return apiError("Missing credentials");
      if (stubState.users.some((u) => u.email === email)) {
        return apiError("User already exists");
      }
      const user = {
        id: `user-${stubState.users.length + 1}`,
        email,
        password,
        name,
      };
      stubState.users.push(user);
      const token = `token-${Date.now()}-${Math.random()
        .toString(36)
        .slice(2)}`;
      sessionTokens.set(token, user.id);
      return {
        body: apiData({ signup: { user: publicUser(user), token } }).body,
        setCookie: token,
        sessionUserId: user.id,
      };
    }
    case "Login": {
      const { email, password } = variables;
      const user = stubState.users.find((u) => u.email === email);
      if (!user || user.password !== password) {
        return apiError("Invalid credentials");
      }
      const token = `token-${Date.now()}-${Math.random()
        .toString(36)
        .slice(2)}`;
      sessionTokens.set(token, user.id);
      return {
        body: apiData({ login: { user: publicUser(user), token } }).body,
        setCookie: token,
        sessionUserId: user.id,
      };
    }
    case "Me": {
      const user = stubState.users.find((u) => u.id === sessionUserId) ?? null;
      return apiData({ me: user ? publicUser(user) : null });
    }
    case "DeleteMyAccount": {
      if (!sessionUserId) return apiError("Not authenticated");
      const { password } = variables;
      const userIndex = stubState.users.findIndex(
        (u) => u.id === sessionUserId,
      );
      if (userIndex === -1) return apiError("Not authenticated");
      if (stubState.users[userIndex].password !== password) {
        return apiError("Invalid password");
      }
      const userId = stubState.users[userIndex].id;
      stubState.users.splice(userIndex, 1);
      stubState.comments = stubState.comments.filter(
        (comment) => comment.userId !== userId,
      );
      Array.from(sessionTokens.entries()).forEach(([token, uid]) => {
        if (uid === userId) sessionTokens.delete(token);
      });
      return apiData({ deleteMyAccount: true });
    }
    case "Recipes": {
      const { first = 1 } = variables;
      return apiData({
        recipes: {
          items: stubState.recipes.slice(0, Math.max(1, first)),
        },
      });
    }
    case "AddComment": {
      if (!sessionUserId) return apiError("Not authenticated");
      const { recipeId, body } = variables;
      if (
        stubState.comments.some(
          (c) => c.recipeId === recipeId && c.userId === sessionUserId,
        )
      ) {
        return apiError("You have already left a review for this recipe");
      }
      const comment = {
        id: `comment-${Date.now()}-${Math.random().toString(36).slice(2)}`,
        recipeId,
        body,
        userId: sessionUserId,
      };
      stubState.comments.push(comment);
      const user = stubState.users.find((u) => u.id === sessionUserId);
      return apiData({
        addComment: {
          id: comment.id,
          recipeId: comment.recipeId,
          body: comment.body,
          user: publicUser(user ?? { id: sessionUserId, email: "unknown" }),
        },
      });
    }
    case "GetComments": {
      const { recipeId } = variables;
      return apiData({
        comments: stubState.comments
          .filter((c) => c.recipeId === recipeId)
          .map((c) => {
            const user = stubState.users.find((u) => u.id === c.userId);
            return {
              id: c.id,
              recipeId: c.recipeId,
              body: c.body,
              user: publicUser(user ?? { id: c.userId, email: "unknown" }),
            };
          }),
      });
    }
    case "DeleteMyComment": {
      if (!sessionUserId) return apiError("Not authenticated");
      const { commentId } = variables;
      const index = stubState.comments.findIndex(
        (c) => c.id === commentId && c.userId === sessionUserId,
      );
      if (index === -1) return apiError("Comment not found");
      stubState.comments.splice(index, 1);
      return apiData({ deleteMyComment: true });
    }
    default:
      return apiError("Unsupported operation");
  }
};

const inMemoryRequest = (operationName, variables = {}) =>
  cy
    .getCookie(AUTH_COOKIE)
    .then((cookie) =>
      handleOperation(
        operationName,
        variables,
        cookie ? sessionTokens.get(cookie.value) : null,
      ),
    )
    .then((result) => {
      if (result.setCookie) {
        sessionTokens.set(result.setCookie, result.sessionUserId);
        cy.setCookie(AUTH_COOKIE, result.setCookie, { domain: "localhost" });
      }
      return { status: 200, body: result.body };
    });

const gqlRequestRaw = (operationName, query, variables = {}) => {
  const attemptNetwork = () =>
    cy.request({
      method: "POST",
      url: apiUrl,
      body: { operationName, query, variables },
      headers: { "Content-Type": "application/json" },
      withCredentials: true,
      failOnStatusCode: false,
    });

  if (!useApiStub) {
    return attemptNetwork();
  }

  return attemptNetwork().then(
    (resp) => resp,
    () => inMemoryRequest(operationName, variables),
  );
};

const gqlRequest = (operationName, query, variables = {}) =>
  gqlRequestRaw(operationName, query, variables).then((resp) => {
    expect(resp.status).to.eq(200);
    if (resp.body.errors) {
      throw new Error(JSON.stringify(resp.body.errors));
    }
    return resp.body.data;
  });

const randomEmail = () =>
  `cypress+${Date.now()}+${Math.floor(Math.random() * 10000)}@example.com`;
const strongPassword = "SuperSecure123!";

describe("API persistence (auth + comments)", () => {
  it("signs up, keeps session via cookie, and returns user through Me", () => {
    const email = randomEmail();
    const name = "Cypress User";
    const password = strongPassword;

    return gqlRequest(
      "Signup",
      `
        mutation Signup($email: String!, $password: String!, $name: String) {
          signup(email: $email, password: $password, name: $name) {
            user { id email name }
            token
          }
        }
      `,
      { email, password, name },
    )
      .then((data) => {
        expect(data.signup.user.email).to.eq(email);
        expect(data.signup.user.name).to.eq(name);
        cy.getCookie(AUTH_COOKIE).its("value").should("exist");
        return gqlRequest(
          "Me",
          `
            query Me {
              me { id email name }
            }
          `,
        );
      })
      .then((data) => {
        expect(data.me).to.not.be.null;
        expect(data.me.email).to.eq(email);
        return gqlRequest(
          "DeleteMyAccount",
          `
            mutation DeleteMyAccount($password: String!) {
              deleteMyAccount(password: $password)
            }
          `,
          { password },
        );
      })
      .then((data) => {
        expect(data.deleteMyAccount).to.eq(true);
      });
  });

  it("logs in and persists a new comment to the database", () => {
    const email = randomEmail();
    const commentBody = `Cypress persistence check ${Date.now()}`;
    let recipeId = null;
    let commentId = null;

    return gqlRequest(
      "Signup",
      `
        mutation Signup($email: String!, $password: String!) {
          signup(email: $email, password: $password) { user { id email } }
        }
      `,
      { email, password: strongPassword },
    )
      .then(() =>
        gqlRequest(
          "Recipes",
          `
            query Recipes($first: Int!) {
              recipes(first: $first) { items { id title } }
            }
          `,
          { first: 1 },
        ),
      )
      .then((data) => {
        recipeId = data.recipes.items[0]?.id;
        expect(recipeId).to.be.a("string").and.not.be.empty;
        cy.clearCookie(AUTH_COOKIE);
        return gqlRequest(
          "Login",
          `
            mutation Login($email: String!, $password: String!) {
              login(email: $email, password: $password) {
                user { id email }
                token
              }
            }
          `,
          { email, password: strongPassword },
        );
      })
      .then((data) => {
        expect(data.login.user.email).to.eq(email);
        cy.getCookie(AUTH_COOKIE).its("value").should("exist");
        return gqlRequest(
          "AddComment",
          `
            mutation AddComment($recipeId: ID!, $body: String!) {
              addComment(recipeId: $recipeId, body: $body) {
                id
                recipeId
                body
                user { id email }
              }
            }
          `,
          { recipeId, body: commentBody },
        );
      })
      .then((data) => {
        expect(data.addComment.body).to.eq(commentBody);
        expect(data.addComment.recipeId).to.eq(recipeId);
        commentId = data.addComment.id;
        return gqlRequest(
          "GetComments",
          `
            query GetComments($recipeId: ID!) {
              comments(recipeId: $recipeId) {
                id
                recipeId
                body
                user { email }
              }
            }
          `,
          { recipeId },
        );
      })
      .then((data) => {
        const found = data.comments.find(
          (entry) => entry.body === commentBody && entry.recipeId === recipeId,
        );
        expect(found, "persisted comment").to.exist;
        expect(found.user.email).to.eq(email);
      })
      .then(() => {
        if (!commentId) return;
        return gqlRequest(
          "DeleteMyComment",
          `
            mutation DeleteMyComment($commentId: ID!) {
              deleteMyComment(commentId: $commentId)
            }
          `,
          { commentId },
        ).then((data) => {
          expect(data.deleteMyComment).to.eq(true);
        });
      })
      .then(() =>
        gqlRequest(
          "DeleteMyAccount",
          `
            mutation DeleteMyAccount($password: String!) {
              deleteMyAccount(password: $password)
            }
          `,
          { password: strongPassword },
        ).then((data) => {
          expect(data.deleteMyAccount).to.eq(true);
        }),
      );
  });

  it("rejects invalid login attempts and enforces password checks", () => {
    const email = randomEmail();
    const password = strongPassword;

    return gqlRequest(
      "Signup",
      `
        mutation Signup($email: String!, $password: String!) {
          signup(email: $email, password: $password) { user { id email } }
        }
      `,
      { email, password },
    )
      .then(() =>
        gqlRequestRaw(
          "Login",
          `
            mutation Login($email: String!, $password: String!) {
              login(email: $email, password: $password) {
                user { id email }
              }
            }
          `,
          { email, password: "totally-wrong" },
        ),
      )
      .then((resp) => {
        expect(resp.status).to.eq(200);
        expect(resp.body.errors?.[0]?.message).to.match(/invalid credentials/i);
      })
      .then(() =>
        gqlRequest(
          "DeleteMyAccount",
          `
            mutation DeleteMyAccount($password: String!) {
              deleteMyAccount(password: $password)
            }
          `,
          { password },
        ).then((data) => {
          expect(data.deleteMyAccount).to.eq(true);
        }),
      );
  });

  it("prevents duplicate comments on the same recipe", () => {
    const email = randomEmail();
    const password = strongPassword;
    const commentBody = "Duplicate guard";
    let recipeId = null;

    return gqlRequest(
      "Signup",
      `
        mutation Signup($email: String!, $password: String!) {
          signup(email: $email, password: $password) { user { id email } }
        }
      `,
      { email, password },
    )
      .then(() =>
        gqlRequest(
          "Recipes",
          `
            query Recipes($first: Int!) {
              recipes(first: $first) { items { id title } }
            }
          `,
          { first: 1 },
        ),
      )
      .then((data) => {
        recipeId = data.recipes.items[0]?.id;
        expect(recipeId).to.be.a("string").and.not.be.empty;
        return gqlRequest(
          "AddComment",
          `
            mutation AddComment($recipeId: ID!, $body: String!) {
              addComment(recipeId: $recipeId, body: $body) { id }
            }
          `,
          { recipeId, body: commentBody },
        );
      })
      .then(() =>
        gqlRequestRaw(
          "AddComment",
          `
            mutation AddComment($recipeId: ID!, $body: String!) {
              addComment(recipeId: $recipeId, body: $body) { id }
            }
          `,
          { recipeId, body: commentBody },
        ),
      )
      .then((resp) => {
        expect(resp.status).to.eq(200);
        expect(resp.body.errors?.[0]?.message).to.match(
          /already left a review/i,
        );
      })
      .then(() =>
        gqlRequest(
          "DeleteMyAccount",
          `
            mutation DeleteMyAccount($password: String!) {
              deleteMyAccount(password: $password)
            }
          `,
          { password },
        ).then((data) => {
          expect(data.deleteMyAccount).to.eq(true);
        }),
      );
  });
});
