import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, expect, it, beforeEach, vi } from "vitest";
import AccountSettingsModal from "../../src/components/AccountSettingsModal";
import {
  UPDATE_MY_PROFILE_MUTATION,
  CHANGE_MY_PASSWORD_MUTATION,
  DELETE_MY_ACCOUNT_MUTATION,
} from "../../src/graphql/account";

const mockUseMutation = vi.hoisted(() => vi.fn());

vi.mock("@apollo/client", async () => {
  const actual =
    await vi.importActual<typeof import("@apollo/client")>("@apollo/client");
  return {
    ...actual,
    useMutation: mockUseMutation,
  };
});

vi.mock("react-dom", async () => {
  const actual = await vi.importActual<typeof import("react-dom")>("react-dom");
  return {
    ...actual,
    createPortal: (node: React.ReactNode) => node,
  };
});

const baseUser = {
  id: "user-1",
  email: "hello@example.com",
  name: "Taylor Tester",
};

const renderModal = (
  overrides: Partial<React.ComponentProps<typeof AccountSettingsModal>> = {},
) => {
  const props = {
    isOpen: true,
    onClose: vi.fn(),
    user: baseUser,
    onProfileUpdated: vi.fn(),
    onAccountDeleted: vi.fn(),
    ...overrides,
  };
  return {
    ...props,
    utils: render(<AccountSettingsModal {...props} />),
  };
};

const setupMutations = (mocks?: {
  updateProfile?: ReturnType<typeof vi.fn>;
  changePassword?: ReturnType<typeof vi.fn>;
  deleteAccount?: ReturnType<typeof vi.fn>;
}) => {
  const updateProfile =
    mocks?.updateProfile ?? vi.fn().mockResolvedValue({ data: {} });
  const changePassword =
    mocks?.changePassword ?? vi.fn().mockResolvedValue({ data: {} });
  const deleteAccount =
    mocks?.deleteAccount ?? vi.fn().mockResolvedValue({ data: {} });

  mockUseMutation.mockImplementation((mutation) => {
    if (mutation === UPDATE_MY_PROFILE_MUTATION) return [updateProfile, {}];
    if (mutation === CHANGE_MY_PASSWORD_MUTATION) return [changePassword, {}];
    if (mutation === DELETE_MY_ACCOUNT_MUTATION) return [deleteAccount, {}];
    return [vi.fn(), {}];
  });

  return { updateProfile, changePassword, deleteAccount };
};

beforeEach(() => {
  mockUseMutation.mockReset();
});

describe("AccountSettingsModal", () => {
  it("prefills profile fields and submits updates", async () => {
    const { updateProfile } = setupMutations();
    const { onProfileUpdated } = renderModal();

    expect(screen.getByLabelText("Name")).toHaveValue(baseUser.name);
    expect(screen.getByLabelText("Email")).toHaveValue(baseUser.email);

    fireEvent.change(screen.getByLabelText("Name"), {
      target: { value: "Updated Name" },
    });
    fireEvent.change(screen.getByLabelText("Email"), {
      target: { value: "edited@example.com  " },
    });
    fireEvent.click(screen.getByRole("button", { name: /save changes/i }));

    await waitFor(() =>
      expect(updateProfile).toHaveBeenCalledWith({
        variables: {
          input: { name: "Updated Name", email: "edited@example.com" },
        },
      }),
    );
    expect(onProfileUpdated).toHaveBeenCalled();
    expect(screen.getByText("Account details updated.")).toBeInTheDocument();
  });

  it("validates password confirmation and updates password when valid", async () => {
    const { changePassword } = setupMutations();
    renderModal();

    fireEvent.change(screen.getByLabelText("Current"), {
      target: { value: "oldpass" },
    });
    fireEvent.change(screen.getByLabelText("New"), {
      target: { value: "abc" },
    });
    fireEvent.change(screen.getByLabelText("Confirm"), {
      target: { value: "abcd" },
    });
    fireEvent.click(screen.getByRole("button", { name: /update password/i }));
    expect(screen.getByText("New passwords do not match.")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("New"), {
      target: { value: "newpass" },
    });
    fireEvent.change(screen.getByLabelText("Confirm"), {
      target: { value: "newpass" },
    });
    fireEvent.click(screen.getByRole("button", { name: /update password/i }));

    await waitFor(() =>
      expect(changePassword).toHaveBeenCalledWith({
        variables: { currentPassword: "oldpass", newPassword: "newpass" },
      }),
    );
    expect(screen.getByText("Password updated.")).toBeInTheDocument();
  });

  it("requires password for deletion and calls delete mutation after confirmation", async () => {
    const deleteAccount = vi.fn().mockResolvedValue({ data: {} });
    setupMutations({ deleteAccount });
    const { onAccountDeleted } = renderModal();

    const confirmSpy = vi.spyOn(window, "confirm").mockReturnValue(true);

    fireEvent.click(screen.getByRole("button", { name: /delete account/i }));
    expect(deleteAccount).not.toHaveBeenCalled();
    fireEvent.change(screen.getByLabelText("Password"), {
      target: { value: "secret-pass" },
    });
    fireEvent.click(screen.getByRole("button", { name: /delete account/i }));

    await waitFor(() =>
      expect(deleteAccount).toHaveBeenCalledWith({
        variables: { password: "secret-pass" },
      }),
    );
    expect(onAccountDeleted).toHaveBeenCalled();
    expect(confirmSpy).toHaveBeenCalled();
    confirmSpy.mockRestore();
  });
});
