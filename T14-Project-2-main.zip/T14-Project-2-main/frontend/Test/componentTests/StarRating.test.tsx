import { render, screen, fireEvent } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import StarRating from "../../src/components/starRating";

describe("StarRating", () => {
  it("renders the initial rating and updates on click", () => {
    const handleChange = vi.fn();
    render(<StarRating initialRating={2} onChange={handleChange} />);

    const starTwo = screen.getByRole("radio", { name: "2 stars out of 5" });
    expect(starTwo).toHaveAttribute("aria-checked", "true");

    const starFour = screen.getByRole("radio", { name: "4 stars out of 5" });
    fireEvent.click(starFour);

    expect(handleChange).toHaveBeenCalledWith(4);
    expect(starFour).toHaveAttribute("aria-checked", "true");
  });

  it("supports keyboard navigation for rating changes", () => {
    const handleChange = vi.fn();
    render(<StarRating initialRating={1} onChange={handleChange} />);

    const starOne = screen.getByRole("radio", { name: "1 star out of 5" });
    starOne.focus();
    fireEvent.keyDown(starOne, { key: "ArrowRight" });

    expect(handleChange).toHaveBeenCalledWith(2);

    fireEvent.keyDown(starOne, { key: "End" });
    expect(handleChange).toHaveBeenCalledWith(5);
  });

  it("renders read-only stars as aria-disabled", () => {
    render(<StarRating initialRating={3} isReadOnly />);

    const radios = screen.getAllByRole("radio");
    radios.forEach((radio) => {
      expect(radio).toHaveAttribute("aria-disabled", "true");
    });
  });

  it("notifies when interaction is blocked", () => {
    const handleBlocked = vi.fn();
    render(
      <StarRating
        initialRating={4}
        isReadOnly
        onBlockedAttempt={handleBlocked}
      />,
    );

    const star = screen.getByRole("radio", { name: "4 stars out of 5" });
    fireEvent.click(star);
    expect(handleBlocked).toHaveBeenCalled();
  });
});
