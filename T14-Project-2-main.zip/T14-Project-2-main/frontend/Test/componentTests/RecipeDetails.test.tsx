import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import {
  describe,
  expect,
  it,
  beforeEach,
  afterEach,
  beforeAll,
  afterAll,
  vi,
} from "vitest";
vi.mock("../../src/styles/recipeDetail.css", () => ({}), { virtual: true });

import RecipeDetails from "../../src/components/RecipeDetails";
import {
  TOGGLE_FAVORITE_MUTATION,
  RATE_RECIPE_MUTATION,
  ADD_COMMENT_MUTATION,
  DELETE_COMMENT_MUTATION,
} from "../../src/graphql/recipeActions";

const mockUseQuery = vi.hoisted(() => vi.fn());
const mockUseMutation = vi.hoisted(() => vi.fn());
const mockUseAuth = vi.hoisted(() => vi.fn());
const mockNavigate = vi.fn();

vi.mock("../../src/components/Header", () => ({
  default: () => <header data-testid="header-stub" />,
}));

vi.mock("@apollo/client", async () => {
  const actual =
    await vi.importActual<typeof import("@apollo/client")>("@apollo/client");
  return {
    ...actual,
    useQuery: mockUseQuery,
    useMutation: mockUseMutation,
  };
});

vi.mock("../../src/contexts/useAuth", () => ({
  useAuth: () => mockUseAuth(),
}));

vi.mock("react-router-dom", async () => {
  const actual =
    await vi.importActual<typeof import("react-router-dom")>(
      "react-router-dom",
    );
  return {
    ...actual,
    useNavigate: () => mockNavigate,
    useParams: () => ({ id: "recipe-1" }),
    useLocation: () => ({
      pathname: "/recipes/recipe-1",
      search: "",
      hash: "",
      state: undefined,
      key: "test",
    }),
  };
});

const baseRecipe = {
  id: "recipe-1",
  title: "Autumn Soup",
  time: 40,
  category: "Dinner",
  area: "Nordic",
  vegetarian: true,
  glutenFree: false,
  difficulty: "EASY",
  image: "https://example.com/soup.jpg",
  instructions: "Mix everything and simmer.",
  ingredients: ["1 cup pumpkin", "Salt to taste"],
  steps: ["Chop veggies", "Cook slowly"],
  source: "https://example.com/soup",
  averageRating: 4.5,
  ratingCount: 12,
  isFavorite: false,
  myRating: null,
};

const mockQueryResult = (recipeOverrides = {}, comments = []) => {
  const recipeResult = {
    data: { recipe: { ...baseRecipe, ...recipeOverrides } },
    loading: false,
    error: undefined,
    refetch: vi.fn(),
    fetchMore: vi.fn(),
  };
  const commentsResult = {
    data: { comments },
    loading: false,
    error: undefined,
    refetch: vi.fn(),
    fetchMore: vi.fn(),
  };
  mockUseQuery.mockImplementation(
    (_, options: { variables?: Record<string, unknown> } = {}) => {
      const vars = options.variables ?? {};
      if ("recipeId" in vars) {
        return commentsResult;
      }
      return recipeResult;
    },
  );
};

const buildAuthValue = () => ({
  user: null,
  openLogin: vi.fn(),
  logout: vi.fn(),
});

const completeAuthValue = (
  overrides?: Partial<ReturnType<typeof buildAuthValue>>,
) => ({
  ...buildAuthValue(),
  ...overrides,
});

type MutationOverrides = Partial<{
  toggle: ReturnType<typeof vi.fn>;
  rate: ReturnType<typeof vi.fn>;
  addComment: ReturnType<typeof vi.fn>;
  deleteComment: ReturnType<typeof vi.fn>;
}>;

const stubMutations = (overrides: MutationOverrides = {}) => {
  const toggle = overrides.toggle ?? vi.fn();
  const rate = overrides.rate ?? vi.fn();
  const addComment = overrides.addComment ?? vi.fn();
  const deleteComment = overrides.deleteComment ?? vi.fn();

  mockUseMutation.mockImplementation((document) => {
    if (document === TOGGLE_FAVORITE_MUTATION) return [toggle, {}];
    if (document === RATE_RECIPE_MUTATION) return [rate, {}];
    if (document === ADD_COMMENT_MUTATION)
      return [
        async (options) => {
          const result = await addComment(options);
          // Simulate Apollo calling the provided update function so the component state updates
          options?.update?.(
            { updateQuery: vi.fn() } as never,
            { data: result?.data } as never,
          );
          return result;
        },
        {},
      ];
    if (document === DELETE_COMMENT_MUTATION) return [deleteComment, {}];
    return [vi.fn(), {}];
  });

  return { toggle, rate, addComment, deleteComment };
};

const originalRAF = window.requestAnimationFrame;
const originalCancelRAF = window.cancelAnimationFrame;
const originalCSSStyleSheet = globalThis.CSSStyleSheet;
let replaceSyncSpy: ReturnType<typeof vi.spyOn> | null = null;

beforeAll(() => {
  if (
    originalCSSStyleSheet &&
    "replaceSync" in originalCSSStyleSheet.prototype
  ) {
    replaceSyncSpy = vi
      .spyOn(originalCSSStyleSheet.prototype, "replaceSync")
      .mockImplementation(() => {});
  } else {
    class FakeSheet {
      replaceSync() {}
    }
    globalThis.CSSStyleSheet = FakeSheet as unknown as typeof CSSStyleSheet;
  }
});

beforeEach(() => {
  mockUseQuery.mockReset();
  mockUseMutation.mockReset();
  mockUseAuth.mockReset();
  mockNavigate.mockReset();
  window.scrollTo = vi.fn();
  window.requestAnimationFrame = (cb: FrameRequestCallback) => {
    cb(0);
    return 0;
  };
  window.cancelAnimationFrame = () => {};
});

afterEach(() => {
  window.requestAnimationFrame = originalRAF;
  window.cancelAnimationFrame = originalCancelRAF;
});

afterAll(() => {
  replaceSyncSpy?.mockRestore();
  if (!originalCSSStyleSheet) {
    // eslint-disable-next-line @typescript-eslint/no-dynamic-delete
    delete (globalThis as { CSSStyleSheet?: typeof CSSStyleSheet })
      .CSSStyleSheet;
  } else {
    globalThis.CSSStyleSheet = originalCSSStyleSheet;
  }
});

describe("RecipeDetails", () => {
  it("renders recipe information and keeps review form read-only for guests", async () => {
    mockQueryResult();
    stubMutations();
    mockUseAuth.mockReturnValue(completeAuthValue());

    render(<RecipeDetails />);

    expect(
      await screen.findByRole("heading", { name: "Autumn Soup" }),
    ).toBeInTheDocument();
    expect(screen.getByAltText("Autumn Soup")).toHaveAttribute(
      "src",
      baseRecipe.image,
    );
    expect(screen.getByText(/Chop veggies/)).toBeInTheDocument();

    const commentField = screen.getByLabelText(/Your comments/);
    expect(commentField).toHaveAttribute("readonly");
    expect(
      screen.getByText(/Please log in to leave a review/i),
    ).toBeInTheDocument();
  });

  it("allows logged-in users to submit a new comment together with a rating", async () => {
    const addCommentMock = vi.fn().mockResolvedValue({
      data: {
        addComment: {
          id: "comment-1",
          recipeId: baseRecipe.id,
          body: "Fantastic dish!",
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          user: { id: "user-1", email: "chef@example.com", name: "Chef" },
          rating: null,
        },
      },
    });
    const rateRecipeMock = vi.fn().mockResolvedValue({
      data: {
        rateRecipe: {
          recipeId: baseRecipe.id,
          average: 5,
          count: 15,
        },
      },
    });
    mockQueryResult();
    stubMutations({ addComment: addCommentMock, rate: rateRecipeMock });
    mockUseAuth.mockReturnValue(
      completeAuthValue({
        user: { id: "user-1", email: "chef@example.com", name: "Chef" },
      }),
    );

    render(<RecipeDetails />);

    await screen.findByRole("heading", { name: "Autumn Soup" });

    const textarea = screen.getByLabelText(/Your comments/);
    expect(textarea).not.toHaveAttribute("readonly");
    const star = screen.getByRole("radio", { name: "4 stars out of 5" });
    fireEvent.click(star);
    fireEvent.change(textarea, { target: { value: "Fantastic dish!" } });
    fireEvent.click(screen.getByRole("button", { name: "Submit review" }));

    await waitFor(() =>
      expect(rateRecipeMock).toHaveBeenCalledWith(
        expect.objectContaining({
          variables: { recipeId: baseRecipe.id, value: 4 },
        }),
      ),
    );

    await waitFor(() =>
      expect(addCommentMock).toHaveBeenCalledWith(
        expect.objectContaining({
          variables: { recipeId: baseRecipe.id, body: "Fantastic dish!" },
        }),
      ),
    );

    expect(await screen.findByText("Fantastic dish!")).toBeInTheDocument();
    expect(textarea).toHaveValue("");
  });
});
