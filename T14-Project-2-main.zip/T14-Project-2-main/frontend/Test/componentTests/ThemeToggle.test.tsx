import { render, screen, fireEvent, act } from "@testing-library/react";
import { describe, expect, it, beforeEach, afterEach, vi } from "vitest";
import ThemeToggle from "../../src/components/ThemeToggle";

const STORAGE_KEY = "theme-preference";

const setupMatchMedia = () => {
  const listeners: Record<string, ((event: MediaQueryListEvent) => void)[]> =
    {};

  const mockList: MediaQueryList = {
    matches: false,
    media: "(prefers-color-scheme: dark)",
    onchange: null,
    addListener: vi.fn(),
    removeListener: vi.fn(),
    addEventListener: vi.fn((event, handler: EventListener) => {
      if (!listeners[event]) {
        listeners[event] = [];
      }
      listeners[event].push(handler as (evt: MediaQueryListEvent) => void);
    }),
    removeEventListener: vi.fn((event, handler: EventListener) => {
      listeners[event] = (listeners[event] ?? []).filter(
        (cb) => cb !== handler,
      );
    }),
    dispatchEvent: vi.fn((evt: Event) => {
      (listeners[evt.type] ?? []).forEach((cb) =>
        cb(evt as MediaQueryListEvent),
      );
      return true;
    }),
  };

  vi.spyOn(window, "matchMedia").mockImplementation(() => mockList);

  return mockList;
};

describe("ThemeToggle", () => {
  let originalRaf: typeof window.requestAnimationFrame;

  beforeEach(() => {
    vi.useFakeTimers();
    document.documentElement.dataset.theme = "";
    window.localStorage.clear();
    originalRaf = window.requestAnimationFrame;
    window.requestAnimationFrame = ((cb: FrameRequestCallback) => {
      cb(0);
      return 1;
    }) as typeof window.requestAnimationFrame;
  });

  afterEach(() => {
    window.requestAnimationFrame = originalRaf;
    vi.restoreAllMocks();
    vi.useRealTimers();
  });

  it("applies stored preference on mount and toggles theme/aria state on click", () => {
    window.localStorage.setItem(STORAGE_KEY, "dark");
    setupMatchMedia();

    render(<ThemeToggle />);

    expect(document.documentElement.dataset.theme).toBe("dark");
    const disableButton = screen.getByRole("button", {
      name: /disable dark mode/i,
    });
    expect(disableButton).toHaveAttribute("aria-pressed", "true");

    fireEvent.click(disableButton);
    vi.runAllTimers();

    const enableButton = screen.getByRole("button", {
      name: /enable dark mode/i,
    });
    expect(enableButton).toHaveAttribute("aria-pressed", "false");
    expect(document.documentElement.dataset.theme).toBe("light");
    expect(window.localStorage.getItem(STORAGE_KEY)).toBe("light");
  });

  it("subscribes to system preference changes when no stored choice exists", async () => {
    const mediaList = setupMatchMedia();
    render(<ThemeToggle />);

    const listenerArgs = mediaList.addEventListener.mock.calls.at(-1);
    expect(listenerArgs?.[0]).toBe("change");
    expect(typeof listenerArgs?.[1]).toBe("function");
    expect(document.documentElement.dataset.theme).toBe("light");

    window.localStorage.removeItem(STORAGE_KEY);

    const changeEvent = new Event("change") as MediaQueryListEvent;
    Object.defineProperty(changeEvent, "matches", { value: true });
    await act(async () => {
      mediaList.dispatchEvent(changeEvent);
      await Promise.resolve();
    });
    vi.runAllTimers();

    expect(document.documentElement.dataset.theme).toBe("dark");
    expect(window.localStorage.getItem(STORAGE_KEY)).toBe("dark");
  });

  it("ignores system preference changes once the user has stored a choice", () => {
    window.localStorage.setItem(STORAGE_KEY, "light");
    const mediaList = setupMatchMedia();

    render(<ThemeToggle />);

    const changeEvent = new Event("change") as MediaQueryListEvent;
    Object.defineProperty(changeEvent, "matches", { value: true });
    mediaList.dispatchEvent(changeEvent);
    vi.runAllTimers();

    expect(document.documentElement.dataset.theme).toBe("light");
  });
});
