import { render, screen, fireEvent } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import ListingCard, { type Listing } from "../../src/components/Card";

const baseListing: Listing = {
  id: "pumpkin-soup",
  title: "Pumpkin Soup",
  imageUrl: "https://via.placeholder.com/400x300?text=Pumpkin+Soup",
  rating: 4.2,
  price: "$12",
  location: "Autumn Kitchen",
  tags: ["30 min", "Vegetarian"],
};

describe("ListingCard", () => {
  it("renders the provided listing content", () => {
    render(<ListingCard item={baseListing} isFavorite />);

    expect(
      screen.getByRole("heading", { name: baseListing.title }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("img", { name: baseListing.title }),
    ).toHaveAttribute("src", baseListing.imageUrl);
    expect(screen.getByText("$12")).toBeInTheDocument();
    expect(screen.getByLabelText("Origin")).toHaveTextContent(
      baseListing.location as string,
    );
    expect(screen.getByText("4.2")).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /remove from favorites/i }),
    ).toHaveAttribute("aria-pressed", "true");
    expect(screen.getByRole("list", { name: "Tags" })).toHaveTextContent(
      baseListing.tags!.join(""),
    );
  });

  it("invokes callbacks when clicking the card and favorite button", () => {
    const onClick = vi.fn();
    const onFavoriteToggle = vi.fn();

    render(
      <ListingCard
        item={baseListing}
        onClick={onClick}
        onFavoriteToggle={onFavoriteToggle}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: /save to favorites/i }));
    expect(onFavoriteToggle).toHaveBeenCalledWith(baseListing.id);

    const cardLink = screen.getByRole("link", {
      name: `Open ${baseListing.title}`,
    });
    fireEvent.click(cardLink);
    expect(onClick).toHaveBeenCalledWith(baseListing.id);
  });

  it("falls back to default visuals when optional fields are missing", () => {
    render(
      <ListingCard
        item={{
          id: "fallback",
          title: "Fallback Recipe",
        }}
      />,
    );

    expect(screen.queryByText("$")).not.toBeInTheDocument();
    expect(screen.queryByLabelText("Tags")).not.toBeInTheDocument();
    expect(screen.queryByText(/4\.\d/)).not.toBeInTheDocument();
    expect(
      screen.getByRole("img", { name: "Fallback Recipe" }),
    ).toHaveAttribute("src", expect.stringContaining("logo.webp"));
  });
});
