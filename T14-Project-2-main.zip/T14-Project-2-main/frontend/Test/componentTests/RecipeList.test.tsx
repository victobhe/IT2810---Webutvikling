// Test/componentTests/RecipeList.test.tsx
import { render, screen, fireEvent } from "@testing-library/react";
import { describe, expect, it, vi, beforeEach } from "vitest";
import type { RecipesQueryData } from "../../src/graphql/recipes";

// 1) Viktig: hoist mock-variabelen slik at vi kan bruke den inne i vi.mock-fabrikken
const mockUseQuery = vi.hoisted(() => vi.fn());

// 2) Mock @apollo/client før imports brukes av komponenten
vi.mock("@apollo/client", async () => {
  const actual =
    await vi.importActual<typeof import("@apollo/client")>("@apollo/client");
  return {
    ...actual,
    useQuery: mockUseQuery, // trygg å referere pga vi.hoisted
  };
});

// 3) Mock graphql-modulen (f.eks. bytte ut GET_RECIPES)
vi.mock("../../src/graphql/recipes", async () => {
  const actual = await vi.importActual<
    typeof import("../../src/graphql/recipes")
  >("../../src/graphql/recipes");
  return {
    ...actual,
    GET_RECIPES: Symbol("GET_RECIPES"),
  };
});

// 4) Importér komponenten ETTER mockene
import RecipeList from "../../src/components/RecipeList";

const baseProps = {
  search: "",
  sort: { field: "TITLE" as const, direction: "ASC" as const },
  filters: {},
};

const makeData = (
  overrides: Partial<RecipesQueryData["recipes"]["items"][number]> = {},
): RecipesQueryData => {
  const id = overrides.id ?? "recipe-1";
  return {
    recipes: {
      items: [
        {
          id,
          title: "Pumpkin Soup",
          time: 45,
          vegetarian: true,
          glutenFree: false,
          difficulty: "EASY",
          category: "Soup",
          area: "Nordic",
          image: null,
          ...overrides,
        },
      ],
      pageInfo: {
        endCursor: "cursor",
        hasNextPage: false,
        totalCount: 1,
      },
    },
  };
};

beforeEach(() => {
  vi.clearAllMocks();
  mockUseQuery.mockReset();
});

describe("RecipeList", () => {
  it("renders recipes from the query response", () => {
    mockUseQuery.mockReturnValue({
      data: makeData(),
      loading: false,
      error: undefined,
      fetchMore: vi.fn(),
    });

    render(<RecipeList {...baseProps} />);

    expect(
      screen.getByRole("heading", { level: 3, name: "Pumpkin Soup" }),
    ).toBeInTheDocument();
    expect(screen.getByText(/45 min/i)).toBeInTheDocument();
    expect(screen.getByText(/EASY/)).toBeInTheDocument();

    // Sjekk at hooken kalles med forventede variabler
    const args = mockUseQuery.mock.calls.at(-1);
    expect(args?.[0]).toBeDefined();
    expect(args?.[1]).toMatchObject({
      variables: expect.objectContaining({
        search: "",
        sort: baseProps.sort,
        first: 20,
      }),
    });
  });

  it("shows loading state and accessible announcement", () => {
    mockUseQuery.mockReturnValue({
      data: undefined,
      loading: true,
      error: undefined,
      fetchMore: vi.fn(),
    });

    const { container } = render(<RecipeList {...baseProps} />);

    expect(screen.getByText("Loading results...")).toBeInTheDocument();
    expect(container.querySelector('section[aria-busy="true"]')).not.toBeNull();
    expect(screen.getByText("Loading...")).toBeInTheDocument();
  });

  it("renders error feedback when the query fails", () => {
    mockUseQuery.mockReturnValue({
      data: undefined,
      loading: false,
      error: new Error("Boom"),
      fetchMore: vi.fn(),
    });

    render(<RecipeList {...baseProps} />);

    expect(screen.getByRole("alert")).toHaveTextContent(
      "Something went wrong.",
    );
  });

  it("calls fetchMore when the load more button is pressed", () => {
    const fetchMore = vi.fn();
    const data = makeData();
    mockUseQuery.mockReturnValue({
      data: {
        recipes: {
          items: data.recipes.items,
          pageInfo: {
            ...data.recipes.pageInfo,
            hasNextPage: true,
            totalCount: 25,
          },
        },
      },
      loading: false,
      error: undefined,
      fetchMore,
    });

    render(<RecipeList {...baseProps} />);

    fireEvent.click(screen.getByRole("button", { name: "Load more results" }));
    expect(fetchMore).toHaveBeenCalledWith({ variables: { after: "cursor" } });
  });

  it("announces empty results accessibly", () => {
    mockUseQuery.mockReturnValue({
      data: {
        recipes: {
          items: [],
          pageInfo: {
            endCursor: null,
            hasNextPage: false,
            totalCount: 0,
          },
        },
      },
      loading: false,
      error: undefined,
      fetchMore: vi.fn(),
    });

    render(<RecipeList {...baseProps} />);

    expect(screen.getByText(/Showing 0 of 0 results/i)).toBeInTheDocument();
    expect(screen.queryByRole("listitem")).toBeNull();
  });

  it("summarizes large result sets and supports keyboard activation of pagination", () => {
    const fetchMore = vi.fn();
    mockUseQuery.mockReturnValue({
      data: {
        recipes: {
          items: makeData().recipes.items,
          pageInfo: {
            endCursor: "cursor",
            hasNextPage: true,
            totalCount: 250,
          },
        },
      },
      loading: false,
      error: undefined,
      fetchMore,
    });

    render(<RecipeList {...baseProps} />);

    expect(screen.getByText(/Showing 1 of 250 results/i)).toBeInTheDocument();

    const loadMore = screen.getByRole("button", { name: "Load more results" });
    loadMore.focus();
    expect(loadMore).toHaveFocus();
    fireEvent.click(loadMore);

    expect(fetchMore).toHaveBeenCalledWith({ variables: { after: "cursor" } });
  });

  it("handles very large pagination values and continues fetching until exhaustion", () => {
    const fetchMore = vi.fn().mockResolvedValue(undefined);
    const items = Array.from({ length: 20 }).map((_, idx) => ({
      id: `recipe-${idx + 1}`,
      title: `Dish ${idx + 1}`,
      time: 30,
      vegetarian: false,
      glutenFree: false,
      difficulty: "EASY",
      category: "Dinner",
      area: "Nordic",
      image: null,
    }));

    mockUseQuery.mockReturnValue({
      data: {
        recipes: {
          items,
          pageInfo: {
            endCursor: "page-1",
            hasNextPage: true,
            totalCount: 1000,
          },
        },
      },
      loading: false,
      error: undefined,
      fetchMore,
    });

    render(<RecipeList {...baseProps} />);

    expect(screen.getByText(/Showing 20 of 1000 results/i)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Load more results" }));

    expect(fetchMore).toHaveBeenCalledWith({
      variables: { after: "page-1" },
    });
  });
});
