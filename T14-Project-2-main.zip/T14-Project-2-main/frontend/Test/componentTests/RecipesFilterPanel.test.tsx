import { render, screen, fireEvent } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { RecipesFilterPanel } from "../../src/components/RecipesFilterPanel";
import type {
  FiltersState,
  SortOption,
  DifficultyValue,
} from "../../src/utils/recipeFilters";

const baseFilters: FiltersState = {
  vegetarian: false,
  glutenFree: false,
  difficulty: [],
  area: "",
  searchIngredients: false,
};

const availability = {
  vegetarian: true,
  glutenFree: true,
  difficulty: (["EASY", "MEDIUM", "HARD"] as DifficultyValue[]).map(
    (level) => ({ level, available: true }),
  ),
  areas: [
    { value: "Nordic", label: "Nordic", available: true },
    { value: "Asian", label: "Asian", available: true },
  ],
};

const setup = (
  overrides: Partial<React.ComponentProps<typeof RecipesFilterPanel>> = {},
) => {
  const props: React.ComponentProps<typeof RecipesFilterPanel> = {
    search: "",
    onSearchChange: vi.fn(),
    onSearchSubmit: vi.fn(),
    filters: baseFilters,
    onToggleBooleanFilter: vi.fn(),
    onToggleDifficultyFilter: vi.fn(),
    onClearDifficultyFilter: vi.fn(),
    onAreaChange: vi.fn(),
    onSearchIngredientsChange: vi.fn(),
    availability,
    disabledFilters: { vegetarian: false, glutenFree: false },
    originFilterDisabled: false,
    sort: "title-asc" as SortOption,
    onSortChange: vi.fn(),
    hasActiveFilters: true,
    onResetFilters: vi.fn(),
    ...overrides,
  };
  render(<RecipesFilterPanel {...props} />);
  return props;
};

describe("RecipesFilterPanel", () => {
  it("supports keyboard toggling of menus and selecting options", () => {
    const props = setup();

    const originToggle = screen.getByRole("button", {
      name: /toggle origin filters/i,
    });
    originToggle.focus();
    fireEvent.click(originToggle);
    expect(originToggle).toHaveAttribute("aria-expanded", "true");

    const nordic = screen.getByRole("menuitemradio", { name: "Nordic" });
    fireEvent.click(nordic);
    expect(props.onAreaChange).toHaveBeenCalledWith("Nordic");

    const difficultyToggle = screen.getByRole("button", {
      name: /toggle difficulty filters/i,
    });
    fireEvent.click(difficultyToggle);
    expect(difficultyToggle).toHaveAttribute("aria-expanded", "true");

    const easyOption = screen.getByRole("menuitemcheckbox", {
      name: "Easy",
    });
    fireEvent.click(easyOption);
    expect(props.onToggleDifficultyFilter).toHaveBeenCalledWith("EASY");
  });

  it("focuses and submits search via keyboard and shows helper text", () => {
    const props = setup({ search: "soup" });
    const searchButton = screen.getByRole("button", { name: "Search" });
    searchButton.focus();
    fireEvent.click(searchButton);
    expect(props.onSearchSubmit).toHaveBeenCalled();
    expect(screen.getByRole("status")).toHaveTextContent(/press tab/i);
  });
});
