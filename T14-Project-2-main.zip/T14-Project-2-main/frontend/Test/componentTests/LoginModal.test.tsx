import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, expect, it, beforeEach, vi } from "vitest";
import type { ReactNode } from "react";
import { LoginModal } from "../../src/components/LoginModal";
import userEvent from "@testing-library/user-event";

const mockUseAuth = vi.hoisted(() => vi.fn());

vi.mock("../../src/contexts/useAuth", () => ({
  useAuth: () => mockUseAuth(),
}));

vi.mock("react-dom", async () => {
  const actual = await vi.importActual<typeof import("react-dom")>("react-dom");
  return {
    ...actual,
    createPortal: (node: ReactNode) => node,
  };
});

type MockAuthValue = {
  login: ReturnType<typeof vi.fn>;
  signup: ReturnType<typeof vi.fn>;
};

const buildAuthValue = (
  overrides: Partial<MockAuthValue> = {},
): MockAuthValue => ({
  login: vi.fn().mockResolvedValue(undefined),
  signup: vi.fn().mockResolvedValue(undefined),
  ...overrides,
});

describe("LoginModal", () => {
  beforeEach(() => {
    mockUseAuth.mockReset();
  });

  it("returns null when closed", () => {
    mockUseAuth.mockReturnValue(buildAuthValue());
    const { container } = render(
      <LoginModal isOpen={false} onClose={vi.fn()} />,
    );
    expect(container).toBeEmptyDOMElement();
  });

  it("submits login credentials and clears form inputs", async () => {
    const authValue = buildAuthValue();
    mockUseAuth.mockReturnValue(authValue);

    render(<LoginModal isOpen onClose={vi.fn()} />);

    fireEvent.change(screen.getByLabelText("Email"), {
      target: { value: "chef@example.com" },
    });
    fireEvent.change(screen.getByLabelText("Password"), {
      target: { value: "secret" },
    });

    fireEvent.click(screen.getByRole("button", { name: "Log in" }));

    await waitFor(() =>
      expect(authValue.login).toHaveBeenCalledWith({
        email: "chef@example.com",
        password: "secret",
      }),
    );

    expect(screen.getByLabelText("Email")).toHaveValue("");
    expect(screen.getByLabelText("Password")).toHaveValue("");
  });

  it("switches to signup mode, handles errors, and calls signup mutation", async () => {
    const authValue = buildAuthValue();
    authValue.signup.mockRejectedValueOnce(new Error("Email already in use"));
    mockUseAuth.mockReturnValue(authValue);

    render(<LoginModal isOpen onClose={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: /Need an account\?/i }));
    fireEvent.change(screen.getByLabelText("Name"), {
      target: { value: "Taylor" },
    });
    fireEvent.change(screen.getByLabelText("Email"), {
      target: { value: "hello@example.com" },
    });
    fireEvent.change(screen.getByLabelText("Password"), {
      target: { value: "super-secret" },
    });

    fireEvent.click(screen.getByRole("button", { name: "Sign up" }));

    await waitFor(() =>
      expect(authValue.signup).toHaveBeenCalledWith({
        name: "Taylor",
        email: "hello@example.com",
        password: "super-secret",
      }),
    );

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Email already in use",
    );
  });

  it("keeps submit button disabled while request is in flight and triggers close handler", async () => {
    const authValue = buildAuthValue();
    authValue.login.mockImplementation(
      () =>
        new Promise((resolve) => {
          setTimeout(resolve, 50);
        }),
    );
    mockUseAuth.mockReturnValue(authValue);
    const onClose = vi.fn();

    render(<LoginModal isOpen onClose={onClose} />);

    fireEvent.change(screen.getByLabelText("Email"), {
      target: { value: "chef@example.com" },
    });
    fireEvent.change(screen.getByLabelText("Password"), {
      target: { value: "secret" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Log in" }));
    expect(
      screen.getByRole("button", { name: "Just a moment…" }),
    ).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: "Close login dialog" }));
    expect(onClose).toHaveBeenCalled();
  });

  it("supports keyboard-only flow through controls and submit", async () => {
    const user = userEvent.setup();
    const authValue = buildAuthValue();
    mockUseAuth.mockReturnValue(authValue);

    render(<LoginModal isOpen onClose={vi.fn()} />);

    await user.tab(); // focus the close button
    expect(
      screen.getByRole("button", { name: "Close login dialog" }),
    ).toHaveFocus();

    await user.tab(); // Email
    expect(screen.getByLabelText("Email")).toHaveFocus();
    await user.keyboard("keyboard@example.com{Tab}secret{Tab}{Enter}");

    await waitFor(() =>
      expect(authValue.login).toHaveBeenCalledWith({
        email: "keyboard@example.com",
        password: "secret",
      }),
    );
  });
});
