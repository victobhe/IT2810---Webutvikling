import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import CardsGrid from "../../src/components/Card-Grid";

describe("CardsGrid", () => {
  it("renders its children unchanged within the recipe grid container", () => {
    const { container } = render(
      <CardsGrid>
        <article>
          <h2>First recipe</h2>
        </article>
        <article>
          <h2>Second recipe</h2>
        </article>
      </CardsGrid>,
    );

    expect(
      screen.getByRole("heading", { name: "First recipe" }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { name: "Second recipe" }),
    ).toBeInTheDocument();

    const wrapper = container.querySelector(".recipe-grid");
    expect(wrapper).not.toBeNull();
    expect(wrapper?.children).toHaveLength(2);
  });

  it("merges custom class names with the base layout class", () => {
    const { container } = render(
      <CardsGrid className="custom-grid">
        <article>
          <h2>Only recipe</h2>
        </article>
      </CardsGrid>,
    );

    const wrapper = container.firstChild as HTMLElement;
    expect(wrapper).toHaveClass("recipe-grid");
    expect(wrapper).toHaveClass("custom-grid");
  });
});
