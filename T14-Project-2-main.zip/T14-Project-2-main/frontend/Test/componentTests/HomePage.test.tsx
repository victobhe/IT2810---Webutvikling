import { render, screen, fireEvent } from "@testing-library/react";
import { describe, expect, it, beforeEach, vi } from "vitest";
import type { ReactNode } from "react";
import HomePage from "../../src/pages/HomePage";
import { TOGGLE_FAVORITE_MUTATION } from "../../src/graphql/recipeActions";

const mockUseQuery = vi.hoisted(() => vi.fn());
const mockUseMutation = vi.hoisted(() => vi.fn());
const mockUseAuth = vi.hoisted(() => vi.fn());
const mockNavigate = vi.fn();

const mockReadScrollPosition = vi.hoisted(() => vi.fn(() => null));
const mockWriteScrollPosition = vi.hoisted(() => vi.fn());
const mockClearScrollPosition = vi.hoisted(() => vi.fn());
const mockScrollInstant = vi.hoisted(() => vi.fn());

vi.mock("@apollo/client", async () => {
  const actual =
    await vi.importActual<typeof import("@apollo/client")>("@apollo/client");
  return {
    ...actual,
    useQuery: mockUseQuery,
    useMutation: mockUseMutation,
  };
});

vi.mock("../../src/contexts/useAuth", () => ({
  useAuth: () => mockUseAuth(),
}));

vi.mock("react-router-dom", async () => {
  const actual =
    await vi.importActual<typeof import("react-router-dom")>(
      "react-router-dom",
    );
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

vi.mock("../../src/components/Header", () => ({
  default: () => <header data-testid="header" />,
}));

vi.mock("../../src/components/Card-Grid", () => ({
  default: ({ children }: { children: ReactNode }) => (
    <section data-testid="cards-grid">{children}</section>
  ),
}));

vi.mock("../../src/components/Card", () => ({
  default: ({
    item,
    isFavorite,
    onFavoriteToggle,
    onClick,
  }: {
    item: { id: string; title: string };
    isFavorite?: boolean;
    onFavoriteToggle?: (id: string) => void;
    onClick?: (id: string) => void;
  }) => (
    <article data-testid={`card-${item.id}`}>
      <h3>{item.title}</h3>
      <p>{isFavorite ? "favorite" : "not-favorite"}</p>
      <button
        type="button"
        onClick={() => onFavoriteToggle?.(item.id)}
        aria-label={`favorite ${item.id}`}
      >
        Favorite
      </button>
      <button
        type="button"
        onClick={() => onClick?.(item.id)}
        aria-label={`open ${item.id}`}
      >
        Open
      </button>
    </article>
  ),
}));

vi.mock("../../src/utils/scrollStorage", () => ({
  readScrollPosition: mockReadScrollPosition,
  writeScrollPosition: mockWriteScrollPosition,
  clearScrollPosition: mockClearScrollPosition,
  HOME_SCROLL_KEY: "HOME_SCROLL_KEY",
}));

vi.mock("../../src/utils/instantScroll", () => ({
  scrollInstant: (...args: unknown[]) => mockScrollInstant(...args),
}));

type Recipe = {
  id: string;
  title: string;
  area?: string | null;
  averageRating?: number | null;
  ratingCount?: number | null;
  isFavorite?: boolean;
  image?: string | null;
};

const buildQueryResult = (
  items: Recipe[] = [],
  loading = false,
  totalCount?: number,
) => ({
  data: {
    recipes: {
      items,
      pageInfo: {
        endCursor: null,
        hasNextPage: false,
        totalCount: totalCount ?? items.length,
      },
    },
  },
  loading,
});

const defaultAuth = () => ({
  user: null,
  openLogin: vi.fn(),
});

const setupToggleMutation = (impl?: ReturnType<typeof vi.fn>) => {
  const toggle =
    impl ?? vi.fn().mockResolvedValue({ data: { toggleFavorite: true } });
  mockUseMutation.mockImplementation((mutation) => {
    if (mutation === TOGGLE_FAVORITE_MUTATION) return [toggle, {}];
    return [vi.fn(), {}];
  });
  return toggle;
};

beforeEach(() => {
  mockUseQuery.mockReset();
  mockUseMutation.mockReset();
  mockUseAuth.mockReset();
  mockNavigate.mockReset();
  mockWriteScrollPosition.mockReset();
  mockReadScrollPosition.mockReset();
  mockReadScrollPosition.mockReturnValue(null);
  mockClearScrollPosition.mockReset();
  mockScrollInstant.mockReset();
  window.scrollTo = vi.fn();
});

describe("HomePage", () => {
  it("renders hero content, featured cards, and prompts login when toggling favorite as guest", () => {
    const items: Recipe[] = [
      { id: "rec-1", title: "First dish", area: "Nordic", isFavorite: false },
      { id: "rec-2", title: "Second dish", area: "Asian", isFavorite: true },
    ];
    mockUseQuery.mockReturnValue(buildQueryResult(items));
    setupToggleMutation();
    const auth = defaultAuth();
    mockUseAuth.mockReturnValue(auth);

    render(<HomePage />);

    expect(
      screen.getByRole("heading", { name: /Welcome to DishDelish/i }),
    ).toBeInTheDocument();
    expect(screen.getByTestId("cards-grid").children).toHaveLength(2);
    expect(screen.getByTestId("card-rec-1")).toHaveTextContent("not-favorite");

    fireEvent.click(screen.getByRole("button", { name: "favorite rec-1" }));
    expect(auth.openLogin).toHaveBeenCalledTimes(1);
  });

  it("calls the toggle favorite mutation when a signed-in user interacts with a card", () => {
    const items: Recipe[] = [
      { id: "rec-10", title: "Carrot Soup", isFavorite: false },
    ];
    mockUseQuery.mockReturnValue(buildQueryResult(items));
    const toggleMutation = setupToggleMutation();
    mockUseAuth.mockReturnValue({
      user: { id: "user-1", email: "chef@example.com" },
      openLogin: vi.fn(),
    });

    render(<HomePage />);

    fireEvent.click(screen.getByRole("button", { name: "favorite rec-10" }));
    expect(toggleMutation).toHaveBeenCalledWith(
      expect.objectContaining({
        variables: { recipeId: "rec-10" },
      }),
    );
  });

  it("shows fallback and loading messages when no featured items are available", () => {
    mockUseAuth.mockReturnValue(defaultAuth());

    mockUseQuery.mockReturnValueOnce(buildQueryResult([], true));
    setupToggleMutation();
    const { rerender } = render(<HomePage />);

    expect(screen.getByRole("status")).toHaveTextContent(
      "Loading featured recipes...",
    );

    mockUseQuery.mockReturnValueOnce(buildQueryResult([], false));
    rerender(<HomePage />);
    expect(screen.getByRole("status")).toHaveTextContent(
      "Featured dishes will appear here soon.",
    );
  });

  it("stores scroll position and navigates when a card is opened", () => {
    const items: Recipe[] = [{ id: "rec-20", title: "Taco" }];
    mockUseQuery.mockReturnValue(buildQueryResult(items));
    setupToggleMutation();
    mockUseAuth.mockReturnValue({
      user: { id: "u1" },
      openLogin: vi.fn(),
    });
    mockReadScrollPosition.mockReturnValueOnce(null);

    render(<HomePage />);

    fireEvent.click(screen.getByRole("button", { name: "open rec-20" }));
    expect(mockWriteScrollPosition).toHaveBeenCalled();
    expect(mockNavigate).toHaveBeenCalledWith("/recipe/rec-20");
  });

  it("falls back to empty state messaging when the recipes query fails", () => {
    mockUseAuth.mockReturnValue(defaultAuth());
    mockUseQuery.mockReturnValue({
      data: undefined,
      loading: false,
      error: new Error("network down"),
      fetchMore: vi.fn(),
    });
    setupToggleMutation();

    render(<HomePage />);

    expect(screen.getByRole("status")).toHaveTextContent(
      "Featured dishes will appear here soon.",
    );
  });
});
