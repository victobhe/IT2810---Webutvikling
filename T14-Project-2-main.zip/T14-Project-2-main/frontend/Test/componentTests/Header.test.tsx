import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { describe, expect, it, beforeEach, vi } from "vitest";
import Header from "../../src/components/Header";

vi.mock("../../src/styles/components.css", () => ({}), { virtual: true });

const mockUseAuth = vi.hoisted(() => vi.fn());

vi.mock("../../src/contexts/useAuth", () => ({
  useAuth: () => mockUseAuth(),
}));

vi.mock("../../src/components/ThemeToggle", () => ({
  ThemeToggle: () => <span data-testid="theme-toggle" />,
  default: () => <span data-testid="theme-toggle" />,
}));

function buildDefaultAuth() {
  return {
    user: null,
    status: "unauthenticated",
    isLoginOpen: false,
    openLogin: vi.fn(),
    closeLogin: vi.fn(),
    login: vi.fn(),
    signup: vi.fn(),
    logout: vi.fn(),
    refresh: vi.fn(),
  };
}

const createAuthValue = (
  overrides: Partial<ReturnType<typeof buildDefaultAuth>> = {},
) => ({
  ...buildDefaultAuth(),
  ...overrides,
});

const renderWithRouter = (ui: React.ReactElement, initialPath = "/") =>
  render(<MemoryRouter initialEntries={[initialPath]}>{ui}</MemoryRouter>);

describe("Header", () => {
  beforeEach(() => {
    mockUseAuth.mockReset();
  });

  it("shows default navigation links and login action when unauthenticated", () => {
    const authValue = createAuthValue();
    mockUseAuth.mockReturnValue(authValue);

    renderWithRouter(<Header recipeCount={5} />, "/recipes");

    expect(screen.getByRole("link", { name: "DishDelish" })).toHaveAttribute(
      "href",
      "/",
    );
    expect(screen.getByRole("link", { name: "Recipes" })).toHaveAttribute(
      "href",
      "/recipes",
    );
    expect(screen.getByText("5 recipes")).toHaveAttribute(
      "aria-live",
      "polite",
    );

    fireEvent.click(screen.getByRole("button", { name: /log in/i }));
    expect(authValue.openLogin).toHaveBeenCalled();
  });

  it("renders user badge and logout control when authenticated", () => {
    const authValue = createAuthValue({
      user: { id: "1", name: "Casey Cook", email: "casey@example.com" },
    });
    mockUseAuth.mockReturnValue(authValue);

    renderWithRouter(
      <Header
        recipeCount={12}
        links={[{ href: "/recipes", label: "Browse" }]}
      />,
      "/recipes",
    );

    expect(screen.getByText("12 recipes")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Browse" })).toHaveAttribute(
      "href",
      "/recipes",
    );
    expect(
      screen.getByLabelText("View profile for Casey Cook"),
    ).toHaveTextContent("C");

    fireEvent.click(screen.getByRole("button", { name: /log out/i }));
    expect(authValue.logout).toHaveBeenCalled();
  });

  it("falls back to email initial when name is missing", () => {
    const authValue = createAuthValue({
      user: { id: "2", name: null, email: "hello@example.com" },
    });
    mockUseAuth.mockReturnValue(authValue);

    renderWithRouter(<Header />);

    expect(
      screen.getByLabelText("View profile for hello@example.com"),
    ).toHaveTextContent("H");
  });
});
