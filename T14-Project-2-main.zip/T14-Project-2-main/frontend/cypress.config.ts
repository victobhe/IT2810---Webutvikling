import { defineConfig } from "cypress";
import ctViteConfig from "./vite.config.ct";

export default defineConfig({
  fixturesFolder: "Test/cypress/fixtures",
  downloadsFolder: "Test/cypress/downloads",
  screenshotsFolder: "Test/cypress/screenshots",
  videosFolder: "Test/cypress/videos",
  component: {
    specPattern: "Test/cypress/component/**/*.cy.{js,jsx,ts,tsx}",
    supportFile: "Test/cypress/support/component.ts",
    indexHtmlFile: "Test/cypress/support/component-index.html",
    devServer: {
      framework: "react",
      bundler: "vite",
      viteConfig: ctViteConfig,
    },
  },

  e2e: {
    specPattern: "Test/cypress/e2e/**/*.cy.{js,jsx,ts,tsx}",
    supportFile: "Test/cypress/support/e2e.ts",
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
    baseUrl: "http://localhost:5173/project2/",
  },
});
