/**
 * Utility for parsing and validating sort strings
 * Converts "title-asc" → { field: "TITLE", direction: "ASC" }
 */

import { type RecipeSortInput } from "../graphql/recipes";
import { type SortOption, VALID_SORTS } from "./recipeFilters";

/**
 * Parse a sort string into field and direction components
 * @param sort - Sort string like "title-asc" or "time-desc"
 * @returns { field, direction } for GraphQL query
 * @throws Error if sort string is invalid
 */
export const parseSortString = (sort: SortOption): RecipeSortInput => {
  if (!VALID_SORTS.has(sort)) {
    throw new Error(`Invalid sort option: ${sort}`);
  }

  const [fieldRaw, dirRaw] = sort.split("-");
  const field = fieldRaw?.toUpperCase() === "TIME" ? "TIME" : "TITLE";
  const direction = dirRaw?.toUpperCase() === "DESC" ? "DESC" : "ASC";

  return { field, direction };
};

/**
 * Validate if a string is a valid SortOption
 * @param candidate - Potential sort string
 * @returns true if valid, false otherwise
 */
export const isValidSort = (candidate: unknown): candidate is SortOption => {
  return (
    typeof candidate === "string" && VALID_SORTS.has(candidate as SortOption)
  );
};

/**
 * Get human-readable label for a sort option
 * @param sort - Sort option like "title-asc"
 * @returns Display label like "Title (A-Z)"
 */
export const getSortLabel = (sort: SortOption): string => {
  const labels: Record<SortOption, string> = {
    "title-asc": "Title (A-Z)",
    "title-desc": "Title (Z-A)",
    "time-asc": "Shortest time",
    "time-desc": "Longest time",
  };
  return labels[sort] ?? sort;
};
