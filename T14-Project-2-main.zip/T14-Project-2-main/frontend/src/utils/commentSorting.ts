export type CommentSortOrder = "newest" | "oldest" | "highest" | "lowest";

export const COMMENT_SORT_OPTIONS: Array<{
  value: CommentSortOrder;
  label: string;
}> = [
  { value: "newest", label: "Newest first" },
  { value: "oldest", label: "Oldest first" },
  { value: "highest", label: "Highest rated first" },
  { value: "lowest", label: "Lowest rated first" },
];

type SortableComment = {
  createdAt: string;
  rating?: number | null;
};

const getTimestamp = (value: string): number => {
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const getRating = (rating?: number | null): number | null => {
  if (typeof rating !== "number" || Number.isNaN(rating)) {
    return null;
  }
  return rating;
};

export const sortCommentsBy = <T extends SortableComment>(
  comments: T[],
  order: CommentSortOrder,
): T[] => {
  const byNewest = (a: T, b: T) =>
    getTimestamp(b.createdAt) - getTimestamp(a.createdAt);
  const byOldest = (a: T, b: T) =>
    getTimestamp(a.createdAt) - getTimestamp(b.createdAt);
  const withRating = (direction: "asc" | "desc") => (a: T, b: T) => {
    const ratingA = getRating(a.rating);
    const ratingB = getRating(b.rating);

    if (ratingA === null && ratingB === null) {
      return byNewest(a, b);
    }
    if (ratingA === null) return 1;
    if (ratingB === null) return -1;

    const diff = direction === "desc" ? ratingB - ratingA : ratingA - ratingB;
    if (diff !== 0) {
      return diff;
    }
    return byNewest(a, b);
  };

  const sorter: Record<CommentSortOrder, (a: T, b: T) => number> = {
    newest: byNewest,
    oldest: byOldest,
    highest: withRating("desc"),
    lowest: withRating("asc"),
  };

  return [...comments].sort(sorter[order]);
};
