/**
 * Recipe filter utilities, constants, and types
 * Centralized definitions for difficulty levels, sort options, and filter state
 */

/**
 * Valid difficulty levels for recipes
 */
export type DifficultyValue = "EASY" | "MEDIUM" | "HARD";

/**
 * Difficulty order (used for consistent sorting)
 */
export const DIFFICULTY_ORDER: DifficultyValue[] = ["EASY", "MEDIUM", "HARD"];

/**
 * Human-readable labels for difficulty levels
 */

export const DIFFICULTY_LABELS: Record<DifficultyValue, string> = {
  EASY: "Easy",
  MEDIUM: "Medium",
  HARD: "Hard",
};

/**
 * Valid sort options
 */
export type SortOption = "title-asc" | "title-desc" | "time-asc" | "time-desc";

/**
 * Set of valid sort options for quick validation
 */
export const VALID_SORTS: Set<SortOption> = new Set([
  "title-asc",
  "title-desc",
  "time-asc",
  "time-desc",
]);

/**
 * Client-side recipe filter state
 * Maps closely to RecipeFiltersInput but keeps search separate for debouncing
 */
export interface FiltersState {
  vegetarian?: boolean;
  glutenFree?: boolean;
  difficulty?: DifficultyValue[];
  area?: string;
  searchIngredients?: boolean;
}

/**
 * Combined search and filter criteria for recipes
 * Used to track desired state before relaxation steps
 */
export interface RecipeCriteria {
  search: string;
  filters: FiltersState;
  sort: SortOption;
}

/**
 * Represents one step in the filter relaxation process
 * Used when search/filters return no results
 */
export interface RelaxationStep {
  label: string;
  apply: (criteria: RecipeCriteria) => RecipeCriteria;
}

/**
 * Build relaxation steps for progressive filter relaxation
 * When no results found, these steps progressively remove filters to find matches
 * Order matters: Steps are applied in order when results are empty
 *
 * @param criteria - The desired filter criteria
 * @returns Array of relaxation steps to try in order
 */
export const buildRelaxationSteps = (
  criteria: RecipeCriteria,
): RelaxationStep[] => {
  const steps: RelaxationStep[] = [];

  if (criteria.filters.difficulty && criteria.filters.difficulty.length > 0) {
    steps.push({
      label: "Removing difficulty filter",
      apply: (c) => ({
        ...c,
        filters: { ...c.filters, difficulty: undefined },
      }),
    });
  }

  if (criteria.filters.vegetarian) {
    steps.push({
      label: "Removing vegetarian filter",
      apply: (c) => ({
        ...c,
        filters: { ...c.filters, vegetarian: undefined },
      }),
    });
  }

  if (criteria.filters.glutenFree) {
    steps.push({
      label: "Removing gluten-free filter",
      apply: (c) => ({
        ...c,
        filters: { ...c.filters, glutenFree: undefined },
      }),
    });
  }

  if (criteria.filters.area) {
    steps.push({
      label: "Expanding to all regions",
      apply: (c) => ({
        ...c,
        filters: { ...c.filters, area: undefined },
      }),
    });
  }

  if (criteria.search.trim().length > 0) {
    steps.push({
      label: "Searching all recipes",
      apply: (c) => ({
        ...c,
        search: "",
      }),
    });
  }

  return steps;
};

/**
 * Type guard to check if a string is a valid DifficultyValue
 * @param value - Value to check
 * @returns true if value is "EASY", "MEDIUM", or "HARD"
 */
export const isDifficultyValue = (value: unknown): value is DifficultyValue => {
  return value === "EASY" || value === "MEDIUM" || value === "HARD";
};

/**
 * Type guard to check if a string is a valid SortOption
 * @param value - Value to check
 * @returns true if value is a valid sort option
 */
export const isSortOption = (value: unknown): value is SortOption => {
  return typeof value === "string" && VALID_SORTS.has(value as SortOption);
};
