export const scrollInstant = (top = 0, left = 0) => {
  if (typeof window === "undefined") return;
  const root = document.documentElement;
  const previousBehavior = root.style.scrollBehavior;

  root.style.scrollBehavior = "auto";
  window.scrollTo(left, top);

  requestAnimationFrame(() => {
    root.style.scrollBehavior = previousBehavior;
  });
};
