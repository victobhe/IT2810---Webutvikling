export const HOME_SCROLL_KEY = "home-page-scroll";
export const RECIPES_SCROLL_KEY = "recipes-page-scroll";

const getSession = () => {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage;
  } catch {
    return null;
  }
};

const parseScrollValue = (raw: string | null) => {
  if (!raw) return null;
  const value = Number.parseInt(raw, 10);
  if (!Number.isFinite(value) || value < 0) {
    return null;
  }
  return value;
};

const readHistoryScroll = (key: string): number | null => {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.history.state?.[key];
    return typeof raw === "number" ? raw : parseScrollValue(raw ?? null);
  } catch {
    return null;
  }
};

const writeHistoryScroll = (key: string, value: number | null) => {
  if (typeof window === "undefined") return;
  try {
    const state = window.history.state ?? {};
    if (value === null) {
      if (state[key] === undefined) return;
      const { [key]: removed, ...rest } = state;
      void removed;
      window.history.replaceState(rest, document.title);
      return;
    }
    window.history.replaceState({ ...state, [key]: value }, document.title);
  } catch {
    // ignore history errors
  }
};

export const readScrollPosition = (key: string): number | null => {
  const storage = getSession();
  if (storage) {
    try {
      const value = parseScrollValue(storage.getItem(key));
      if (value !== null) return value;
    } catch {
      // ignore and fall back to history
    }
  }
  return readHistoryScroll(key);
};

export const writeScrollPosition = (key: string, value: number) => {
  const sanitized = Math.max(0, Math.round(value));
  const storage = getSession();
  if (storage) {
    try {
      storage.setItem(key, String(sanitized));
    } catch {
      // ignore write errors (e.g., Safari private mode)
    }
  }
  writeHistoryScroll(key, sanitized);
};

export const clearScrollPosition = (key: string) => {
  const storage = getSession();
  if (storage) {
    try {
      storage.removeItem(key);
    } catch {
      // ignore
    }
  }
  writeHistoryScroll(key, null);
};

export const hasScrollPosition = (key: string): boolean => {
  const storage = getSession();
  if (storage) {
    try {
      if (storage.getItem(key) !== null) return true;
    } catch {
      // ignore and fall back to history
    }
  }
  return readHistoryScroll(key) !== null;
};
