/**
 * Utility functions for building and rendering recipe cards
 */

import { type RecipeListItem } from "../graphql/recipes";
import { resolveImageUrl } from "./resolveImageUrl";

/**
 * Calculate rating value with bounds checking
 * @param value - Rating value to clamp
 * @returns Clamped value between 0-5 with one decimal
 */
export const clampRating = (value: number): number =>
  Math.max(0, Math.min(5, Math.round(value * 10) / 10));

/**
 * Extract rating from recipe, with safety checks
 * @param recipe - Recipe data
 * @returns Rating value (0-5) or undefined if no valid rating
 */
export const getRecipeRating = (
  recipe?: RecipeListItem | null,
): number | undefined => {
  if (
    recipe &&
    typeof recipe.averageRating === "number" &&
    Number.isFinite(recipe.averageRating) &&
    (recipe.ratingCount ?? 0) > 0
  ) {
    return clampRating(recipe.averageRating);
  }
  return undefined;
};

/**
 * Build array of tags for a recipe card
 * Includes time, difficulty, category, dietary info
 * @param recipe - Recipe data
 * @returns Array of unique tag strings
 */
export const buildCardTags = (recipe: RecipeListItem): string[] =>
  Array.from(
    new Set(
      [
        typeof recipe.time === "number" ? `${recipe.time} min` : undefined,
        recipe.difficulty ?? undefined,
        recipe.category ?? undefined,
        recipe.vegetarian === true ? "Vegetarian" : undefined,
        recipe.glutenFree === true ? "Gluten-free" : undefined,
      ].filter(
        (tag): tag is string => typeof tag === "string" && tag.length > 0,
      ),
    ),
  );

/**
 * Generate placeholder image URL for a recipe
 * @param title - Recipe title
 * @returns Placeholder image URL
 */
export const getPlaceholderImageUrl = (title: string): string =>
  `https://via.placeholder.com/600x400?text=${encodeURIComponent(title)}`;

/**
 * Get final image URL for a recipe (resolved or placeholder)
 * @param image - Recipe image field
 * @param title - Recipe title (for placeholder)
 * @returns Valid image URL
 */
export const getCardImageUrl = (
  image: string | null | undefined,
  title: string,
): string => resolveImageUrl(image) ?? getPlaceholderImageUrl(title);
