const isAbsoluteUrl = (value: string) =>
  /^[a-z][a-z0-9+.-]*:\/\//i.test(value) || value.startsWith("data:");
const isProtocolRelative = (value: string) => value.startsWith("//");

export const resolveImageUrl = (source?: string | null): string | null => {
  if (!source) return null;
  const trimmed = source.trim();
  if (trimmed.length === 0) return null;

  if (isProtocolRelative(trimmed)) {
    return `https:${trimmed}`;
  }
  if (isAbsoluteUrl(trimmed)) {
    return trimmed;
  }

  // Always trust the API-provided relative path so we never rewrite to localhost.
  return trimmed;
};
