let currentToken: string | null = null;

const TOKEN_STORAGE_KEY = "dishdelish.authToken";
const TOKEN_TTL_MS = 1000 * 60 * 60 * 2; // 2 hours

type StoredTokenPayload = {
  value: string;
  expiresAt: number;
};

const getStorage = (type: "local" | "session"): Storage | null => {
  if (typeof window === "undefined") return null;
  return type === "local" ? window.localStorage : window.sessionStorage;
};

const isStorageUsable = (storage: Storage | null) => {
  if (!storage) return false;
  try {
    const testKey = `${TOKEN_STORAGE_KEY}.test`;
    storage.setItem(testKey, "1");
    storage.removeItem(testKey);
    return true;
  } catch {
    return false;
  }
};

const buildPayload = (token: string): StoredTokenPayload => ({
  value: token,
  expiresAt: Date.now() + TOKEN_TTL_MS,
});

const writeToken = (storage: Storage, payload: StoredTokenPayload) => {
  storage.setItem(TOKEN_STORAGE_KEY, JSON.stringify(payload));
};

const removeToken = (storage: Storage) => {
  storage.removeItem(TOKEN_STORAGE_KEY);
};

const readTokenFromStorage = (storage: Storage): StoredTokenPayload | null => {
  try {
    const raw = storage.getItem(TOKEN_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as StoredTokenPayload;
    if (!parsed?.value || typeof parsed.expiresAt !== "number") {
      removeToken(storage);
      return null;
    }
    if (parsed.expiresAt <= Date.now()) {
      removeToken(storage);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
};

const persistToken = (token: string | null) => {
  const localStorage = getStorage("local");
  const sessionStorage = getStorage("session");

  if (token) {
    const payload = buildPayload(token);
    if (isStorageUsable(localStorage)) {
      writeToken(localStorage, payload);
    }
    if (isStorageUsable(sessionStorage)) {
      writeToken(sessionStorage, payload);
    }
    return;
  }

  if (isStorageUsable(localStorage)) {
    removeToken(localStorage);
  }
  if (isStorageUsable(sessionStorage)) {
    removeToken(sessionStorage);
  }
};

const hydrateToken = () => {
  const sessionStorage = getStorage("session");
  const localStorage = getStorage("local");
  const sessionPayload =
    sessionStorage && isStorageUsable(sessionStorage)
      ? readTokenFromStorage(sessionStorage)
      : null;
  const localPayload =
    localStorage && isStorageUsable(localStorage)
      ? readTokenFromStorage(localStorage)
      : null;
  const payload = sessionPayload ?? localPayload;
  if (payload) {
    currentToken = payload.value;
    return;
  }
  currentToken = null;
};

export const setAuthToken = (token: string | null | undefined) => {
  currentToken = token ?? null;
  persistToken(currentToken);
};

export const getAuthToken = () => {
  if (currentToken) return currentToken;
  hydrateToken();
  return currentToken;
};

export const clearAuthToken = () => {
  currentToken = null;
  persistToken(null);
};

hydrateToken();
