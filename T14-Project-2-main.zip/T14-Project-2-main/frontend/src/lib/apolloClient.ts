import { ApolloClient, InMemoryCache, HttpLink, from } from "@apollo/client";
import { setContext } from "@apollo/client/link/context";
import { getAuthToken } from "./authToken";

const httpLink = new HttpLink({
  uri: import.meta.env.VITE_API_URL ?? "http://localhost:3001/graphql",
  credentials: "include",
});

const authLink = setContext((_, { headers }) => {
  const token = getAuthToken();
  return {
    headers: {
      ...headers,
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  };
});

export const client = new ApolloClient({
  link: from([authLink, httpLink]),
  cache: new InMemoryCache({
    typePolicies: {
      Query: {
        fields: {
          recipes: {
            keyArgs: ["search", "filters", "sort"],
            merge(existing = { items: [], pageInfo: {} }, incoming, { args }) {
              const isFirstPage = !args?.after;
              const mergedItems = isFirstPage
                ? (incoming.items ?? [])
                : [...(existing.items ?? []), ...(incoming.items ?? [])];
              return {
                items: mergedItems,
                pageInfo: incoming.pageInfo,
              };
            },
          },
        },
      },
    },
  }),
});
