import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { useMutation, useQuery } from "@apollo/client";
import {
  ME_QUERY,
  type MeQueryData,
  LOGIN_MUTATION,
  LOGOUT_MUTATION,
  SIGNUP_MUTATION,
  type LoginMutationData,
  type LoginVariables,
  type LogoutMutationData,
  type SignupMutationData,
  type SignupVariables,
  type AuthUser,
} from "../graphql/auth";
import { clearAuthToken, getAuthToken, setAuthToken } from "../lib/authToken";
import {
  AuthContext,
  type AuthContextValue,
  type AuthStatus,
} from "./AuthContextContext";

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [shouldFetchUser, setShouldFetchUser] = useState<boolean>(() =>
    Boolean(getAuthToken()),
  );
  const { data, loading, refetch } = useQuery<MeQueryData>(ME_QUERY, {
    fetchPolicy: "cache-first",
    skip: !shouldFetchUser,
  });
  const [loginMutation] = useMutation<LoginMutationData, LoginVariables>(
    LOGIN_MUTATION,
  );
  const [logoutMutation] = useMutation<LogoutMutationData>(LOGOUT_MUTATION);
  const [signupMutation] = useMutation<SignupMutationData, SignupVariables>(
    SIGNUP_MUTATION,
  );
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoginOpen, setIsLoginOpen] = useState(false);

  useEffect(() => {
    if (!loading) {
      setUser(data?.me ?? null);
    }
  }, [data?.me, loading]);

  const status: AuthStatus = loading
    ? "loading"
    : user
      ? "authenticated"
      : "unauthenticated";

  const openLogin = useCallback(() => setIsLoginOpen(true), []);
  const closeLogin = useCallback(() => setIsLoginOpen(false), []);

  const login = useCallback(
    async (variables: LoginVariables) => {
      const result = await loginMutation({ variables });
      const payload = result.data?.login;
      if (!payload?.user) {
        throw new Error("Could not log in");
      }
      if (payload.token) {
        setAuthToken(payload.token);
        setShouldFetchUser(true);
      }
      await refetch();
      setUser(payload.user);
      closeLogin();
    },
    [closeLogin, loginMutation, refetch],
  );

  const logout = useCallback(async () => {
    try {
      await logoutMutation();
    } finally {
      clearAuthToken();
      setUser(null);
      setShouldFetchUser(false);
      if (shouldFetchUser) {
        await refetch();
      }
    }
  }, [logoutMutation, refetch, shouldFetchUser]);

  const signup = useCallback(
    async (variables: SignupVariables) => {
      const result = await signupMutation({ variables });
      const payload = result.data?.signup;
      if (!payload?.user) {
        throw new Error("Could not sign up");
      }
      if (payload.token) {
        setAuthToken(payload.token);
        setShouldFetchUser(true);
      }
      await refetch();
      setUser(payload.user);
      closeLogin();
    },
    [closeLogin, refetch, signupMutation],
  );

  const refresh = useCallback(async () => {
    setShouldFetchUser(true);
    const result = await refetch();
    setUser(result.data?.me ?? null);
  }, [refetch]);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      status,
      isLoginOpen,
      openLogin,
      closeLogin,
      login,
      signup,
      logout,
      refresh,
    }),
    [
      closeLogin,
      isLoginOpen,
      login,
      logout,
      openLogin,
      refresh,
      signup,
      status,
      user,
    ],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
