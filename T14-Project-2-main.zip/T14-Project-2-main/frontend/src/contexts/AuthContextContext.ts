import { createContext } from "react";
import type {
  AuthUser,
  LoginVariables,
  SignupVariables,
} from "../graphql/auth";

export type AuthStatus = "loading" | "authenticated" | "unauthenticated";

export type AuthContextValue = {
  user: AuthUser | null;
  status: AuthStatus;
  isLoginOpen: boolean;
  openLogin: () => void;
  closeLogin: () => void;
  login: (variables: LoginVariables) => Promise<void>;
  signup: (variables: SignupVariables) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
};

export const AuthContext = createContext<AuthContextValue | undefined>(
  undefined,
);
