import { Link, NavLink, useLocation } from "react-router-dom";
import { ThemeToggle } from "./ThemeToggle";
import { useAuth } from "../contexts/useAuth";
import "../styles/components.css";

type HeaderLink = {
  label: string;
  href?: string;
  to?: string;
};

type HeaderProps = {
  recipeCount?: number;
  links?: HeaderLink[];
};

const buildDefaultLinks = (hasUser: boolean): HeaderLink[] => {
  const entries: HeaderLink[] = [{ to: "/recipes", label: "Recipes" }];
  if (hasUser) {
    entries.push({ to: "/profile", label: "My profile" });
  }
  return entries;
};

export default function Header({
  recipeCount,
  links,
}: HeaderProps): React.ReactElement {
  const { user, logout, openLogin } = useAuth();
  const location = useLocation();
  const resolvedLinks = links ?? buildDefaultLinks(Boolean(user));
  const showRecipeCount =
    typeof recipeCount === "number" && location.pathname.startsWith("/recipes");

  return (
    <header className="site-header" role="banner">
      <section className="site-header__inner">
        <nav className="primary-nav" aria-label="Main navigation">
          <NavLink className="site-logo" to="/">
            DishDelish
          </NavLink>
          {resolvedLinks.map((link) => {
            const key = `${link.to ?? link.href ?? link.label}-${link.label}`;
            if (link.to) {
              return (
                <NavLink key={key} to={link.to}>
                  {link.label}
                </NavLink>
              );
            }
            return (
              <a key={key} href={link.href ?? "#"}>
                {link.label}
              </a>
            );
          })}
        </nav>
        <section className="site-header__actions" aria-label="User controls">
          {showRecipeCount ? (
            <p className="header-recipe-count" aria-live="polite">
              {recipeCount} recipe{recipeCount === 1 ? "" : "s"}
            </p>
          ) : null}
          <ThemeToggle />
          {user ? (
            <aside className="header-user">
              <button
                type="button"
                className="btn btn--ghost header-user__logout"
                onClick={() => logout()}
              >
                Log out
              </button>
              <Link
                className="header-user__badge"
                to="/profile"
                aria-label={`View profile for ${user.name ?? user.email}`}
              >
                {user.name?.[0] ?? user.email[0]?.toUpperCase() ?? "U"}
              </Link>
            </aside>
          ) : (
            <button
              type="button"
              className="btn btn--ghost header-login"
              onClick={openLogin}
            >
              Log in
            </button>
          )}
        </section>
      </section>
    </header>
  );
}
