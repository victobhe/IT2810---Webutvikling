import type { ReactNode } from "react";

type Props = { children: ReactNode; className?: string };

export default function CardsGrid({ children, className }: Props) {
  const classes = ["recipe-grid"];
  if (className) {
    classes.push(className);
  }

  return (
    <section className={classes.join(" ")} role="presentation">
      {children}
    </section>
  );
}
