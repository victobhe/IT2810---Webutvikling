import { useState } from "react";
import { createPortal } from "react-dom";
import { useAuth } from "../contexts/useAuth";

type Props = {
  isOpen: boolean;
  onClose: () => void;
};

type Mode = "login" | "signup";

export function LoginModal({ isOpen, onClose }: Props) {
  const { login, signup } = useAuth();
  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (mode === "login") {
        await login({ email, password });
      } else {
        await signup({ email, password, name });
      }
      setEmail("");
      setPassword("");
      setName("");
    } catch (err) {
      const message =
        err instanceof Error
          ? err.message
          : `Could not ${mode === "login" ? "log in" : "sign up"}`;
      setError(message);
    } finally {
      setSubmitting(false);
    }
  };

  const toggleMode = () => {
    setMode((prev) => (prev === "login" ? "signup" : "login"));
    setError(null);
  };

  const title = mode === "login" ? "Log in" : "Create account";
  const submitLabel = submitting
    ? "Just a moment…"
    : mode === "login"
      ? "Log in"
      : "Sign up";
  const helperText =
    mode === "login" ? "Need an account?" : "Already have an account?";

  const body = (
    <section className="modal-overlay" role="presentation">
      <article
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="login-title"
      >
        <header className="modal__header">
          <h2 id="login-title">{title}</h2>
          <button
            type="button"
            className="modal__close"
            aria-label="Close login dialog"
            onClick={onClose}
          >
            ×
          </button>
        </header>
        <form className="modal__body" onSubmit={handleSubmit}>
          {mode === "signup" ? (
            <>
              <label className="modal__label" htmlFor="login-name">
                Name
              </label>
              <input
                id="login-name"
                type="text"
                autoComplete="name"
                value={name}
                onChange={(event) => setName(event.target.value)}
                required
              />
            </>
          ) : null}

          <label className="modal__label" htmlFor="login-email">
            Email
          </label>
          <input
            id="login-email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            required
          />

          <label className="modal__label" htmlFor="login-password">
            Password
          </label>
          <input
            id="login-password"
            type="password"
            autoComplete={
              mode === "login" ? "current-password" : "new-password"
            }
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            required
          />

          {error ? (
            <p role="alert" className="modal__error">
              {error}
            </p>
          ) : null}

          <button
            type="submit"
            className="btn btn--primary modal__submit"
            disabled={submitting}
          >
            {submitLabel}
          </button>
          <button type="button" className="modal__switch" onClick={toggleMode}>
            {helperText} <span>{mode === "login" ? "Sign up" : "Log in"}</span>
          </button>
        </form>
      </article>
    </section>
  );

  return createPortal(body, document.body);
}
