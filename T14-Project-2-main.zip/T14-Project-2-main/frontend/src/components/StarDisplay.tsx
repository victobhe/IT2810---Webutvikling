import React from "react";
import "../styles/starRating.css";

interface StarDisplayProps {
  rating: number;
  totalStars?: number;
  variant?: "lg" | "compact";
  showValue?: boolean;
  showCount?: boolean;
  count?: number;
  commentId?: string;
  aria?: {
    label?: string;
    hidden?: boolean;
  };
}

const StarDisplay: React.FC<StarDisplayProps> = ({
  rating,
  totalStars = 5,
  variant = "compact",
  showValue = true,
  showCount = false,
  count,
  commentId,
  aria = {},
}) => {
  if (typeof rating !== "number" || Number.isNaN(rating) || rating < 0) {
    return (
      <span
        className={`review-card__rating review-card__rating--placeholder`}
        role={aria.hidden ? "img" : undefined}
        aria-label={aria.label ?? "No rating yet"}
      >
        No rating yet
      </span>
    );
  }

  const safeRating = Math.min(
    totalStars,
    Math.max(0, Math.round(rating * 10) / 10),
  );
  const ratingDisplay = safeRating.toFixed(1);
  const fullStars = Math.floor(safeRating);
  const hasHalfStar = safeRating - fullStars >= 0.5 && fullStars < totalStars;

  if (commentId) {
    const safeCommentRating = Math.max(
      0,
      Math.min(totalStars, Math.round(rating)),
    );
    return (
      <section
        className="review-card__rating"
        role={aria.hidden ? undefined : "img"}
        aria-label={
          aria.label ?? `Rated ${safeCommentRating} out of ${totalStars}`
        }
      >
        <section
          className="rating rating--compact"
          aria-hidden={aria.hidden ? "true" : "false"}
        >
          {Array.from({ length: totalStars }, (_, index) => (
            <span
              key={`comment-${commentId}-star-${index}`}
              className={`rating__icon${index < safeCommentRating ? " rating__icon--filled" : ""}`}
              aria-hidden="true"
            >
              {"\u2605"}
            </span>
          ))}
        </section>
      </section>
    );
  }

  const ratingClasses = `rating rating--${variant}`;

  return (
    <p
      className={ratingClasses}
      role={aria.hidden ? undefined : "img"}
      aria-label={aria.label ?? `Rating: ${ratingDisplay} out of ${totalStars}`}
      aria-hidden={aria.hidden ? "true" : undefined}
    >
      {Array.from({ length: totalStars }, (_, index) => {
        const isFilled = index < fullStars;
        const isHalf = !isFilled && hasHalfStar && index === fullStars;
        const className = `rating__icon${isFilled ? " rating__icon--filled" : ""}${isHalf ? " rating__icon--half" : ""}`;
        return (
          <span
            key={`rating-star-${index}`}
            className={className}
            aria-hidden="true"
          >
            {"\u2605"}
          </span>
        );
      })}
      {showValue ? (
        <span className="rating__value">{ratingDisplay}</span>
      ) : null}
      {showCount && typeof count === "number" ? (
        <span className="rating__count">({count})</span>
      ) : null}
    </p>
  );
};

export default StarDisplay;
export { StarDisplay };
