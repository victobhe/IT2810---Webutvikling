import {
  DIFFICULTY_LABELS,
  DIFFICULTY_ORDER,
  type DifficultyValue,
  type FiltersState,
  type SortOption,
} from "../utils/recipeFilters";
import { useDifficultyMenu } from "../hooks/useDifficultyMenu";
import "../styles/recipeDetail.css";

interface FilterAvailability {
  vegetarian: boolean;
  glutenFree: boolean;
  difficulty: Array<{ level: DifficultyValue; available: boolean }>;
  areas: Array<{ value: string; label: string; available: boolean }>;
}

interface RecipesFilterPanelProps {
  search: string;
  onSearchChange: (value: string) => void;
  onSearchSubmit?: () => void;
  filters: FiltersState;
  onToggleBooleanFilter: (key: "vegetarian" | "glutenFree") => void;
  onToggleDifficultyFilter: (value: DifficultyValue) => void;
  onClearDifficultyFilter: () => void;
  onAreaChange: (value: string) => void;
  onSearchIngredientsChange: (checked: boolean) => void;
  availability: FilterAvailability;
  disabledFilters: {
    vegetarian: boolean;
    glutenFree: boolean;
  };
  originFilterDisabled: boolean;
  sort: SortOption;
  onSortChange: (value: string) => void;
  hasActiveFilters: boolean;
  onResetFilters: () => void;
}

export function RecipesFilterPanel({
  search,
  onSearchChange,
  onSearchSubmit,
  filters,
  onToggleBooleanFilter,
  onToggleDifficultyFilter,
  onClearDifficultyFilter,
  onAreaChange,
  onSearchIngredientsChange,
  availability,
  disabledFilters,
  originFilterDisabled,
  sort,
  onSortChange,
  hasActiveFilters,
  onResetFilters,
}: RecipesFilterPanelProps) {
  const { isDifficultyMenuOpen, setDifficultyMenuOpen, difficultyMenuRef } =
    useDifficultyMenu();
  const {
    isDifficultyMenuOpen: isOriginMenuOpen,
    setDifficultyMenuOpen: setOriginMenuOpen,
    difficultyMenuRef: originMenuRef,
  } = useDifficultyMenu();
  const {
    isDifficultyMenuOpen: isSortMenuOpen,
    setDifficultyMenuOpen: setSortMenuOpen,
    difficultyMenuRef: sortMenuRef,
  } = useDifficultyMenu();

  const selectedDifficultyLabel =
    filters.difficulty && filters.difficulty.length > 0
      ? filters.difficulty.map((level) => DIFFICULTY_LABELS[level]).join(", ")
      : "All levels";
  const originOptions = [
    { value: "", label: "All origins", available: true },
    ...availability.areas,
  ];
  const selectedOriginLabel =
    originOptions.find((entry) => entry.value === (filters.area ?? ""))
      ?.label ?? "All origins";
  const sortOptionsList: Array<{ value: SortOption; label: string }> = [
    { value: "title-asc", label: "Title (A-Z)" },
    { value: "title-desc", label: "Title (Z-A)" },
    { value: "time-asc", label: "Shortest time" },
    { value: "time-desc", label: "Longest time" },
  ];
  const selectedSortLabel =
    sortOptionsList.find((option) => option.value === sort)?.label ?? "Sort by";

  return (
    <form
      id="filter-panel"
      className="filter-bar u-flow-sm"
      role="search"
      aria-label="Filter recipes"
      onSubmit={(event) => {
        event.preventDefault();
        onSearchSubmit?.();
      }}
    >
      <section className="filter-bar__group filter-bar__search">
        <section className="filter-bar__label-row" aria-hidden="true" />
        <section className="filter-bar__search-row">
          <section className="filter-bar__search-input">
            <input
              id="search-recipes"
              type="search"
              name="query"
              value={search}
              placeholder="Search for recipes or ingridients..."
              onChange={(event) => onSearchChange(event.target.value)}
              aria-describedby="search-help"
            />
            <span className="search-help__wrapper">
              <button
                type="button"
                className="search-help__trigger"
                aria-label="Show search tips"
                aria-describedby="search-help"
              >
                ?
              </button>
              <p id="search-help" className="search-help" role="status">
                Press Tab to move through filters. Escape closes open menus.
                Enable ingredient search to include matching ingredients.
              </p>
            </span>
          </section>
          <button
            type="submit"
            className="btn btn--ghost filter-bar__search-button"
          >
            Search
          </button>
        </section>
        <label
          className="filter-bar__checkbox"
          htmlFor="search-ingredients-toggle"
        >
          <input
            id="search-ingredients-toggle"
            type="checkbox"
            checked={Boolean(filters.searchIngredients)}
            onChange={(event) =>
              onSearchIngredientsChange(event.target.checked)
            }
          />
          <span>Search ingredients</span>
        </label>
      </section>

      <fieldset className="filter-bar__fieldset filter-bar__dietary">
        <legend className="dietary-header">Dietary filters</legend>
        <section
          className="filter-bar__chips"
          role="group"
          aria-label="Dietary filters"
        >
          <button
            type="button"
            className="tag"
            aria-pressed={!!filters.vegetarian}
            disabled={disabledFilters.vegetarian}
            onClick={() => onToggleBooleanFilter("vegetarian")}
          >
            Vegetarian
          </button>
          <button
            type="button"
            className="tag"
            aria-pressed={!!filters.glutenFree}
            disabled={disabledFilters.glutenFree}
            onClick={() => onToggleBooleanFilter("glutenFree")}
          >
            Gluten-free
          </button>
        </section>
      </fieldset>

      <fieldset className="filter-bar__fieldset filter-bar__origin">
        <legend className="filter-bar__legend">Origin</legend>
        <section className="filter-dropdown" ref={originMenuRef}>
          <button
            type="button"
            className="filter-dropdown__toggle"
            aria-haspopup="true"
            aria-expanded={isOriginMenuOpen}
            aria-label="Toggle origin filters"
            data-active={Boolean(filters.area)}
            disabled={originFilterDisabled}
            onClick={() => {
              if (!originFilterDisabled) {
                setOriginMenuOpen((prev) => !prev);
              }
            }}
          >
            <span className="filter-dropdown__value">
              {selectedOriginLabel}
            </span>
            <span className="filter-dropdown__chevron" aria-hidden="true">
              {"\u25BC"}
            </span>
          </button>
          {isOriginMenuOpen ? (
            <section
              className="filter-dropdown__menu"
              role="menu"
              aria-label="Origin filters"
            >
              {originOptions.map((entry) => {
                const isSelected = (filters.area ?? "") === entry.value;
                const optionDisabled =
                  originFilterDisabled ||
                  (!isSelected && entry.available === false);
                return (
                  <button
                    key={entry.value || "all"}
                    type="button"
                    className="filter-dropdown__option"
                    role="menuitemradio"
                    aria-checked={isSelected}
                    disabled={optionDisabled}
                    onClick={() => {
                      if (!optionDisabled) {
                        onAreaChange(entry.value);
                        setOriginMenuOpen(false);
                      }
                    }}
                  >
                    <span>{entry.label}</span>
                    {isSelected ? (
                      <span
                        className="filter-dropdown__check"
                        aria-hidden="true"
                      >
                        {"\u2713"}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </section>
          ) : null}
        </section>
        {originFilterDisabled ? (
          <p
            className="filter-bar__helper u-text-sm u-text-muted"
            role="status"
          >
            No origin filters available for the current view.
          </p>
        ) : null}
      </fieldset>

      <fieldset
        className="filter-bar__fieldset filter-bar__difficulty"
        role="group"
        aria-label="Difficulty filter"
      >
        <legend className="filter-bar__legend">Difficulty</legend>
        <section className="filter-dropdown" ref={difficultyMenuRef}>
          <button
            type="button"
            className="filter-dropdown__toggle"
            aria-haspopup="true"
            aria-expanded={isDifficultyMenuOpen}
            aria-label="Toggle difficulty filters"
            data-active={filters.difficulty && filters.difficulty.length > 0}
            onClick={() => setDifficultyMenuOpen((prev) => !prev)}
          >
            <span className="filter-dropdown__value">
              {selectedDifficultyLabel}
            </span>
            <span className="filter-dropdown__chevron" aria-hidden="true">
              {"\u25BC"}
            </span>
          </button>
          {isDifficultyMenuOpen ? (
            <section
              className="filter-dropdown__menu"
              role="menu"
              aria-label="Difficulty filters"
            >
              <button
                type="button"
                className="filter-dropdown__option"
                role="menuitemcheckbox"
                aria-checked={
                  !filters.difficulty || filters.difficulty.length === 0
                }
                onClick={onClearDifficultyFilter}
              >
                <span>All levels</span>
                {!filters.difficulty || filters.difficulty.length === 0 ? (
                  <span className="filter-dropdown__check" aria-hidden="true">
                    {"\u2713"}
                  </span>
                ) : null}
              </button>
              {DIFFICULTY_ORDER.map((level) => {
                const active = filters.difficulty?.includes(level) ?? false;
                const availabilityEntry = availability.difficulty.find(
                  (entry) => entry.level === level,
                );
                const disabled =
                  !active && !(availabilityEntry?.available ?? false);
                return (
                  <button
                    key={level}
                    type="button"
                    className="filter-dropdown__option"
                    role="menuitemcheckbox"
                    aria-checked={active}
                    disabled={disabled}
                    onClick={() => onToggleDifficultyFilter(level)}
                  >
                    <span>{DIFFICULTY_LABELS[level]}</span>
                    {active ? (
                      <span
                        className="filter-dropdown__check"
                        aria-hidden="true"
                      >
                        {"\u2713"}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </section>
          ) : null}
        </section>
      </fieldset>

      <fieldset
        className="filter-bar__fieldset filter-bar__sort"
        role="group"
        aria-label="Sort options"
      >
        <legend className="filter-bar__legend">Sort by</legend>
        <section className="filter-dropdown" ref={sortMenuRef}>
          <button
            type="button"
            className="filter-dropdown__toggle"
            aria-haspopup="true"
            aria-expanded={isSortMenuOpen}
            aria-label="Toggle sort options"
            data-active={sort !== sortOptionsList[0].value}
            onClick={() => setSortMenuOpen((prev) => !prev)}
          >
            <span className="filter-dropdown__value">{selectedSortLabel}</span>
            <span className="filter-dropdown__chevron" aria-hidden="true">
              {"\u25BC"}
            </span>
          </button>
          {isSortMenuOpen ? (
            <section
              className="filter-dropdown__menu"
              role="menu"
              aria-label="Sort menu"
            >
              {sortOptionsList.map((option) => {
                const isSelected = sort === option.value;
                return (
                  <button
                    key={option.value}
                    type="button"
                    className="filter-dropdown__option"
                    role="menuitemradio"
                    aria-checked={isSelected}
                    onClick={() => {
                      if (!isSelected) {
                        onSortChange(option.value);
                      }
                      setSortMenuOpen(false);
                    }}
                  >
                    <span>{option.label}</span>
                    {isSelected ? (
                      <span
                        className="filter-dropdown__check"
                        aria-hidden="true"
                      >
                        {"\u2713"}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </section>
          ) : null}
        </section>
      </fieldset>

      <button
        type="button"
        className="btn-reset-filters"
        onClick={onResetFilters}
        disabled={!hasActiveFilters}
      >
        Reset filters
      </button>
    </form>
  );
}
