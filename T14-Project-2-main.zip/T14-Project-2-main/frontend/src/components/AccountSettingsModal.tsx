import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { useMutation } from "@apollo/client";
import type { AuthUser } from "../graphql/auth";
import {
  UPDATE_MY_PROFILE_MUTATION,
  CHANGE_MY_PASSWORD_MUTATION,
  DELETE_MY_ACCOUNT_MUTATION,
  type UpdateMyProfileData,
  type UpdateMyProfileVars,
  type ChangeMyPasswordData,
  type ChangeMyPasswordVars,
  type DeleteMyAccountData,
  type DeleteMyAccountVars,
} from "../graphql/account";

type Props = {
  isOpen: boolean;
  onClose: () => void;
  user: AuthUser | null | undefined;
  onProfileUpdated: () => void;
  onAccountDeleted: () => void;
  dialogId?: string;
};

const MIN_PASSWORD_LENGTH = 6;

const buildErrorMessage = (error: unknown, fallback: string) => {
  if (error instanceof Error) {
    return error.message;
  }
  return fallback;
};

export default function AccountSettingsModal({
  isOpen,
  onClose,
  user,
  onProfileUpdated,
  onAccountDeleted,
  dialogId,
}: Props) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [profileStatus, setProfileStatus] = useState<string | null>(null);
  const [profileError, setProfileError] = useState<string | null>(null);
  const [updatingProfile, setUpdatingProfile] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordStatus, setPasswordStatus] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [changingPassword, setChangingPassword] = useState(false);

  const [deletePassword, setDeletePassword] = useState("");
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const [updateProfile] = useMutation<UpdateMyProfileData, UpdateMyProfileVars>(
    UPDATE_MY_PROFILE_MUTATION,
  );
  const [changePassword] = useMutation<
    ChangeMyPasswordData,
    ChangeMyPasswordVars
  >(CHANGE_MY_PASSWORD_MUTATION);
  const [deleteAccount] = useMutation<DeleteMyAccountData, DeleteMyAccountVars>(
    DELETE_MY_ACCOUNT_MUTATION,
  );

  useEffect(() => {
    if (!isOpen || !user) return;
    setName(user.name ?? "");
    setEmail(user.email);
    setProfileError(null);
    setProfileStatus(null);
    setPasswordError(null);
    setPasswordStatus(null);
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    setDeletePassword("");
    setDeleteError(null);
  }, [isOpen, user]);

  if (!isOpen || !user) {
    return null;
  }

  const modalId = dialogId ?? "account-settings-modal";

  const handleProfileSubmit = async (
    event: React.FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();
    setProfileError(null);
    setProfileStatus(null);
    const trimmedEmail = email.trim();
    if (trimmedEmail.length === 0) {
      setProfileError("Email is required.");
      return;
    }
    const trimmedName = name ? name.trim() : "";

    setUpdatingProfile(true);
    try {
      await updateProfile({
        variables: {
          input: {
            name: trimmedName || undefined,
            email: trimmedEmail,
          },
        },
      });
      setProfileStatus("Account details updated.");
      onProfileUpdated();
    } catch (err) {
      setProfileError(
        buildErrorMessage(err, "Could not update your profile right now."),
      );
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handlePasswordSubmit = async (
    event: React.FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();
    setPasswordError(null);
    setPasswordStatus(null);
    if (newPassword !== confirmPassword) {
      setPasswordError("New passwords do not match.");
      return;
    }
    if (newPassword.length < MIN_PASSWORD_LENGTH) {
      setPasswordError(
        `Password must be at least ${MIN_PASSWORD_LENGTH} characters.`,
      );
      return;
    }
    setChangingPassword(true);
    try {
      await changePassword({
        variables: {
          currentPassword,
          newPassword,
        },
      });
      setPasswordStatus("Password updated.");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      setPasswordError(
        buildErrorMessage(err, "Could not change your password right now."),
      );
    } finally {
      setChangingPassword(false);
    }
  };

  const handleDeleteSubmit = async (
    event: React.FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();
    setDeleteError(null);
    if (deletePassword.trim().length === 0) {
      setDeleteError("Password is required.");
      return;
    }
    const confirmed = window.confirm(
      "This will permanently delete your account, favorites, and reviews. Continue?",
    );
    if (!confirmed) return;
    setDeleting(true);
    try {
      await deleteAccount({ variables: { password: deletePassword } });
      onAccountDeleted();
    } catch (err) {
      setDeleteError(
        buildErrorMessage(err, "Could not delete your account right now."),
      );
    } finally {
      setDeleting(false);
    }
  };

  const handleOverlayClick = (event: React.MouseEvent<HTMLElement>) => {
    if (event.target === event.currentTarget) {
      onClose();
    }
  };

  const body = (
    <section
      className="modal-overlay"
      role="presentation"
      onClick={handleOverlayClick}
    >
      <article
        className="modal account-modal"
        id={modalId}
        role="dialog"
        aria-modal="true"
        aria-labelledby="account-settings-title"
        onClick={(event) => event.stopPropagation()}
      >
        <header className="modal__header">
          <h2 id="account-settings-title">Account</h2>
          <button
            type="button"
            className="modal__close"
            aria-label="Close account settings"
            onClick={onClose}
          >
            x
          </button>
        </header>
        <section className="modal__body account-modal__body">
          <form
            className="account-modal__section"
            onSubmit={handleProfileSubmit}
          >
            <fieldset>
              <legend>Profile</legend>
              <section className="account-modal__field">
                <label htmlFor="account-name">Name</label>
                <input
                  id="account-name"
                  type="text"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  placeholder="Add your name"
                  autoComplete="name"
                />
              </section>
              <section className="account-modal__field">
                <label htmlFor="account-email">Email</label>
                <input
                  id="account-email"
                  type="email"
                  required
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  autoComplete="email"
                />
              </section>
            </fieldset>
            {profileError ? (
              <p role="alert" className="modal__error">
                {profileError}
              </p>
            ) : null}
            {profileStatus ? (
              <p className="modal__helper" role="status" aria-live="polite">
                {profileStatus}
              </p>
            ) : null}
            <button
              type="submit"
              className="btn btn--accent"
              disabled={updatingProfile}
            >
              {updatingProfile ? "Saving..." : "Save changes"}
            </button>
          </form>

          <form
            className="account-modal__section"
            onSubmit={handlePasswordSubmit}
          >
            <fieldset>
              <legend>Password</legend>
              <section className="account-modal__field">
                <label htmlFor="account-current-password">Current</label>
                <input
                  id="account-current-password"
                  type="password"
                  value={currentPassword}
                  onChange={(event) => setCurrentPassword(event.target.value)}
                  autoComplete="current-password"
                  required
                />
              </section>
              <section className="account-modal__field">
                <label htmlFor="account-new-password">New</label>
                <input
                  id="account-new-password"
                  type="password"
                  value={newPassword}
                  onChange={(event) => setNewPassword(event.target.value)}
                  autoComplete="new-password"
                  required
                />
              </section>
              <section className="account-modal__field">
                <label htmlFor="account-confirm-password">Confirm</label>
                <input
                  id="account-confirm-password"
                  type="password"
                  value={confirmPassword}
                  onChange={(event) => setConfirmPassword(event.target.value)}
                  autoComplete="new-password"
                  required
                />
              </section>
            </fieldset>
            {passwordError ? (
              <p role="alert" className="modal__error">
                {passwordError}
              </p>
            ) : null}
            {passwordStatus ? (
              <p className="modal__helper" role="status" aria-live="polite">
                {passwordStatus}
              </p>
            ) : null}
            <button
              type="submit"
              className="btn btn--subtle"
              disabled={changingPassword}
            >
              {changingPassword ? "Updating..." : "Update password"}
            </button>
          </form>

          <form
            className="account-modal__section account-modal__section--danger"
            onSubmit={handleDeleteSubmit}
          >
            <fieldset>
              <legend>Delete account</legend>
              <p className="modal__helper">Remove your profile permanently.</p>
              <section className="account-modal__field">
                <label htmlFor="account-delete-password">Password</label>
                <input
                  id="account-delete-password"
                  type="password"
                  value={deletePassword}
                  onChange={(event) => setDeletePassword(event.target.value)}
                  autoComplete="current-password"
                  required
                />
              </section>
            </fieldset>
            {deleteError ? (
              <p role="alert" className="modal__error">
                {deleteError}
              </p>
            ) : null}
            <button
              type="submit"
              className="btn btn--ghost account-modal__delete"
              disabled={deleting}
            >
              {deleting ? "Deleting..." : "Delete account"}
            </button>
          </form>
        </section>
      </article>
    </section>
  );

  return createPortal(body, document.body);
}
