import { gql, useMutation, useQuery } from "@apollo/client";
import React, {
  useEffect,
  useMemo,
  useState,
  useLayoutEffect,
  useCallback,
  useRef,
} from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { Heart } from "lucide-react";
import Header from "./Header";
import StarRating from "./starRating";
import StarDisplay from "./StarDisplay";
import "../styles/recipeDetail.css";
import { scrollInstant } from "../utils/instantScroll";
import { useAuth } from "../contexts/useAuth";
import { resolveImageUrl } from "../utils/resolveImageUrl";
import {
  COMMENT_SORT_OPTIONS,
  sortCommentsBy,
  type CommentSortOrder,
} from "../utils/commentSorting";
import { useRatingStars } from "../hooks/useRatingStars";
import { useFavoriteToggle } from "../hooks/useFavoriteToggle";
import { APOLLO_QUERY_POLICIES } from "../config/apolloPolicies";
import {
  RATE_RECIPE_MUTATION,
  ADD_COMMENT_MUTATION,
  DELETE_COMMENT_MUTATION,
  type RateRecipeData,
  type AddCommentData,
  type DeleteCommentData,
} from "../graphql/recipeActions";

const DUPLICATE_COMMENT_ERROR =
  "You can only leave one comment and one rating per review. Delete your previous review to share another one.";
const COMMENTS_PAGE_SIZE = 10;
const COMMENTS_REQUEST_SIZE = COMMENTS_PAGE_SIZE + 1;
const MAX_COMMENT_LENGTH = 500;

type RecipeUser = {
  id: string;
  name?: string | null;
  email: string;
};

type RecipeComment = {
  id: string;
  body: string;
  createdAt: string;
  updatedAt: string;
  user: RecipeUser;
  rating?: number | null;
};

type CommentRatingProps = {
  rating?: number | null;
  commentId: string;
};

const CommentRating = ({ rating, commentId }: CommentRatingProps) => {
  const ratingStars = useRatingStars(rating, { fallback: 0 });

  return (
    <StarDisplay
      rating={ratingStars.ratingValue ?? 0}
      commentId={commentId}
      variant="compact"
      showValue={false}
    />
  );
};

export type Recipe = {
  id: string;
  title: string;
  time?: number | null;
  difficulty?: string | null;
  category?: string | null;
  area?: string | null;
  vegetarian?: boolean | null;
  glutenFree?: boolean | null;
  ingredients?: string[];
  steps?: string[];
  instructions?: string | null;
  image?: string | null;
  source?: string | null;
  averageRating?: number | null;
  ratingCount?: number | null;
  isFavorite?: boolean;
  myRating?: number | null;
};

type RouteParams = { id: string };
type LocationState = { recipe?: Recipe; imageUrl?: string; rating?: number };

const GET_RECIPE = gql`
  query GetRecipe($id: ID!) {
    recipe(id: $id) {
      id
      title
      time
      category
      area
      vegetarian
      glutenFree
      difficulty
      image
      instructions
      ingredients
      steps
      source
      averageRating
      ratingCount
      isFavorite
      myRating
    }
  }
`;

const GET_COMMENTS = gql`
  query GetComments($recipeId: ID!, $first: Int, $after: ID) {
    comments(recipeId: $recipeId, first: $first, after: $after) {
      id
      body
      createdAt
      updatedAt
      rating
      user {
        id
        name
        email
      }
    }
  }
`;

type RecipeQueryData = { recipe: Recipe | null };
type RecipeQueryVars = { id: string };
type CommentsQueryData = { comments: RecipeComment[] };
type CommentsQueryVars = {
  recipeId: string;
  first?: number | null;
  after?: string | null;
};

const splitCommentPage = (incoming: RecipeComment[]) => {
  const hasMore = incoming.length > COMMENTS_PAGE_SIZE;
  const items = hasMore ? incoming.slice(0, COMMENTS_PAGE_SIZE) : [...incoming];
  const nextCursor =
    hasMore && items.length > 0 ? (items[items.length - 1]?.id ?? null) : null;
  return { items, nextCursor, hasMore };
};

function mergeRecipeData(
  ...sources: Array<Recipe | null | undefined>
): Recipe | undefined {
  const cleanedSources = sources.filter(Boolean) as Recipe[];
  if (cleanedSources.length === 0) return undefined;

  const result: Partial<Recipe> = {};

  const assign = <K extends keyof Recipe>(key: K, value: Recipe[K]) => {
    if (value === undefined || value === null) return;
    if (Array.isArray(value)) {
      if (value.length === 0) return;
      result[key] = [...value];
      return;
    }
    if (typeof value === "string") {
      if (value.trim().length === 0) return;
      result[key] = value;
      return;
    }
    result[key] = value;
  };

  for (const candidate of cleanedSources) {
    assign("id", candidate.id);
    assign("title", candidate.title);
    assign("time", candidate.time ?? undefined);
    assign("difficulty", candidate.difficulty ?? undefined);
    assign("vegetarian", candidate.vegetarian ?? undefined);
    assign("glutenFree", candidate.glutenFree ?? undefined);
    assign("ingredients", candidate.ingredients ?? undefined);
    assign("steps", candidate.steps ?? undefined);
    assign("instructions", candidate.instructions ?? undefined);
    assign("image", candidate.image ?? undefined);
    assign("source", candidate.source ?? undefined);
    assign("averageRating", candidate.averageRating ?? undefined);
    assign("ratingCount", candidate.ratingCount ?? undefined);
    assign("isFavorite", candidate.isFavorite ?? undefined);
    assign("myRating", candidate.myRating ?? undefined);
  }

  if (!result.id || !result.title) return undefined;
  return result as Recipe;
}

const measurementCandidates = new Set([
  "cup",
  "cups",
  "tbsp",
  "tablespoon",
  "tablespoons",
  "tsp",
  "teaspoon",
  "teaspoons",
  "g",
  "kg",
  "mg",
  "ml",
  "l",
  "dl",
  "cl",
  "oz",
  "lbs",
  "lb",
  "stk",
  "ss",
  "ts",
]);

const STEP_PREFIX = /^\s*\d+\s*(?:[.)]|-|–|—)\s*(?:step|steg|trinn)?\s*:?\s*/i;

const stripStepPrefix = (value: string): string =>
  value.replace(STEP_PREFIX, "").trim();

const normalizeStep = (value: unknown): string => {
  const text = stripStepPrefix(String(value ?? ""));
  if (/^(?:\d+\s*[.)]?)?$/.test(text)) return "";
  return text;
};

const splitIngredient = (value: string): { amount?: string; item: string } => {
  const trimmed = value.trim();
  if (trimmed.length === 0) return { item: "" };
  const parts = trimmed.split(/\s+/);
  if (parts.length === 1) return { item: trimmed };

  const first = parts[0];
  const second = parts[1]?.toLowerCase();
  const numberLike = /^[\d¼½¾⅓⅔⅛⅜⅝⅞.,/+-]+$/;

  if (numberLike.test(first)) {
    if (second && measurementCandidates.has(second)) {
      return {
        amount: `${first} ${parts[1]}`,
        item: parts.slice(2).join(" ") || parts[1],
      };
    }
    return { amount: first, item: parts.slice(1).join(" ") };
  }

  return { item: trimmed };
};

const favoriteToastMessage = (saved: boolean, title: string) =>
  saved
    ? `${title} was added to favorites.`
    : `${title} was removed from favorites.`;

const formatDuration = (minutes?: number | null): string => {
  if (typeof minutes !== "number" || Number.isNaN(minutes) || minutes <= 0) {
    return "Unknown time";
  }
  if (minutes < 60) {
    return `${minutes} minutes`;
  }
  const mins = Math.round(minutes);
  const hours = Math.floor(mins / 60);
  const rest = mins % 60;
  if (rest === 0) {
    return `${hours} ${hours === 1 ? "hour" : "hours"}`;
  }
  return `${hours} h ${rest} min`;
};

export default function RecipeDetail(): React.ReactElement {
  const { id } = useParams<RouteParams>();
  const location = useLocation();
  const navigate = useNavigate();
  const state = (location.state ?? null) as LocationState | null;
  const { user, openLogin } = useAuth();
  const userId = user?.id;

  useLayoutEffect(() => {
    scrollInstant(0);
  }, [id]);

  const goBackToRecipes = useCallback(() => {
    if (typeof window !== "undefined" && window.history.length > 1) {
      navigate(-1);
      return;
    }
    navigate("/recipes");
  }, [navigate]);

  const [comments, setComments] = useState<RecipeComment[]>([]);
  const [commentSort, setCommentSort] = useState<CommentSortOrder>("newest");
  const sortedComments = useMemo(
    () => sortCommentsBy(comments, commentSort),
    [comments, commentSort],
  );
  const [commentCursor, setCommentCursor] = useState<string | null>(null);
  const [hasMoreComments, setHasMoreComments] = useState(false);
  const [loadingMoreComments, setLoadingMoreComments] = useState(false);
  const initialCommentsLoadedRef = useRef(false);
  const [commentText, setCommentText] = useState("");
  const [commentError, setCommentError] = useState<string | null>(null);
  const [submittingComment, setSubmittingComment] = useState(false);
  const [isCommentLimitNoticeOpen, setCommentLimitNoticeOpen] = useState(false);

  const {
    data,
    loading,
    error: recipeError,
    refetch: refetchRecipe,
  } = useQuery<RecipeQueryData, RecipeQueryVars>(GET_RECIPE, {
    ...APOLLO_QUERY_POLICIES.recipeDetails,
    skip: !id,
    variables: { id: id! },
  });
  const handleRetryRecipe = useCallback(() => {
    if (!id) return;
    void refetchRecipe({ id });
  }, [id, refetchRecipe]);
  const {
    data: commentsData,
    loading: commentsLoading,
    error: commentsError,
    fetchMore: fetchMoreComments,
    refetch: refetchComments,
  } = useQuery<CommentsQueryData, CommentsQueryVars>(GET_COMMENTS, {
    ...APOLLO_QUERY_POLICIES.recipeComments,
    skip: !id,
    variables: { recipeId: id!, first: COMMENTS_REQUEST_SIZE },
  });
  const { toggle: toggleFavorite } = useFavoriteToggle();
  const [rateRecipeMutation] =
    useMutation<RateRecipeData>(RATE_RECIPE_MUTATION);
  const [addCommentMutation] =
    useMutation<AddCommentData>(ADD_COMMENT_MUTATION);
  const [deleteCommentMutation] = useMutation<DeleteCommentData>(
    DELETE_COMMENT_MUTATION,
  );
  const isInitialCommentsLoading =
    commentsLoading && !initialCommentsLoadedRef.current;
  const showCommentSkeleton = isInitialCommentsLoading && !commentsError;
  const commentSkeleton = useMemo(
    () => (
      <ul className="review-list__items" aria-hidden="true">
        {Array.from({ length: 3 }).map((_, index) => (
          <li key={`comment-skeleton-${index}`}>
            <article className="review-card review-card--skeleton">
              <header className="review-card__header">
                <section className="review-card__author">
                  <span className="skeleton-line skeleton-line--title" />
                  <span className="skeleton-line skeleton-line--meta" />
                </section>
                <span className="skeleton-line skeleton-line--rating" />
              </header>
              <p className="skeleton-line skeleton-line--body" />
              <p className="skeleton-line skeleton-line--body skeleton-line--short" />
            </article>
          </li>
        ))}
      </ul>
    ),
    [],
  );

  const reviewerDisplayName = useMemo(() => {
    if (!user) return "";
    const cleanName = typeof user.name === "string" ? user.name.trim() : "";
    return cleanName.length > 0 ? cleanName : user.email;
  }, [user]);

  const userComment = useMemo(() => {
    if (!userId) return null;
    return comments.find((comment) => comment.user.id === userId) ?? null;
  }, [comments, userId]);

  const hasUserComment = Boolean(userComment);
  const commentFieldReadOnly = !user || hasUserComment;
  const ratingReadOnly = !user || hasUserComment;
  const commentFieldDisabled = submittingComment;
  const commentPlaceholder = hasUserComment
    ? "You already left a review for this recipe."
    : "Share your thoughts about this recipe...";
  const closeCommentLimitNotice = useCallback(
    () => setCommentLimitNoticeOpen(false),
    [],
  );

  useEffect(() => {
    if (!hasUserComment && commentError === DUPLICATE_COMMENT_ERROR) {
      setCommentError(null);
    }
  }, [commentError, hasUserComment]);

  useEffect(() => {
    if (!hasUserComment) {
      setCommentLimitNoticeOpen(false);
    }
  }, [hasUserComment]);

  useEffect(() => {
    if (!isCommentLimitNoticeOpen || typeof window === "undefined") return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setCommentLimitNoticeOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isCommentLimitNoticeOpen]);

  const handleCommentFieldIntent = useCallback(() => {
    if (!user) {
      openLogin();
      return;
    }
    if (hasUserComment) {
      setCommentLimitNoticeOpen(true);
    }
  }, [hasUserComment, openLogin, user]);

  const handleRatingIntent = useCallback(() => {
    if (!user) {
      openLogin();
      return;
    }
    if (hasUserComment) {
      setCommentLimitNoticeOpen(true);
    }
  }, [hasUserComment, openLogin, user]);

  const recipe = useMemo(() => {
    const merged = mergeRecipeData(state?.recipe ?? null, data?.recipe ?? null);
    if (!merged) return undefined;
    if (!merged.id && id) {
      return { ...merged, id };
    }
    return merged;
  }, [data?.recipe, id, state?.recipe]);

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isToastVisible, setToastVisible] = useState(false);
  const showToast = useCallback((message: string) => {
    setToastVisible(false);
    setToastMessage(message);
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const frame = window.requestAnimationFrame(() => setToastVisible(true));
    const hideTimer = window.setTimeout(() => setToastVisible(false), 2000);
    return () => {
      window.cancelAnimationFrame(frame);
      window.clearTimeout(hideTimer);
    };
  }, [toastMessage]);

  useEffect(() => {
    setComments([]);
    setCommentSort("newest");
    setCommentCursor(null);
    setHasMoreComments(false);
    initialCommentsLoadedRef.current = false;
  }, [id]);

  useEffect(() => {
    if (!id) return;
    if (initialCommentsLoadedRef.current) return;
    if (!commentsData?.comments) return;
    const { items, nextCursor, hasMore } = splitCommentPage(
      commentsData.comments,
    );
    setComments(items);
    setCommentCursor(nextCursor);
    setHasMoreComments(hasMore);
    initialCommentsLoadedRef.current = true;
  }, [commentsData?.comments, id]);

  const handleRetryComments = useCallback(() => {
    if (!id) return;
    initialCommentsLoadedRef.current = false;
    setComments([]);
    setCommentCursor(null);
    setHasMoreComments(false);
    void refetchComments({ recipeId: id, first: COMMENTS_REQUEST_SIZE }).catch(
      () => {
        setToastMessage("Could not refresh comments.");
      },
    );
  }, [id, refetchComments]);

  const isFavorite = recipe?.isFavorite ?? false;

  // Normalize rating display from cache (avoid duplicate calculations)
  const heroRating = useRatingStars(recipe?.averageRating, { fallback: 0 });
  const imageSrc =
    resolveImageUrl(recipe?.image ?? state?.imageUrl) ||
    `https://www.themealdb.com/images/media/meals/llcbn01574260722.jpg`;

  const recipeLead = useMemo(() => {
    if (recipe?.category || recipe?.area) {
      return `Explore ${recipe.title} - a ${recipe.category?.toLowerCase() ?? "versatile"} dish with roots in ${
        recipe.area ?? "an unknown origin"
      }.`;
    }
    if (recipe?.instructions) {
      const trimmed = recipe.instructions.trim();
      if (trimmed.length === 0) return null;
      const sentences = trimmed.split(/(?<=\.)\s+/);
      const firstSentence = sentences.find(
        (sentence) => sentence.trim().length > 0,
      );
      if (!firstSentence) return null;
      if (firstSentence.length > 180) {
        return `${firstSentence.slice(0, 177)}...`;
      }
      return firstSentence;
    }
    return null;
  }, [recipe?.instructions, recipe?.category, recipe?.area, recipe?.title]);

  const sanitizedSteps = useMemo(() => {
    if (!recipe || !Array.isArray(recipe.steps)) return [];
    return recipe.steps.map(normalizeStep).filter(Boolean);
  }, [recipe]);

  const fallbackInstructions = useMemo(() => {
    if (!recipe?.instructions) return null;
    const clean = recipe.instructions
      .split(/\r?\n+/)
      .map((line) => stripStepPrefix(line).trim())
      .filter((line) => line.length > 0)
      .join("\n");
    return clean.length > 0 ? clean : null;
  }, [recipe?.instructions]);

  const handleFavoriteToggle = useCallback(async () => {
    if (!recipe) return;
    if (!user) {
      openLogin();
      return;
    }

    const result = await toggleFavorite(recipe.id, isFavorite);
    if (result.success) {
      showToast(
        favoriteToastMessage(result.newState ?? !isFavorite, recipe.title),
      );
    } else {
      showToast(result.error ?? "Could not update favorites right now.");
    }
  }, [recipe, user, openLogin, isFavorite, toggleFavorite, showToast]);

  const handleRatingChange = (value: number) => {
    if (!recipe) return;
    if (!user) {
      openLogin();
      return;
    }

    rateRecipeMutation({
      variables: { recipeId: recipe.id, value },
      optimisticResponse: {
        rateRecipe: {
          recipeId: recipe.id,
          average: value,
          count: Math.max(
            (recipe.ratingCount ?? 0) + (recipe.myRating ? 0 : 1),
            1,
          ),
        },
      },
      update: (cache, { data }) => {
        const next = data?.rateRecipe;
        const cacheId = cache.identify({ __typename: "Recipe", id: recipe.id });
        if (!cacheId) return;
        cache.modify({
          id: cacheId,
          fields: {
            averageRating: () => next?.average ?? value,
            ratingCount: () => next?.count ?? recipe.ratingCount ?? 1,
            myRating: () => value,
          },
        });
      },
    })
      .then(() => {
        showToast("Thanks for rating!");
      })
      .catch(() => {
        showToast("Could not update your rating right now.");
      });
  };

  const handleCommentSubmit = async (
    event: React.FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();
    if (!recipe) return;
    if (!user) {
      openLogin();
      return;
    }
    if (hasUserComment) {
      setCommentError(DUPLICATE_COMMENT_ERROR);
      setCommentLimitNoticeOpen(true);
      return;
    }
    const body = commentText.trim();
    if (body.length === 0) {
      setCommentError("Please enter a comment.");
      return;
    }
    if (body.length > MAX_COMMENT_LENGTH) {
      setCommentError(
        `Comments cannot exceed ${MAX_COMMENT_LENGTH} characters.`,
      );
      return;
    }
    setCommentError(null);
    setSubmittingComment(true);
    try {
      const commentVariables: CommentsQueryVars = {
        recipeId: recipe.id,
        first: COMMENTS_REQUEST_SIZE,
      };
      const result = await addCommentMutation({
        variables: { recipeId: recipe.id, body },
        update: (cache, { data: mutationData }) => {
          const newComment = mutationData?.addComment;
          if (!newComment) return;
          setComments((prev) => [
            newComment,
            ...prev.filter((comment) => comment.id !== newComment.id),
          ]);
          cache.updateQuery<CommentsQueryData, CommentsQueryVars>(
            { query: GET_COMMENTS, variables: commentVariables },
            (existing) => {
              const existingList = existing?.comments ?? [];
              const merged = [
                newComment,
                ...existingList.filter(
                  (comment) => comment.id !== newComment.id,
                ),
              ];
              return { comments: merged.slice(0, COMMENTS_REQUEST_SIZE) };
            },
          );
        },
      });
      const newComment = result.data?.addComment;
      if (newComment) {
        setCommentText("");
        showToast("Thanks for sharing your review!");
      }
    } catch (err) {
      setCommentError(
        err instanceof Error ? err.message : "Could not post your comment.",
      );
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!user) {
      openLogin();
      return;
    }
    if (!window.confirm("Delete this comment?")) return;
    try {
      const commentVariables: CommentsQueryVars = {
        recipeId: recipe.id,
        first: COMMENTS_REQUEST_SIZE,
      };
      const result = await deleteCommentMutation({
        variables: { commentId },
        update: (cache) => {
          cache.updateQuery<CommentsQueryData, CommentsQueryVars>(
            { query: GET_COMMENTS, variables: commentVariables },
            (existing) => {
              if (!existing) return existing;
              return {
                comments: existing.comments.filter(
                  (comment) => comment.id !== commentId,
                ),
              };
            },
          );
        },
      });
      if (result.data?.deleteMyComment) {
        setComments((prev) =>
          prev.filter((comment) => comment.id !== commentId),
        );
        showToast("Comment deleted.");
      }
    } catch {
      setToastMessage("Could not delete the comment.");
    }
  };

  const handleLoadMoreComments = useCallback(async () => {
    if (!id || loadingMoreComments || !hasMoreComments || !commentCursor) {
      return;
    }
    setLoadingMoreComments(true);
    try {
      const { data: moreData } = await fetchMoreComments({
        variables: {
          recipeId: id,
          first: COMMENTS_REQUEST_SIZE,
          after: commentCursor,
        },
        updateQuery: (previous) => previous,
      });
      const incoming = moreData?.comments ?? [];
      if (incoming.length === 0) {
        setHasMoreComments(false);
        setCommentCursor(null);
        return;
      }
      const { items, nextCursor, hasMore } = splitCommentPage(incoming);
      setComments((prev) => {
        const seen = new Set(prev.map((comment) => comment.id));
        const merged = [...prev];
        for (const comment of items) {
          if (!seen.has(comment.id)) {
            merged.push(comment);
          }
        }
        return merged;
      });
      setCommentCursor(nextCursor);
      setHasMoreComments(hasMore);
    } catch {
      setToastMessage("Could not load more comments right now.");
    } finally {
      setLoadingMoreComments(false);
    }
  }, [
    commentCursor,
    fetchMoreComments,
    hasMoreComments,
    id,
    loadingMoreComments,
  ]);

  if (recipeError) {
    return (
      <>
        <Header />
        <main id="recipe-main" tabIndex={-1} className="u-flow">
          <section className="alert alert--error" role="alert">
            <p>Could not load this recipe right now.</p>
            <section className="u-flex u-gap-sm">
              <button
                type="button"
                className="btn btn--ghost"
                onClick={handleRetryRecipe}
              >
                Try again
              </button>
              <button
                type="button"
                className="btn btn--ghost"
                onClick={goBackToRecipes}
              >
                Back to recipes
              </button>
            </section>
          </section>
        </main>
      </>
    );
  }
  if (!recipe) {
    return (
      <>
        <Header />
        <main id="recipe-main" tabIndex={-1} className="u-flow">
          <p role="status">
            {loading ? "Loading recipe..." : "Recipe not found."}
          </p>
          <button
            type="button"
            className="btn btn--ghost"
            onClick={goBackToRecipes}
          >
            Back to recipes
          </button>
        </main>
      </>
    );
  }

  return (
    <>
      <Header />

      <main id="recipe-main" tabIndex={-1} className="recipe-detail">
        <button
          type="button"
          className="btn btn--ghost u-hide-on-print"
          onClick={goBackToRecipes}
        >
          <span aria-hidden="true">←</span>
          <span>Back to recipes</span>
        </button>

        <section className="recipe-hero">
          <article
            className="recipe-header panel panel--subtle section"
            aria-labelledby="recipe-title"
          >
            <section className="recipe-header__media recipe-media">
              <img
                src={imageSrc}
                alt={recipe.title}
                width={1200}
                height={800}
              />
              <button
                type="button"
                className="recipe-header__favorite u-hide-on-print"
                aria-label={
                  isFavorite ? "Remove favorite" : "Save to favorites"
                }
                aria-pressed={isFavorite}
                onClick={handleFavoriteToggle}
              >
                <Heart
                  className="recipe-header__favorite-icon"
                  size={40}
                  strokeWidth={1.75}
                  fill={isFavorite ? "currentColor" : "none"}
                />
                <span className="sr-only">
                  {isFavorite ? "Remove favorite" : "Save to favorites"}
                </span>
              </button>
            </section>
            <section className="recipe-header__content">
              <section className="meta-cluster recipe-meta">
                <StarDisplay
                  rating={heroRating.ratingValue ?? 0}
                  variant="lg"
                  showValue={true}
                  showCount={true}
                  count={recipe.ratingCount ?? undefined}
                />
                <span className="badge">
                  Time
                  <strong>{formatDuration(recipe.time)}</strong>
                </span>
                <span className="badge">
                  Difficulty
                  <strong>{recipe.difficulty ?? "Unknown"}</strong>
                </span>
                <span className="badge">
                  Servings
                  <strong>{recipe.category ?? "Flexible"}</strong>
                </span>
                {recipe.area ? (
                  <span className="badge">
                    Cuisine
                    <strong>{recipe.area}</strong>
                  </span>
                ) : null}
              </section>

              <h1 id="recipe-title" className="recipe-detail__title">
                {recipe.title}
              </h1>
              {recipeLead ? (
                <p className="recipe-header__lede">
                  {recipeLead.replace(/^\s*\d+\.\s*/, "")}
                </p>
              ) : null}
              <section className="meta-cluster">
                {recipe.vegetarian === true ? (
                  <span className="tag">Vegetarian</span>
                ) : null}
                {recipe.glutenFree === true ? (
                  <span className="tag">Gluten-free</span>
                ) : null}
              </section>
            </section>
          </article>

          <section
            className="recipe-actions u-hide-on-print panel panel--subtle section"
            role="complementary"
            aria-label="Recipe actions"
          >
            <button
              type="button"
              className="btn btn--ghost"
              onClick={() => window.print()}
            >
              Print
            </button>
            {/* <button type="button" className="btn btn--ghost" onClick={handleShare}>
              Share
            </button> */}
            {recipe.source ? (
              <a
                className="btn btn--ghost"
                href={recipe.source}
                target="_blank"
                rel="noopener noreferrer"
              >
                View source
              </a>
            ) : null}
          </section>
        </section>

        {toastMessage ? (
          <section
            className={`toast u-hide-on-print${isToastVisible ? " is-visible" : ""}`}
            role="status"
            aria-live="polite"
          >
            <section className="toast__message">
              <span className="toast__title">Notification</span>
              <span>{toastMessage}</span>
            </section>
            <button
              type="button"
              data-dismiss="toast"
              onClick={() => setToastVisible(false)}
              className="btn btn--ghost"
            >
              ×
            </button>
          </section>
        ) : null}

        <section
          className="ingredients panel section"
          aria-labelledby="ingredients-title"
        >
          <section>
            <h2 id="ingredients-title">Ingredients</h2>
            <p className="u-text-sm u-text-muted">
              Check items off as you go to stay organized while cooking.
            </p>
          </section>
          {Array.isArray(recipe.ingredients) &&
          recipe.ingredients.length > 0 ? (
            <ul className="ingredients__list">
              {recipe.ingredients.map((entry, index) => {
                const parsed = splitIngredient(entry);
                const ingredientId = `ingredient-${index}`;
                return (
                  <li className="ingredients__item" key={ingredientId}>
                    <input id={ingredientId} type="checkbox" />
                    <label htmlFor={ingredientId}>
                      {parsed.amount ? (
                        <span className="ingredients__amount">
                          {parsed.amount}
                        </span>
                      ) : null}
                      <span>{parsed.item}</span>
                    </label>
                  </li>
                );
              })}
            </ul>
          ) : (
            <p>No ingredients are available for this recipe.</p>
          )}
        </section>

        <section className="steps panel section" aria-labelledby="steps-title">
          <h2 id="steps-title">Steps</h2>
          {sanitizedSteps.length > 0 ? (
            <ol className="steps__list">
              {sanitizedSteps.map((step, index) => (
                <li
                  className="steps__item"
                  key={`${index}-${step.slice(0, 6)}`}
                >
                  {step}
                </li>
              ))}
            </ol>
          ) : recipe.instructions ? (
            <p className="steps__fallback">
              {fallbackInstructions ?? recipe.instructions}
            </p>
          ) : (
            <p>No steps are available for this recipe.</p>
          )}
        </section>

        <section
          className="section section--comments u-flow review-form"
          aria-labelledby="review-title"
        >
          <h2 id="review-title">Add your review</h2>
          <form className="review-form__form" onSubmit={handleCommentSubmit}>
            <section className="review-row">
              <section className="review-field review-field--name">
                <span className="review-label">Your name</span>
                {user ? (
                  <section
                    className="review-value"
                    role="text"
                    aria-live="polite"
                  >
                    {reviewerDisplayName}
                  </section>
                ) : (
                  <button
                    type="button"
                    className="review-value review-value--action"
                    onClick={openLogin}
                  >
                    Log in to add your name
                  </button>
                )}
              </section>
              <section className="review-rating">
                <span className="review-label" id="review-rating-label">
                  Your rating
                </span>

                <section
                  className="review-stars"
                  aria-labelledby="review-rating-label"
                >
                  <StarRating
                    initialRating={recipe?.myRating ?? 0}
                    onChange={handleRatingChange}
                    isReadOnly={ratingReadOnly}
                    onBlockedAttempt={
                      ratingReadOnly ? handleRatingIntent : undefined
                    }
                  />
                </section>
              </section>
            </section>
            <section className="review-field">
              <label htmlFor="review-comment" className="review-label">
                Your comments
              </label>
              <textarea
                name="comment"
                id="review-comment"
                className="review-textarea"
                value={commentText}
                maxLength={MAX_COMMENT_LENGTH}
                onChange={(event) => setCommentText(event.target.value)}
                placeholder={commentPlaceholder}
                rows={4}
                readOnly={commentFieldReadOnly}
                disabled={commentFieldDisabled}
                onClick={handleCommentFieldIntent}
                onFocus={handleCommentFieldIntent}
                required
              />
              <small id="comment-help" className="sr-only">
                Write at least a few words.
              </small>
              {!user ? (
                <p className="review-form__helper">
                  <strong>Please log in to leave a review.</strong>
                </p>
              ) : (
                <p className="review-form__helper">
                  Your star rating is submitted together with your written
                  review.
                </p>
              )}
              {hasUserComment && isCommentLimitNoticeOpen ? (
                <section
                  className="review-limit-notice"
                  role="alertdialog"
                  aria-live="assertive"
                  aria-label="Comment limit notice"
                >
                  <p>{DUPLICATE_COMMENT_ERROR}</p>
                  <button
                    type="button"
                    className="btn btn--ghost"
                    onClick={closeCommentLimitNotice}
                  >
                    Close
                  </button>
                </section>
              ) : null}
              {commentError && !hasUserComment ? (
                <p role="alert" className="review-form__error">
                  {commentError}
                </p>
              ) : null}
            </section>
            <button
              type="submit"
              className="btn btn--primary review-submit"
              disabled={submittingComment}
            >
              {submittingComment ? "Sending…" : "Submit review"}
            </button>
          </form>

          <section className="review-list u-flow-sm" aria-live="polite">
            <h3>What others say</h3>
            {commentsError ? (
              <section className="alert alert--error" role="alert">
                <p>Could not load comments right now.</p>
                <button
                  type="button"
                  className="btn btn--ghost"
                  onClick={handleRetryComments}
                >
                  Try again
                </button>
              </section>
            ) : null}
            {showCommentSkeleton ? (
              <section role="status" aria-live="polite">
                <span className="sr-only">Loading comments…</span>
                {commentSkeleton}
              </section>
            ) : comments.length === 0 ? (
              <p>No reviews yet. Be the first!</p>
            ) : (
              <>
                <section className="review-list__controls">
                  <label
                    className="review-list__sort"
                    htmlFor="recipe-comment-sort"
                  >
                    <span>Sort comments</span>
                    <select
                      id="recipe-comment-sort"
                      value={commentSort}
                      onChange={(event) =>
                        setCommentSort(event.target.value as CommentSortOrder)
                      }
                    >
                      {COMMENT_SORT_OPTIONS.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </label>
                </section>
                <ul className="review-list__items" role="list">
                  {sortedComments.map((comment, index) => {
                    const authorName = comment.user.name ?? comment.user.email;
                    return (
                      <li key={`${comment.id}-${index}`}>
                        <article
                          className="review-card"
                          aria-labelledby={`comment-${comment.id}`}
                        >
                          <header className="review-card__header">
                            <section className="review-card__author">
                              <h4 id={`comment-${comment.id}`}>{authorName}</h4>
                              <time dateTime={comment.createdAt}>
                                {new Date(
                                  comment.createdAt,
                                ).toLocaleDateString()}
                              </time>
                            </section>
                            <section className="review-card__actions">
                              <CommentRating
                                rating={comment.rating}
                                commentId={comment.id}
                              />
                              {user?.id === comment.user.id ? (
                                <>
                                  <span
                                    className="review-card__badge"
                                    aria-label="This is your review"
                                  >
                                    Your review
                                  </span>
                                  <button
                                    type="button"
                                    className="btn btn--ghost"
                                    onClick={() =>
                                      handleDeleteComment(comment.id)
                                    }
                                  >
                                    Delete
                                  </button>
                                </>
                              ) : null}
                            </section>
                          </header>
                          <p className="review-card__body">{comment.body}</p>
                        </article>
                      </li>
                    );
                  })}
                </ul>
                {hasMoreComments ? (
                  <button
                    type="button"
                    className="btn btn--ghost review-list__load-more"
                    onClick={handleLoadMoreComments}
                    disabled={loadingMoreComments}
                  >
                    {loadingMoreComments
                      ? "Loading more comments…"
                      : "Load more comments"}
                  </button>
                ) : null}
              </>
            )}
          </section>
        </section>
      </main>
    </>
  );
}
