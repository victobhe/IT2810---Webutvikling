// src/components/RecipeList.tsx
import {
  GET_RECIPES,
  type RecipeFiltersInput,
  type RecipeSortInput,
  type RecipesQueryData,
  type RecipesQueryVars,
} from "../graphql/recipes";
import { useQuery } from "@apollo/client";

type DifficultyValue = "EASY" | "MEDIUM" | "HARD";

type Props = {
  search: string;
  sort: RecipeSortInput;
  filters: {
    vegetarian?: boolean;
    glutenFree?: boolean;
    difficulty?: DifficultyValue | DifficultyValue[];
    area?: string;
  };
};

const buildFilters = (filters: Props["filters"]): RecipeFiltersInput => {
  const next: RecipeFiltersInput = {};
  if (filters.vegetarian) next.vegetarian = true;
  if (filters.glutenFree) next.glutenFree = true;
  if (typeof filters.area === "string" && filters.area.trim().length > 0) {
    next.area = filters.area.trim();
  }
  if (filters.difficulty !== undefined) {
    if (Array.isArray(filters.difficulty)) {
      if (filters.difficulty.length > 0) next.difficulty = filters.difficulty;
    } else {
      next.difficulty = [filters.difficulty];
    }
  }
  return next;
};

export default function RecipeList({ search, sort, filters }: Props) {
  const filterVariables = buildFilters(filters);
  const trimmedSearch = search.trim();
  if (trimmedSearch) {
    filterVariables.q = trimmedSearch;
  }

  const { data, loading, error, fetchMore } = useQuery<
    RecipesQueryData,
    RecipesQueryVars
  >(GET_RECIPES, {
    variables: {
      search,
      filters: filterVariables,
      sort,
      first: 20,
    },
    notifyOnNetworkStatusChange: true,
  });

  if (error) return <p role="alert">Something went wrong.</p>;

  const items = data?.recipes.items ?? [];
  const pageInfo = data?.recipes.pageInfo;

  return (
    <section aria-busy={loading ? "true" : "false"} aria-live="polite">
      <p className="sr-only">
        {loading
          ? "Loading results..."
          : `Showing ${items.length} of ${pageInfo?.totalCount ?? 0} results`}
      </p>
      <section>
        <ul>
          {items.map((recipe, index) => (
            <li key={`${recipe.id}-${index}`}>
              <article>
                <h3>{recipe.title}</h3>
                <p>
                  {recipe.time ? `${recipe.time} min` : "Time unknown"}
                  {recipe.difficulty ? ` - ${recipe.difficulty}` : ""}
                  {recipe.category ? ` - ${recipe.category}` : ""}
                  {recipe.area ? ` - ${recipe.area}` : ""}
                  {recipe.vegetarian ? " - Vegetarian" : ""}
                  {recipe.glutenFree ? " - Gluten free" : ""}
                </p>
              </article>
            </li>
          ))}
        </ul>

        {pageInfo?.hasNextPage && (
          <button
            onClick={() =>
              fetchMore({
                variables: { after: pageInfo.endCursor ?? undefined },
              })
            }
            aria-label="Load more results"
          >
            Load more
          </button>
        )}
        {loading && <p>Loading...</p>}
      </section>
    </section>
  );
}
