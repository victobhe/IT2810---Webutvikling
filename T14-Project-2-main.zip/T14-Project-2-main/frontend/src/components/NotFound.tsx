export default function NotFound() {
  return (
    <main style={{ textAlign: "center", padding: "2rem" }}>
      <h1>404</h1>
      <p>The page you are trying to reach cannot be found.</p>
    </main>
  );
}
