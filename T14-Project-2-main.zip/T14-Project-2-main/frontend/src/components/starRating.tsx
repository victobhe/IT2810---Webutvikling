import React, {
  useEffect,
  useState,
  useCallback,
  type KeyboardEvent,
  type MouseEvent,
} from "react";
import "../styles/starRating.css";

interface StarRatingProps {
  totalStars?: number;
  initialRating?: number;
  onChange?: (rating: number) => void;
  isReadOnly?: boolean;
  onBlockedAttempt?: () => void;
}

const BLOCKED_KEYS = new Set([
  "Enter",
  " ",
  "Spacebar",
  "ArrowRight",
  "ArrowLeft",
  "ArrowUp",
  "ArrowDown",
  "Home",
  "End",
]);

const StarRating: React.FC<StarRatingProps> = ({
  totalStars = 5,
  initialRating = 0,
  onChange,
  isReadOnly = false,
  onBlockedAttempt,
}) => {
  const safeTotal = Math.max(1, Math.floor(totalStars));
  const clampValue = useCallback(
    (value: number) => Math.min(Math.max(value, 0), safeTotal),
    [safeTotal],
  );

  const [rating, setRating] = useState(() => clampValue(initialRating));
  const [hover, setHover] = useState<number | null>(null);

  useEffect(() => {
    setRating(clampValue(initialRating));
  }, [initialRating, safeTotal, clampValue]);

  const current = hover ?? rating;
  const focusTarget = rating > 0 ? rating : 1;

  const notifyBlockedAttempt = useCallback(() => {
    onBlockedAttempt?.();
  }, [onBlockedAttempt]);

  const commitRating = (value: number) => {
    const next = clampValue(value);
    if (next < 1) return;
    setRating(next);
    onChange?.(next);
  };

  const createKeyDownHandler =
    (value: number) => (event: KeyboardEvent<HTMLButtonElement>) => {
      if (isReadOnly) {
        if (BLOCKED_KEYS.has(event.key)) {
          event.preventDefault();
          notifyBlockedAttempt();
        }
        return;
      }

      const parent = event.currentTarget.parentElement;
      const focusButton = (button: Element | null) => {
        (button as HTMLButtonElement | null)?.focus();
      };

      switch (event.key) {
        case "ArrowRight":
        case "ArrowUp": {
          event.preventDefault();
          const nextValue = value === safeTotal ? safeTotal : value + 1;
          commitRating(nextValue);
          focusButton(
            event.currentTarget.nextElementSibling ?? event.currentTarget,
          );
          break;
        }
        case "ArrowLeft":
        case "ArrowDown": {
          event.preventDefault();
          const nextValue = value === 1 ? 1 : value - 1;
          commitRating(nextValue);
          focusButton(
            event.currentTarget.previousElementSibling ?? event.currentTarget,
          );
          break;
        }
        case "Home": {
          event.preventDefault();
          commitRating(1);
          focusButton(parent?.firstElementChild ?? event.currentTarget);
          break;
        }
        case "End": {
          event.preventDefault();
          commitRating(safeTotal);
          focusButton(parent?.lastElementChild ?? event.currentTarget);
          break;
        }
        default:
          break;
      }
    };

  const handleStarClick =
    (value: number) => (event: MouseEvent<HTMLButtonElement>) => {
      if (isReadOnly) {
        event.preventDefault();
        notifyBlockedAttempt();
        return;
      }
      commitRating(value);
    };

  return (
    <section
      className="stars"
      role="radiogroup"
      aria-label="Rating"
      onMouseLeave={() => setHover(null)}
    >
      {Array.from({ length: safeTotal }, (_, index) => index + 1).map(
        (value) => {
          const isActive = current >= value;
          const tabIndex = value === focusTarget ? 0 : -1;

          return (
            <button
              key={value}
              type="button"
              onClick={handleStarClick(value)}
              onMouseEnter={() => !isReadOnly && setHover(value)}
              onFocus={() => !isReadOnly && setHover(value)}
              onBlur={() => !isReadOnly && setHover(null)}
              onKeyDown={createKeyDownHandler(value)}
              aria-disabled={isReadOnly}
              className={`star-box${value === safeTotal ? " has-tooltip" : ""}`}
              role="radio"
              aria-checked={rating === value}
              aria-label={`${value} ${value === 1 ? "star" : "stars"} out of ${safeTotal}`}
              tabIndex={tabIndex}
              data-star-value={value}
              data-tooltip={value === safeTotal ? "Yummi!" : undefined}
            >
              <span
                className={`the-actual-star${isActive ? " star-filled" : ""}`}
              >
                {"\u2605"}
              </span>
            </button>
          );
        },
      )}
    </section>
  );
};

export default StarRating;
export { StarRating };
