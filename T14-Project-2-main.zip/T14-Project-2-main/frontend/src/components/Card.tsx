import type { KeyboardEvent } from "react";
import { Heart, MapPin } from "lucide-react";
import StarDisplay from "./StarDisplay";
import { useRatingStars } from "../hooks/useRatingStars";

export type Listing = {
  id: string;
  title: string;
  imageUrl?: string;
  rating?: number; // optional – some recipe data doesn't include rating
  price?: string;
  location?: string;
  tags?: string[];
};

type ListingCardProps = {
  item: Listing;
  isFavorite?: boolean;
  onFavoriteToggle?: (id: string) => void;
  onClick?: (id: string) => void;
};

const FALLBACK_IMAGE = "/assets/logo.webp";

export default function ListingCard({
  item,
  isFavorite = false,
  onFavoriteToggle,
  onClick,
}: ListingCardProps) {
  const hasNavigate = typeof onClick === "function";
  const rating = useRatingStars(item.rating);
  const hasMetaContent =
    rating.hasRating || Boolean(item.location) || Boolean(item.price);

  const handleActivate = () => {
    if (hasNavigate) {
      onClick(item.id);
    }
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLElement>) => {
    if (!hasNavigate) return;
    const target = event.target as HTMLElement | null;
    if (target?.closest(".recipe-card__favorite")) {
      return;
    }
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      onClick(item.id);
    }
  };

  const handleFavoriteKeyDown = (event: KeyboardEvent<HTMLButtonElement>) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      event.stopPropagation();
      onFavoriteToggle?.(item.id);
    }
  };

  return (
    <article
      className="recipe-card card"
      style={{ cursor: hasNavigate ? "pointer" : undefined }}
      role={hasNavigate ? "link" : undefined}
      tabIndex={hasNavigate ? 0 : undefined}
      onClick={hasNavigate ? handleActivate : undefined}
      onKeyDown={hasNavigate ? handleKeyDown : undefined}
      aria-label={hasNavigate ? `Open ${item.title}` : undefined}
    >
      <figure className="recipe-card__media">
        <img
          src={item.imageUrl ?? FALLBACK_IMAGE}
          alt={item.title}
          loading="lazy"
          width={600}
          height={400}
        />
      </figure>

      <header className="card__section card__title-area">
        <h3 className="recipe-card__title card__title">{item.title}</h3>
      </header>

      <section
        className="card__section card__meta recipe-card__meta"
        aria-label={hasMetaContent ? "Recipe details" : undefined}
      >
        {rating.hasRating && rating.ratingValue !== null ? (
          <StarDisplay
            rating={rating.ratingValue}
            variant="compact"
            showValue={true}
            showCount={false}
          />
        ) : null}

        {item.location ? (
          <address className="card__location" aria-label="Origin">
            <MapPin aria-hidden="true" />
            <span>{item.location}</span>
          </address>
        ) : null}

        {item.price ? (
          <strong className="card__price">{item.price}</strong>
        ) : null}
      </section>

      <ul
        className="card__section card__attrs"
        aria-label={item.tags && item.tags.length > 0 ? "Tags" : undefined}
      >
        {item.tags && item.tags.length > 0
          ? item.tags.map((tag, index) => (
              <li key={`${tag}-${index}`} className="tag card__attr">
                {tag}
              </li>
            ))
          : null}
      </ul>

      <button
        type="button"
        className="recipe-card__favorite"
        aria-label={isFavorite ? "Remove from favorites" : "Save to favorites"}
        aria-pressed={isFavorite}
        onClick={(event) => {
          event.stopPropagation();
          onFavoriteToggle?.(item.id);
        }}
        onKeyDown={handleFavoriteKeyDown}
      >
        <Heart
          className="recipe-card__favorite-icon"
          fill={isFavorite ? "currentColor" : "none"}
        />
      </button>
    </article>
  );
}
