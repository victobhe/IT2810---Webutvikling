import { useEffect, useState } from "react";

const STORAGE_KEY = "theme-preference";

type ThemeChoice = "light" | "dark";

const getSystemPreference = (): ThemeChoice => {
  if (typeof window === "undefined") return "light";
  return window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
};

const getInitialTheme = (): ThemeChoice => {
  if (typeof window === "undefined") return "light";
  const stored = window.localStorage.getItem(STORAGE_KEY);
  return stored === "dark" || stored === "light"
    ? stored
    : getSystemPreference();
};

const applyTheme = (theme: ThemeChoice) => {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.dataset.theme = theme;
  document.documentElement.style.colorScheme =
    theme === "dark" ? "dark" : "light";
};

const withThemeTransition = (fn: () => void) => {
  if (typeof window === "undefined" || typeof document === "undefined") {
    fn();
    return;
  }
  const root = document.documentElement;
  root.classList.add("theme-transition");
  window.requestAnimationFrame(() => {
    window.setTimeout(() => {
      root.classList.remove("theme-transition");
    }, 220);
    fn();
  });
};

export function ThemeToggle(): React.ReactElement {
  const [theme, setTheme] = useState<ThemeChoice>(() => getInitialTheme());

  useEffect(() => {
    applyTheme(theme);
    if (typeof window !== "undefined") {
      window.localStorage.setItem(STORAGE_KEY, theme);
    }
  }, [theme]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const handleChange = (event: MediaQueryListEvent) => {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored !== "light" && stored !== "dark") {
        setTheme(event.matches ? "dark" : "light");
      }
    };
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);

  const toggleTheme = () => {
    withThemeTransition(() => {
      setTheme((prev) => (prev === "light" ? "dark" : "light"));
    });
  };

  const isDark = theme === "dark";

  return (
    <button
      type="button"
      className="theme-toggle"
      onClick={toggleTheme}
      aria-pressed={isDark}
      aria-label={isDark ? "Disable dark mode" : "Enable dark mode"}
    >
      <span aria-hidden="true">{isDark ? "🌙" : "☀️"}</span>
      <span className="sr-only">
        {isDark ? "Switch to light mode" : "Switch to dark mode"}
      </span>
    </button>
  );
}

export default ThemeToggle;
