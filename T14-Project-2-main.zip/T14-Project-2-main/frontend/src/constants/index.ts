// Storage Keys
export const TOKEN_STORAGE_KEY = "dishdelish.authToken";
export const HOME_SCROLL_KEY = "home-page-scroll";
export const RECIPES_SCROLL_KEY = "recipes-page-scroll";

// Token Configuration
export const TOKEN_TTL_MS = 1000 * 60 * 60 * 2; // 2 hours

// Rating Configuration
export const DEFAULT_MAX_STARS = 5;
export const DEFAULT_DECIMALS = 1;

// Difficulty Levels
export const DIFFICULTY_EASY = "EASY";
export const DIFFICULTY_MEDIUM = "MEDIUM";
export const DIFFICULTY_HARD = "HARD";

export const DIFFICULTY_ORDER = [
  DIFFICULTY_EASY,
  DIFFICULTY_MEDIUM,
  DIFFICULTY_HARD,
] as const;

export const DIFFICULTY_LABELS: Record<string, string> = {
  [DIFFICULTY_EASY]: "Easy",
  [DIFFICULTY_MEDIUM]: "Medium",
  [DIFFICULTY_HARD]: "Hard",
};

// Sort Configuration
export const SORT_FIELD_TIME = "TIME";
export const SORT_FIELD_TITLE = "TITLE";
export const SORT_DIRECTION_ASC = "ASC";
export const SORT_DIRECTION_DESC = "DESC";

export const VALID_SORTS = new Set([
  "time-asc",
  "time-desc",
  "title-asc",
  "title-desc",
] as const);

// Types for Difficulty
export type DifficultyValue = (typeof DIFFICULTY_ORDER)[number];

// Types for Sort
export type SortField = typeof SORT_FIELD_TIME | typeof SORT_FIELD_TITLE;
export type SortDirection =
  | typeof SORT_DIRECTION_ASC
  | typeof SORT_DIRECTION_DESC;
