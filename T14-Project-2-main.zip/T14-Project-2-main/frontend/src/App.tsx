import { useEffect } from "react";
import { RouterProvider } from "react-router-dom";
import { router } from "./router";
import { AuthProvider } from "./contexts/AuthContext";
import { useAuth } from "./contexts/useAuth";
import { LoginModal } from "./components/LoginModal";

function AppShell() {
  const { isLoginOpen, closeLogin } = useAuth();

  return (
    <>
      <RouterProvider router={router} />
      <LoginModal isOpen={isLoginOpen} onClose={closeLogin} />
    </>
  );
}

export default function App() {
  useEffect(() => {
    if (typeof document === "undefined") return;
    document.documentElement.classList.add("hydrated");
  }, []);

  return (
    <AuthProvider>
      <AppShell />
    </AuthProvider>
  );
}
