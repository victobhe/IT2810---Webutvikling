import { useEffect, useRef } from "react";

/**
 * Custom hook to detect when favorites filter changes and trigger a refetch
 *
 * Prevents unnecessary refetches by only triggering when the filter actually changes
 *
 * @param isFavoritesFilterActive - Current state of the favorites filter
 * @param onFilterChange - Callback to invoke when filter changes
 */
export const useFavoritesFilterSync = (
  isFavoritesFilterActive: boolean | undefined,
  onFilterChange: () => void,
) => {
  const previousStateRef = useRef<boolean | undefined>(isFavoritesFilterActive);

  useEffect(() => {
    // Skip if filter state hasn't changed
    if (previousStateRef.current === isFavoritesFilterActive) {
      return;
    }

    // Update the ref and invoke callback
    previousStateRef.current = isFavoritesFilterActive;
    onFilterChange();
  }, [isFavoritesFilterActive, onFilterChange]);
};
