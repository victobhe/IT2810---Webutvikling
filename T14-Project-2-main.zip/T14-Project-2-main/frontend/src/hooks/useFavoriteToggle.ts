import { useCallback, useState } from "react";
import { useMutation } from "@apollo/client";
import { useAuth } from "../contexts/useAuth";
import {
  TOGGLE_FAVORITE_MUTATION,
  type ToggleFavoriteData,
} from "../graphql/recipeActions";

export type FavoriteToggleResult = {
  success: boolean;
  newState?: boolean;
  error?: string;
};

/**
 * Custom hook for handling favorite toggle with auth-check, error handling, and cache updates
 *
 * Handles:
 * - Auth verification (redirects to login if needed)
 * - Optimistic UI updates
 * - Apollo cache synchronization
 * - Error state management
 *
 * @returns Object with toggle function and error state
 */
export const useFavoriteToggle = () => {
  const { user, openLogin } = useAuth();
  const [lastError, setLastError] = useState<string | null>(null);
  const [toggleFavoriteMutation] = useMutation<ToggleFavoriteData>(
    TOGGLE_FAVORITE_MUTATION,
  );

  const toggle = useCallback(
    async (
      recipeId: string,
      currentState: boolean,
    ): Promise<FavoriteToggleResult> => {
      // Check authentication
      if (!user) {
        openLogin();
        return { success: false, error: "Authentication required" };
      }

      try {
        setLastError(null);
        const result = await toggleFavoriteMutation({
          variables: { recipeId },
          optimisticResponse: {
            toggleFavorite: !currentState,
          },
          update: (cache, { data: mutationData }) => {
            const next = mutationData?.toggleFavorite ?? !currentState;
            const cacheId = cache.identify({
              __typename: "Recipe",
              id: recipeId,
            });
            if (!cacheId) return;
            cache.modify({
              id: cacheId,
              fields: {
                isFavorite: () => next,
              },
            });
          },
        });

        const newState = result.data?.toggleFavorite;
        return {
          success: true,
          newState,
        };
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : "Failed to update favorite";
        setLastError(errorMessage);
        return {
          success: false,
          error: errorMessage,
        };
      }
    },
    [openLogin, toggleFavoriteMutation, user],
  );

  const clearError = useCallback(() => {
    setLastError(null);
  }, []);

  return {
    toggle,
    lastError,
    clearError,
  };
};
