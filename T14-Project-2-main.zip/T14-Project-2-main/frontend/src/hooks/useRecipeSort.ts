/**
 * Custom hook for managing recipe sort state
 * Handles sort option parsing and validation
 */

import { useCallback, useMemo, useState } from "react";
import { type RecipeSortInput } from "../graphql/recipes";
import { type SortOption, VALID_SORTS } from "../utils/recipeFilters";
import { parseSortString } from "../utils/sortParsing";

interface UseRecipeSortReturn {
  sort: SortOption;
  setSortByString: (value: string) => void;
  sortInput: RecipeSortInput;
}

/**
 * Manage recipe sort state with validation
 * @param initialSort - Initial sort option (default: "title-asc")
 * @param onSortChange - Callback when sort changes
 * @returns Current sort, setter, and parsed sort input for GraphQL
 */
export const useRecipeSort = (
  initialSort: SortOption = "title-asc",
  onSortChange?: (newSort: SortOption) => void,
): UseRecipeSortReturn => {
  const [sort, setSort] = useState<SortOption>(initialSort);

  const setSortByString = useCallback(
    (value: string) => {
      if (VALID_SORTS.has(value as SortOption)) {
        const newSort = value as SortOption;
        setSort(newSort);
        onSortChange?.(newSort);
      }
    },
    [onSortChange],
  );

  const sortInput = useMemo<RecipeSortInput>(() => {
    return parseSortString(sort);
  }, [sort]);

  return {
    sort,
    setSortByString,
    sortInput,
  };
};
