/**
 * Custom hook for managing recipe filter state and operations
 * Handles all filter-related state updates and logic
 */

import { useCallback, useState } from "react";
import {
  DIFFICULTY_ORDER,
  type DifficultyValue,
  type FiltersState,
} from "../utils/recipeFilters";

interface UseRecipeFiltersReturn {
  filters: FiltersState;
  setFilters: (filters: FiltersState) => void;
  toggleBooleanFilter: (key: "vegetarian" | "glutenFree") => void;
  toggleDifficultyFilter: (value: DifficultyValue) => void;
  clearDifficultyFilter: () => void;
  handleAreaChange: (value: string) => void;
  handleSearchIngredientsChange: (checked: boolean) => void;
  clearAllFilters: () => void;
}

/**
 * Manage recipe filters state and provide filter update callbacks
 * @param onClearSearch - Callback to clear search when clearAllFilters is called
 * @returns Filter state and handler functions
 */
export const useRecipeFilters = (
  onClearSearch: () => void,
  initialFilters?: FiltersState,
): UseRecipeFiltersReturn => {
  const [filters, setFilters] = useState<FiltersState>(() => {
    if (initialFilters && typeof initialFilters === "object") {
      return { ...initialFilters };
    }
    return {};
  });

  const toggleBooleanFilter = useCallback(
    (key: "vegetarian" | "glutenFree") => {
      if (key === "favorites") return;

      setFilters((prev) => {
        const active = !!prev[key];
        if (active) {
          const next = { ...prev };
          delete next[key];
          return next;
        }
        return { ...prev, [key]: true };
      });
    },
    [],
  );

  const toggleDifficultyFilter = useCallback((value: DifficultyValue) => {
    setFilters((prev) => {
      const current = prev.difficulty ?? [];
      const exists = current.includes(value);
      const nextValues = exists
        ? current.filter((entry) => entry !== value)
        : [...current, value];

      if (nextValues.length === 0) {
        const next = { ...prev };
        delete next.difficulty;
        return next;
      }

      const sorted = DIFFICULTY_ORDER.filter((level) =>
        nextValues.includes(level),
      );
      return { ...prev, difficulty: sorted };
    });
  }, []);

  const clearDifficultyFilter = useCallback(() => {
    setFilters((prev) => {
      if (!prev.difficulty || prev.difficulty.length === 0) {
        return prev;
      }
      const next = { ...prev };
      delete next.difficulty;
      return next;
    });
  }, []);

  const handleAreaChange = useCallback((value: string) => {
    setFilters((prev) => {
      const trimmed = value.trim();
      if (trimmed.length === 0) {
        if (!prev.area) return prev;
        const next = { ...prev };
        delete next.area;
        return next;
      }
      if (prev.area === trimmed) {
        return prev;
      }
      return { ...prev, area: trimmed };
    });
  }, []);

  const handleSearchIngredientsChange = useCallback((checked: boolean) => {
    setFilters((prev) => {
      if (checked) {
        if (prev.searchIngredients) return prev;
        return { ...prev, searchIngredients: true };
      }
      if (!prev.searchIngredients) return prev;
      const next = { ...prev };
      delete next.searchIngredients;
      return next;
    });
  }, []);

  const clearAllFilters = useCallback(() => {
    setFilters({});
    onClearSearch();
  }, [onClearSearch]);

  return {
    filters,
    setFilters,
    toggleBooleanFilter,
    toggleDifficultyFilter,
    clearDifficultyFilter,
    handleAreaChange,
    handleSearchIngredientsChange,
    clearAllFilters,
  };
};
