/**
 * Custom hook for managing difficulty filter dropdown menu
 * Handles open/close state and document-level listeners for escape key and outside clicks
 */

import { useEffect, useRef, useState } from "react";

/**
 * Manages difficulty dropdown state and event listeners
 * @returns { isDifficultyMenuOpen, setDifficultyMenuOpen, difficultyMenuRef }
 */
export const useDifficultyMenu = () => {
  const difficultyMenuRef = useRef<HTMLDivElement | null>(null);
  const [isDifficultyMenuOpen, setDifficultyMenuOpen] = useState(false);

  useEffect(() => {
    if (!isDifficultyMenuOpen) return;

    const handlePointer = (event: PointerEvent) => {
      if (!difficultyMenuRef.current) return;
      if (!difficultyMenuRef.current.contains(event.target as Node)) {
        setDifficultyMenuOpen(false);
      }
    };

    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setDifficultyMenuOpen(false);
      }
    };

    document.addEventListener("pointerdown", handlePointer);
    document.addEventListener("keydown", handleKey);

    return () => {
      document.removeEventListener("pointerdown", handlePointer);
      document.removeEventListener("keydown", handleKey);
    };
  }, [isDifficultyMenuOpen]);

  return {
    isDifficultyMenuOpen,
    setDifficultyMenuOpen,
    difficultyMenuRef,
  };
};
