import { useMemo } from "react";

export type UseRatingStarsOptions = {
  maxStars?: number;
  decimals?: number;
  fallback?: number | null;
};

export type UseRatingStarsResult = {
  ratingValue: number | null;
  displayValue: string | null;
  hasRating: boolean;
  isFallback: boolean;
};

const clampRating = (value: number, maxStars: number) =>
  Math.max(0, Math.min(maxStars, Math.round(value * 10) / 10));

const normalize = (value: unknown, maxStars: number): number | null => {
  if (
    typeof value !== "number" ||
    Number.isNaN(value) ||
    !Number.isFinite(value)
  ) {
    return null;
  }
  return clampRating(value, maxStars);
};

export const useRatingStars = (
  rating: number | null | undefined,
  options: UseRatingStarsOptions = {},
): UseRatingStarsResult => {
  const { maxStars = 5, decimals = 1, fallback = null } = options;

  return useMemo(() => {
    const normalizedRating = normalize(rating, maxStars);
    if (normalizedRating !== null) {
      return {
        ratingValue: normalizedRating,
        displayValue: normalizedRating.toFixed(decimals),
        hasRating: true,
        isFallback: false,
      };
    }

    const fallbackRating = normalize(fallback, maxStars);
    if (fallbackRating !== null) {
      return {
        ratingValue: fallbackRating,
        displayValue: fallbackRating.toFixed(decimals),
        hasRating: false,
        isFallback: true,
      };
    }

    return {
      ratingValue: null,
      displayValue: null,
      hasRating: false,
      isFallback: false,
    };
  }, [rating, fallback, maxStars, decimals]);
};
