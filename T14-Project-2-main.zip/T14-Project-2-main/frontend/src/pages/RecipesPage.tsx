// src/pages/RecipesPage.tsx
import {
  useState,
  useMemo,
  useEffect,
  useCallback,
  useRef,
  useLayoutEffect,
} from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useLazyQuery } from "@apollo/client";
import { NetworkStatus } from "@apollo/client";
import Header from "../components/Header";
import CardsGrid from "../components/Card-Grid";
import Card from "../components/Card";
import { RecipesFilterPanel } from "../components/RecipesFilterPanel";
import { useRecipeFilters } from "../hooks/useRecipeFilters";
import { useDebounce } from "../hooks/useDebounce";
import { useFavoriteToggle } from "../hooks/useFavoriteToggle";
import { resolveImageUrl } from "../utils/resolveImageUrl";
import {
  GET_RECIPES,
  type RecipeFiltersInput,
  type RecipeListItem,
  type RecipeSortInput,
  type RecipesQueryData,
  type RecipesQueryVars,
} from "../graphql/recipes";
import {
  readScrollPosition,
  writeScrollPosition,
  clearScrollPosition,
  RECIPES_SCROLL_KEY,
} from "../utils/scrollStorage";
import { scrollInstant } from "../utils/instantScroll";
import {
  buildRelaxationSteps,
  DIFFICULTY_ORDER,
  type FiltersState,
  type RecipeCriteria,
  type SortOption,
  VALID_SORTS,
} from "../utils/recipeFilters";
import { parseSortString } from "../utils/sortParsing";
import { buildCardTags, getCardImageUrl } from "../utils/cardBuilding";

const PAGE_SIZE = 20;
const ORIGIN_OPTIONS_LIMIT = 200;
const MIN_RENDERED_RESULTS = PAGE_SIZE;

const createSeededRandom = (seed: string) => {
  let state = 0;
  for (let index = 0; index < seed.length; index += 1) {
    state = (state * 31 + seed.charCodeAt(index)) % 2147483647;
  }
  if (state <= 0) state += 2147483646;
  return () => {
    state = (state * 16807) % 2147483647;
    return (state - 1) / 2147483646;
  };
};

const pickRandomRecipes = (
  list: RecipeListItem[],
  count: number,
  seed: string,
) => {
  if (list.length <= count) {
    return list.slice(0, count);
  }
  const random = createSeededRandom(seed);
  const selectedIndices = new Set<number>();
  while (selectedIndices.size < count && selectedIndices.size < list.length) {
    const index = Math.floor(random() * list.length);
    selectedIndices.add(index);
  }
  return Array.from(selectedIndices).map((index) => list[index]);
};

const normalizeSearchValue = (value?: string | null) => {
  if (typeof value !== "string") {
    return "";
  }
  return value.trim().replace(/\s+/g, " ").toLowerCase();
};

const buildApiFilters = (
  filters: FiltersState,
  searchTerm: string,
): RecipeFiltersInput => {
  const next: RecipeFiltersInput = {};
  const trimmedSearch = searchTerm.trim();
  if (trimmedSearch.length > 0) {
    next.q = trimmedSearch;
  }
  if (filters.vegetarian) {
    next.vegetarian = true;
  }
  if (filters.glutenFree) {
    next.glutenFree = true;
  }
  if (filters.difficulty && filters.difficulty.length > 0) {
    next.difficulty = filters.difficulty;
  }
  if (typeof filters.area === "string" && filters.area.trim().length > 0) {
    next.area = filters.area.trim();
  }
  if (filters.searchIngredients) {
    next.searchIngredients = true;
  }
  return next;
};

// Extract local rating getter that doesn't conflict with import
const getRecipeRating = (recipe?: RecipeListItem | null) => {
  if (
    recipe &&
    typeof recipe.averageRating === "number" &&
    Number.isFinite(recipe.averageRating) &&
    (recipe.ratingCount ?? 0) > 0
  ) {
    const clampRating = (value: number) =>
      Math.max(0, Math.min(5, Math.round(value * 10) / 10));
    return clampRating(recipe.averageRating);
  }
  return undefined;
};

export default function RecipesPage() {
  const navigate = useNavigate();
  const historySnapshot =
    typeof window !== "undefined"
      ? ((window.history.state as Record<string, unknown> | undefined) ??
        undefined)
      : undefined;

  const persistedFilters =
    historySnapshot && typeof historySnapshot.recipesFilters === "object"
      ? (historySnapshot.recipesFilters as FiltersState)
      : undefined;

  // Use filter hook
  const {
    filters,
    toggleBooleanFilter,
    toggleDifficultyFilter,
    clearDifficultyFilter,
    handleAreaChange,
    handleSearchIngredientsChange,
    clearAllFilters: clearAllFiltersBase,
  } = useRecipeFilters(() => setSearch(""), persistedFilters);

  // Search and sort state
  const [search, setSearch] = useState<string>(() =>
    typeof historySnapshot?.recipesSearch === "string"
      ? (historySnapshot.recipesSearch as string)
      : "",
  );
  const [sort, setSort] = useState<SortOption>(() => {
    const candidate = historySnapshot?.recipesSort;
    if (
      typeof candidate === "string" &&
      VALID_SORTS.has(candidate as SortOption)
    ) {
      return candidate as SortOption;
    }
    return "title-asc";
  });

  // Page state
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [fallbackStepIndex, setFallbackStepIndex] = useState(-1);
  const [relaxationBannerHidden, setRelaxationBannerHidden] = useState(false);

  // Refs
  const scrollTargetRef = useRef<number | null>(
    typeof window !== "undefined"
      ? readScrollPosition(RECIPES_SCROLL_KEY)
      : null,
  );
  const hasRestoredScrollRef = useRef(false);
  const autoFetchRef = useRef(false);
  const [recentRecipes, setRecentRecipes] = useState<RecipeListItem[]>([]);
  const [areaOptions, setAreaOptions] = useState<string[]>([]);
  const [favoriteError, setFavoriteError] = useState<string | null>(null);

  const debouncedSearch = useDebounce(search, 400);

  const desiredCriteria = useMemo<RecipeCriteria>(
    () => ({
      search: debouncedSearch.trim(),
      filters,
      sort,
    }),
    [debouncedSearch, filters, sort],
  );

  // Persist state to history
  const persistState = useCallback(
    (nextSearch: string, nextSort: SortOption, nextFilters: FiltersState) => {
      if (typeof window === "undefined") return;
      const state = window.history.state ?? {};
      window.history.replaceState(
        {
          ...state,
          recipesSearch: nextSearch,
          recipesSort: nextSort,
          recipesFilters: nextFilters,
        },
        document.title,
      );
    },
    [],
  );

  useEffect(() => {
    persistState(search, sort, filters);
  }, [filters, persistState, search, sort]);

  useEffect(() => {
    setFallbackStepIndex(-1);
  }, [desiredCriteria]);

  const sortInput = useMemo<RecipeSortInput>(() => {
    return parseSortString(sort);
  }, [sort]);

  const fallbackSteps = useMemo(
    () => buildRelaxationSteps(desiredCriteria),
    [desiredCriteria],
  );
  const appliedCriteria = useMemo<RecipeCriteria>(
    () =>
      fallbackSteps
        .slice(0, fallbackStepIndex + 1)
        .reduce((current, step) => step.apply(current), desiredCriteria),
    [fallbackSteps, fallbackStepIndex, desiredCriteria],
  );
  const relaxedLabels = useMemo(
    () =>
      fallbackSteps.slice(0, fallbackStepIndex + 1).map((step) => step.label),
    [fallbackSteps, fallbackStepIndex],
  );

  useEffect(() => {
    if (relaxedLabels.length > 0) {
      setRelaxationBannerHidden(false);
    }
  }, [relaxedLabels]);

  const apiFilters = useMemo(
    () => buildApiFilters(appliedCriteria.filters, appliedCriteria.search),
    [appliedCriteria.filters, appliedCriteria.search],
  );

  const baseVariables = useMemo<RecipesQueryVars>(
    () => ({
      search: appliedCriteria.search,
      filters: apiFilters,
      sort: sortInput,
      first: PAGE_SIZE,
    }),
    [apiFilters, appliedCriteria.search, sortInput],
  );

  const { data, loading, error, fetchMore, networkStatus } = useQuery<
    RecipesQueryData,
    RecipesQueryVars
  >(GET_RECIPES, {
    variables: baseVariables,
    notifyOnNetworkStatusChange: true,
  });

  const [fetchOriginOptions, { data: originOptionsData }] = useLazyQuery<
    RecipesQueryData,
    RecipesQueryVars
  >(GET_RECIPES, {
    fetchPolicy: "network-only",
  });

  const { toggle: toggleFavorite, clearError: clearFavoriteError } =
    useFavoriteToggle();

  const isFetchingMore = networkStatus === NetworkStatus.fetchMore;

  const handleLoadMore = useCallback(() => {
    const pageInfo = data?.recipes?.pageInfo;
    if (!pageInfo?.hasNextPage || isFetchingMore) return;

    void fetchMore({
      variables: {
        ...baseVariables,
        after: pageInfo.endCursor,
      },
    });
  }, [baseVariables, data?.recipes?.pageInfo, fetchMore, isFetchingMore]);

  const serverItems = useMemo(
    () => data?.recipes?.items ?? [],
    [data?.recipes?.items],
  );

  const normalizedAppliedSearch = useMemo(
    () => normalizeSearchValue(appliedCriteria.search),
    [appliedCriteria.search],
  );

  const prioritizedItems = useMemo(() => {
    if (normalizedAppliedSearch.length === 0) {
      return serverItems;
    }
    const exactMatches: RecipeListItem[] = [];
    const others: RecipeListItem[] = [];

    serverItems.forEach((recipe) => {
      const normalizedTitle = normalizeSearchValue(recipe.title);
      if (normalizedTitle === normalizedAppliedSearch) {
        exactMatches.push(recipe);
      } else {
        others.push(recipe);
      }
    });

    if (exactMatches.length === 0) {
      return serverItems;
    }

    return [...exactMatches, ...others];
  }, [normalizedAppliedSearch, serverItems]);

  const buildAreaList = useCallback((items: RecipeListItem[]) => {
    const set = new Set<string>();
    items.forEach((recipe) => {
      const area = typeof recipe.area === "string" ? recipe.area.trim() : "";
      if (area.length > 0) {
        set.add(area);
      }
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, []);

  useEffect(() => {
    if (serverItems.length > 0) {
      setRecentRecipes(serverItems);
    }
  }, [serverItems]);

  useEffect(() => {
    if (filters.area) return;
    if (serverItems.length === 0) {
      setAreaOptions([]);
      return;
    }
    setAreaOptions(buildAreaList(serverItems));
  }, [buildAreaList, filters.area, serverItems]);

  const filtersWithoutArea = useMemo<RecipeFiltersInput>(() => {
    const { area: _ignored, ...rest } = apiFilters;
    void _ignored;
    return rest;
  }, [apiFilters]);

  useEffect(() => {
    if (!filters.area) return;
    const nonAreaVariables: RecipesQueryVars = {
      search: debouncedSearch,
      filters: filtersWithoutArea,
      sort: sortInput,
      first: ORIGIN_OPTIONS_LIMIT,
    };
    fetchOriginOptions({ variables: nonAreaVariables }).catch(() => {});
  }, [
    debouncedSearch,
    fetchOriginOptions,
    filters.area,
    filtersWithoutArea,
    sortInput,
  ]);

  useEffect(() => {
    if (!filters.area) return;
    const originItems = originOptionsData?.recipes?.items ?? [];
    if (originItems.length === 0) {
      setAreaOptions([]);
      return;
    }
    setAreaOptions(buildAreaList(originItems));
  }, [buildAreaList, filters.area, originOptionsData?.recipes?.items]);

  const availableAreas = useMemo(() => {
    const base = areaOptions;
    if (filters.area && !base.includes(filters.area)) {
      return [...base, filters.area].sort((a, b) => a.localeCompare(b));
    }
    return base;
  }, [areaOptions, filters.area]);

  const handleFavoriteToggle = useCallback(
    async (recipeId: string, currentState: boolean) => {
      clearFavoriteError();
      const result = await toggleFavorite(recipeId, currentState);

      if (!result.success) {
        setFavoriteError(result.error ?? "Failed to update favorite");
        return;
      }
    },
    [toggleFavorite, clearFavoriteError],
  );

  const availability = useMemo(
    () => ({
      vegetarian: serverItems.some((recipe) => recipe.vegetarian === true),
      glutenFree: serverItems.some((recipe) => recipe.glutenFree === true),
      difficulty: DIFFICULTY_ORDER.map((level) => ({
        level,
        available: serverItems.some(
          (recipe) =>
            typeof recipe.difficulty === "string" &&
            recipe.difficulty.toUpperCase() === level,
        ),
      })),
      areas: availableAreas.map((area) => ({
        value: area,
        label: area,
        available: true,
      })),
    }),
    [availableAreas, serverItems],
  );

  const originFilterDisabled = availability.areas.length === 0;

  const handleRecipeClick = useCallback(
    (id: string) => {
      if (typeof window !== "undefined") {
        writeScrollPosition(RECIPES_SCROLL_KEY, window.scrollY);
      }

      const found = serverItems.find((entry) => entry.id === id);
      navigate(`/recipe/${id}`, {
        state: {
          recipe: found,
          imageUrl:
            resolveImageUrl(found?.image) ??
            `https://via.placeholder.com/1000x700?text=${encodeURIComponent(
              found?.title ?? "Recipe",
            )}`,
          rating: getRecipeRating(found),
        },
      });
    },
    [navigate, serverItems],
  );

  const handleSearchSubmit = useCallback(() => {
    if (typeof window === "undefined") return;
    const listElement = document.getElementById("recipe-list");
    if (!listElement) return;
    const isMobile = window.matchMedia("(max-width: 768px)").matches;
    if (!isMobile) return;
    const headerOffset = 90;
    const elementPosition =
      listElement.getBoundingClientRect().top + window.scrollY;
    const offsetPosition = elementPosition - headerOffset;
    window.scrollTo({ top: Math.max(offsetPosition, 0), behavior: "smooth" });
  }, []);

  const hasActiveFilters = useMemo(
    () =>
      Boolean(filters.vegetarian || filters.glutenFree) ||
      Boolean(filters.area) ||
      Boolean(filters.difficulty && filters.difficulty.length > 0) ||
      search.trim().length > 0,
    [
      filters.area,
      filters.difficulty,
      filters.glutenFree,
      filters.vegetarian,
      search,
    ],
  );

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (hasRestoredScrollRef.current) return;

    const target = scrollTargetRef.current;
    if (target === null) return;
    if (loading) return;

    hasRestoredScrollRef.current = true;
    scrollTargetRef.current = null;

    scrollInstant(target);

    clearScrollPosition(RECIPES_SCROLL_KEY);
  }, [loading, serverItems.length]);

  useLayoutEffect(() => {
    if (typeof window === "undefined") return;
    if (scrollTargetRef.current !== null) return;
    scrollInstant(0);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 400);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleBackToTop = useCallback(() => {
    if (typeof window === "undefined") return;
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  useEffect(() => {
    if (loading) return;
    if (!data?.recipes.pageInfo?.hasNextPage) return;

    const renderedCount = serverItems.length;
    if (renderedCount >= MIN_RENDERED_RESULTS) return;
    if (autoFetchRef.current) return;

    autoFetchRef.current = true;
    const cursor = data.recipes.pageInfo.endCursor ?? undefined;

    fetchMore({
      variables: {
        after: cursor,
      },
    })
      .catch(() => {
        // ignore automatic fetch errors; manual Load more is still available
      })
      .finally(() => {
        autoFetchRef.current = false;
      });
  }, [
    data?.recipes.pageInfo?.endCursor,
    data?.recipes.pageInfo?.hasNextPage,
    fetchMore,
    loading,
    serverItems.length,
  ]);

  const hasResults = serverItems.length > 0;

  const suggestedRecipes = useMemo(() => {
    const termActive = search.trim().length > 0;
    if (!termActive || hasResults) return [];
    if (recentRecipes.length === 0) return [];
    return pickRandomRecipes(
      recentRecipes,
      6,
      `${search.trim().toLowerCase()}:${recentRecipes.length}`,
    );
  }, [hasResults, recentRecipes, search]);

  const showSearchFallback =
    search.trim().length > 0 && !hasResults && suggestedRecipes.length > 0;

  useEffect(() => {
    if (loading) return;
    if (serverItems.length > 0) return;
    if (fallbackSteps.length === 0) return;
    if (fallbackStepIndex >= fallbackSteps.length - 1) return;
    setFallbackStepIndex((prev) => prev + 1);
  }, [fallbackStepIndex, fallbackSteps.length, loading, serverItems.length]);

  const disabledFilters = useMemo(
    () => ({
      vegetarian: false,
      glutenFree: false,
    }),
    [],
  );

  const renderedCount = serverItems.length;
  const totalCount = data?.recipes?.pageInfo?.totalCount ?? renderedCount;
  const desiredSearchTerm = desiredCriteria.search.trim();
  const appliedSearchTerm = appliedCriteria.search.trim();
  const searchRelaxed =
    desiredSearchTerm.length > 0 && appliedSearchTerm.length === 0;
  const searchNotificationTerm = useMemo(() => {
    const uiValue = search.trim();
    if (uiValue.length > 0) {
      return uiValue;
    }
    return desiredSearchTerm;
  }, [desiredSearchTerm, search]);

  const relaxationSummary =
    relaxedLabels.length > 0
      ? ` Relaxed filters: ${relaxedLabels.join(", ")}.`
      : "";
  const filterFeedback =
    loading && !hasResults
      ? "Loading recipes..."
      : totalCount === 0
        ? "No recipes match the filters."
        : `Showing ${renderedCount} of ${totalCount} recipes.${relaxationSummary}`;
  const relaxationMessageVisible =
    (relaxedLabels.length > 0 || searchRelaxed) &&
    hasResults &&
    !relaxationBannerHidden;

  const renderRecipeCard = (recipe: RecipeListItem, index: number) => {
    const rating = getRecipeRating(recipe);
    return (
      <Card
        key={`${recipe.id}-${index}`}
        item={{
          id: recipe.id,
          title: recipe.title,
          imageUrl: getCardImageUrl(recipe.image, recipe.title),
          rating,
          location: recipe.area ?? undefined,
          tags: buildCardTags(recipe),
          price: undefined,
        }}
        isFavorite={recipe.isFavorite ?? false}
        onFavoriteToggle={(id) =>
          handleFavoriteToggle(id, recipe.isFavorite ?? false)
        }
        onClick={handleRecipeClick}
      />
    );
  };

  return (
    <>
      <Header recipeCount={totalCount} />

      <main id="main-content" tabIndex={-1} className="u-flow">
        <RecipesFilterPanel
          search={search}
          onSearchChange={setSearch}
          onSearchSubmit={handleSearchSubmit}
          filters={filters}
          onToggleBooleanFilter={toggleBooleanFilter}
          onToggleDifficultyFilter={toggleDifficultyFilter}
          onClearDifficultyFilter={clearDifficultyFilter}
          onAreaChange={handleAreaChange}
          onSearchIngredientsChange={handleSearchIngredientsChange}
          availability={availability}
          disabledFilters={disabledFilters}
          originFilterDisabled={originFilterDisabled}
          sort={sort}
          onSortChange={(value) => {
            if (VALID_SORTS.has(value as SortOption)) {
              setSort(value as SortOption);
            }
          }}
          hasActiveFilters={hasActiveFilters}
          onResetFilters={() => {
            clearAllFiltersBase();
          }}
        />

        <section
          id="filter-feedback"
          className="sr-only"
          role="status"
          aria-live="polite"
          aria-atomic="true"
        >
          {filterFeedback}
        </section>

        {error ? (
          <p role="alert">Could not fetch recipes from the server.</p>
        ) : null}

        {favoriteError ? (
          <section className="u-flow-xs" role="alert" aria-live="assertive">
            <p>{favoriteError}</p>
            <button
              type="button"
              className="btn btn--ghost"
              onClick={() => setFavoriteError(null)}
            >
              Dismiss
            </button>
          </section>
        ) : null}

        {loading && !hasResults ? (
          <p role="status">Loading recipes...</p>
        ) : null}

        {!loading && !hasResults ? (
          <section className="u-flow-sm" aria-live="polite">
            <p role="status">No recipes matched your filters.</p>
            {showSearchFallback ? (
              <section className="u-flow-sm" aria-label="Suggested recipes">
                <p className="u-text-sm u-text-muted">
                  Check out our other favorite dishes:
                </p>
                <CardsGrid>
                  {suggestedRecipes.map((recipe, index) =>
                    renderRecipeCard(recipe, index),
                  )}
                </CardsGrid>
              </section>
            ) : null}
          </section>
        ) : null}

        {serverItems.length > 0 ? (
          <section
            id="recipe-list"
            aria-label="Recipes matching the filters"
            className="u-flow-sm"
          >
            {search.trim().length > 0 ? (
              <h2>Search results</h2>
            ) : (
              <h2>Featured recipes</h2>
            )}
            {relaxationMessageVisible ? (
              <section className="u-flow-xs" aria-live="polite" role="status">
                {relaxedLabels.length > 0 ? (
                  <p className="u-text-sm u-text-muted">
                    No exact matches. Showing recipes with relaxed filters:{" "}
                    <strong>{relaxedLabels.join(", ")}</strong>.
                  </p>
                ) : null}
                {searchRelaxed ? (
                  <p className="u-text-sm u-text-muted">
                    Your search for <strong>{searchNotificationTerm}</strong>{" "}
                    did not return any close matches, so we&apos;re showing
                    broader results without that search term.
                  </p>
                ) : null}
                <button
                  type="button"
                  className="btn btn--ghost"
                  onClick={() => setRelaxationBannerHidden(true)}
                  aria-label="Dismiss relaxed filters notice"
                >
                  Dismiss
                </button>
              </section>
            ) : null}
            <CardsGrid>
              {prioritizedItems.map((recipe, index) =>
                renderRecipeCard(recipe, index),
              )}
            </CardsGrid>
          </section>
        ) : null}

        {data?.recipes?.pageInfo?.hasNextPage ? (
          <section
            className="u-flow-sm u-hide-on-print"
            role="region"
            aria-label="More recipes"
          >
            <button
              type="button"
              className="btn btn--ghost"
              onClick={handleLoadMore}
              disabled={isFetchingMore}
            >
              {isFetchingMore ? "Loading more..." : "Load more dishes"}
            </button>
          </section>
        ) : null}
      </main>
      <button
        type="button"
        className={`back-to-top${showBackToTop ? " is-visible" : ""}`}
        onClick={handleBackToTop}
        aria-label="Back to top"
      >
        ↑
      </button>
    </>
  );
}
