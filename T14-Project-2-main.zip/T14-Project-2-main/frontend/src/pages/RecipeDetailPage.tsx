export { default } from "../components/RecipeDetails";
