import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  useLayoutEffect,
} from "react";
import { useNavigate } from "react-router-dom";
import { useMutation, useQuery } from "@apollo/client";
import Header from "../components/Header";
import CardsGrid from "../components/Card-Grid";
import Card, { type Listing } from "../components/Card";
import StarDisplay from "../components/StarDisplay";
import { useAuth } from "../contexts/useAuth";
import {
  GET_MY_PROFILE,
  type ProfileQueryData,
  type ProfileQueryVars,
} from "../graphql/profile";
import type { RecipeListItem } from "../graphql/recipes";
import {
  TOGGLE_FAVORITE_MUTATION,
  type ToggleFavoriteData,
} from "../graphql/recipeActions";
import { resolveImageUrl } from "../utils/resolveImageUrl";
import { useRatingStars } from "../hooks/useRatingStars";
import {
  COMMENT_SORT_OPTIONS,
  sortCommentsBy,
  type CommentSortOrder,
} from "../utils/commentSorting";
import AccountSettingsModal from "../components/AccountSettingsModal";
import "../styles/profile.css";

const FALLBACK_IMAGE = "/assets/logo.webp";
const EMPTY_RECIPES: RecipeListItem[] = [];
const FAVORITES_PAGE_SIZE = 12;
const COMMENTS_PAGE_SIZE = 10;
const ACCOUNT_MODAL_ID = "account-settings-modal";

type ProfileCommentRatingProps = {
  rating?: number | null;
};

const ProfileCommentRating = ({ rating }: ProfileCommentRatingProps) => {
  const ratingDisplay = useRatingStars(rating);

  if (!ratingDisplay.hasRating || ratingDisplay.ratingValue === null) {
    return (
      <span className="profile-comment-card__rating-placeholder">
        No rating
      </span>
    );
  }

  return (
    <StarDisplay
      rating={ratingDisplay.ratingValue}
      variant="compact"
      showValue={true}
      showCount={false}
    />
  );
};

function UserProfilePage(): React.ReactElement {
  const navigate = useNavigate();
  const { user, status, openLogin, refresh } = useAuth();
  const isAuthenticated = status === "authenticated";

  useEffect(() => {
    if (typeof window === "undefined") return;
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);

  const [favoritesLimit, setFavoritesLimit] = useState(FAVORITES_PAGE_SIZE);
  const [favoritesCollapsed, setFavoritesCollapsed] = useState(true);
  const [favoritesSearch, setFavoritesSearch] = useState("");
  const [commentsLimit, setCommentsLimit] = useState(COMMENTS_PAGE_SIZE);
  const [commentsCollapsed, setCommentsCollapsed] = useState(true);
  const [commentSort, setCommentSort] = useState<CommentSortOrder>("newest");
  const [isAccountModalOpen, setAccountModalOpen] = useState(false);
  const favoritesScrollRestoreRef = useRef<number | null>(null);
  const favoritesLoadMoreRef = useRef<HTMLButtonElement | null>(null);

  const queryVariables = useMemo<ProfileQueryVars>(
    () => ({
      favoritesLimit,
      commentsLimit,
    }),
    [favoritesLimit, commentsLimit],
  );

  const { data, previousData, loading, error, refetch } = useQuery<
    ProfileQueryData,
    ProfileQueryVars
  >(GET_MY_PROFILE, {
    skip: !isAuthenticated,
    variables: queryVariables,
    fetchPolicy: "cache-and-network",
  });

  useEffect(() => {
    if (!isAuthenticated) {
      setFavoritesLimit(FAVORITES_PAGE_SIZE);
      setCommentsLimit(COMMENTS_PAGE_SIZE);
    }
  }, [isAuthenticated]);

  const [toggleFavoriteMutation] = useMutation<ToggleFavoriteData>(
    TOGGLE_FAVORITE_MUTATION,
  );

  const profileData = data ?? previousData;
  const profile = profileData?.myProfile;
  const favorites = profile?.favorites ?? EMPTY_RECIPES;
  const comments = useMemo(() => profile?.comments ?? [], [profile?.comments]);
  const favoritesHasMore = profile?.favoritesHasMore ?? false;
  const commentsHasMore = profile?.commentsHasMore ?? false;
  const stats = profile?.stats ?? { favorites: 0, comments: 0 };
  const profileUser = profile?.user ?? user;
  const sortedProfileComments = useMemo(
    () => sortCommentsBy(comments, commentSort),
    [comments, commentSort],
  );
  const totalFavoritesCount = stats?.favorites ?? favorites.length;

  useEffect(() => {
    if (favoritesSearch.trim().length === 0) return;
    if (favoritesLimit >= totalFavoritesCount) return;
    setFavoritesLimit(totalFavoritesCount);
    favoritesScrollRestoreRef.current = null;
  }, [favoritesSearch, favoritesLimit, totalFavoritesCount]);

  const favoritesSearchTerm = favoritesSearch.trim().toLowerCase();
  const filteredFavorites = useMemo(() => {
    if (favoritesSearchTerm.length === 0) return favorites;
    return favorites
      .filter((recipe) =>
        (recipe.title ?? "").toLowerCase().includes(favoritesSearchTerm),
      )
      .slice(0, favoritesLimit);
  }, [favorites, favoritesSearchTerm, favoritesLimit]);

  const visibleFavorites = useMemo(() => {
    if (favoritesSearchTerm.length > 0) return filteredFavorites;
    return filteredFavorites.slice(0, favoritesLimit);
  }, [filteredFavorites, favoritesLimit, favoritesSearchTerm.length]);

  const handleNavigateToRecipe = useCallback(
    (recipeId: string) => {
      navigate(`/recipe/${recipeId}`);
    },
    [navigate],
  );

  const handleFavoriteToggle = useCallback(
    (recipeId: string, currentState?: boolean) => {
      if (!isAuthenticated) {
        openLogin();
        return;
      }
      toggleFavoriteMutation({
        variables: { recipeId },
        optimisticResponse: { toggleFavorite: !(currentState ?? false) },
      })
        .then(() => refetch())
        .catch(() => {});
    },
    [isAuthenticated, openLogin, refetch, toggleFavoriteMutation],
  );

  useLayoutEffect(() => {
    if (typeof window === "undefined") return;
    if (favoritesScrollRestoreRef.current === null) return;
    if (visibleFavorites.length === 0) return;
    window.scrollTo({
      top: favoritesScrollRestoreRef.current,
      behavior: "instant",
    });
    favoritesScrollRestoreRef.current = null;
  }, [visibleFavorites]);

  const handleLoadMoreFavorites = useCallback(() => {
    if (typeof window !== "undefined") {
      const button = favoritesLoadMoreRef.current;
      const reserve = button?.getBoundingClientRect?.()
        ? button.getBoundingClientRect().top + window.scrollY - 370
        : window.scrollY;
      favoritesScrollRestoreRef.current = reserve;
    }
    setFavoritesLimit((value) => value + FAVORITES_PAGE_SIZE);
  }, []);

  const handleLoadMoreComments = useCallback(() => {
    setCommentsLimit((value) => value + COMMENTS_PAGE_SIZE);
  }, []);
  const handleAccountModalClose = useCallback(
    () => setAccountModalOpen(false),
    [],
  );

  const handleProfileUpdated = useCallback(() => {
    void refresh();
    void refetch();
  }, [refresh, refetch]);

  const handleAccountDeleted = useCallback(() => {
    setAccountModalOpen(false);
    void refresh().finally(() => {
      navigate("/");
    });
  }, [navigate, refresh]);

  const renderUnauthenticated = () => (
    <section className="profile-state profile-state--center" role="alert">
      <p className="profile-state__eyebrow">Private area</p>
      <h1>Sign in to view your profile</h1>
      <p>
        Your saved favorites and posted comments live here. Log in to pick up
        where you left off.
      </p>
      <section className="profile-state__actions">
        <button type="button" className="btn btn--primary" onClick={openLogin}>
          Log in
        </button>
      </section>
    </section>
  );

  const renderLoading = () => (
    <section className="profile-state" aria-busy="true" aria-live="polite">
      <p className="profile-state__eyebrow">Just a moment</p>
      <h1>Loading your profile…</h1>
      <p>We&apos;re pulling your favorites and review history.</p>
    </section>
  );

  const renderError = () => (
    <section className="profile-state profile-state--center" role="alert">
      <p className="profile-state__eyebrow">Something went wrong</p>
      <h1>We couldn&apos;t load your profile</h1>
      <p>{error?.message ?? "Please try again."}</p>
      <section className="profile-state__actions">
        <button
          type="button"
          className="btn btn--ghost"
          onClick={() => refetch()}
        >
          Try again
        </button>
      </section>
    </section>
  );

  if (status === "unauthenticated") {
    return (
      <>
        <Header />
        <main id="main-content" tabIndex={-1} className="profile-page">
          {renderUnauthenticated()}
        </main>
      </>
    );
  }

  if (status === "loading" || (loading && !profile)) {
    return (
      <>
        <Header />
        <main id="main-content" tabIndex={-1} className="profile-page">
          {renderLoading()}
        </main>
      </>
    );
  }

  if (error) {
    return (
      <>
        <Header />
        <main id="main-content" tabIndex={-1} className="profile-page">
          {renderError()}
        </main>
      </>
    );
  }

  if (!profile || !profileUser) {
    return (
      <>
        <Header />
        <main id="main-content" tabIndex={-1} className="profile-page">
          <section className="profile-state profile-state--center">
            <h1>Profile unavailable</h1>
            <p>
              We couldn&apos;t find your profile data. Please refresh or try
              again later.
            </p>
            <section className="profile-state__actions">
              <button
                type="button"
                className="btn btn--ghost"
                onClick={() => refetch()}
              >
                Retry
              </button>
            </section>
          </section>
        </main>
      </>
    );
  }

  const displayName = profileUser.name?.trim() || profileUser.email;
  const initials = (profileUser.name ?? profileUser.email ?? "U")
    .trim()
    .charAt(0)
    .toUpperCase();
  const hasVisibleFavorites = visibleFavorites.length > 0;
  const hasComments = comments.length > 0;
  const numberFormatter = new Intl.NumberFormat();

  return (
    <>
      <Header />
      <main id="main-content" tabIndex={-1} className="profile-page">
        <section className="profile-hero">
          <section className="profile-hero__avatar" aria-hidden="true">
            {initials || "U"}
          </section>
          <section className="profile-hero__content">
            <p className="profile-hero__eyebrow">Your DishDelish space</p>
            <h1>{displayName}</h1>
            <p className="profile-hero__meta">{profileUser.email}</p>
            <dl className="profile-stats">
              <section className="profile-stat">
                <dt>Favorites</dt>
                <dd>{numberFormatter.format(stats.favorites ?? 0)}</dd>
              </section>
              <section className="profile-stat">
                <dt>Comments</dt>
                <dd>{numberFormatter.format(stats.comments ?? 0)}</dd>
              </section>
            </dl>
            <section className="profile-hero__actions">
              <button
                type="button"
                className="btn btn--accent"
                onClick={() => setAccountModalOpen(true)}
                aria-haspopup="dialog"
                aria-expanded={isAccountModalOpen}
                aria-controls={ACCOUNT_MODAL_ID}
              >
                Manage account
              </button>
            </section>
          </section>
        </section>

        <section
          className={`profile-section${favoritesCollapsed ? " profile-section--collapsed" : ""}`}
          aria-labelledby="profile-favorites-title"
        >
          <section className="profile-section__header">
            <section>
              <p className="profile-section__eyebrow">Saved recipes</p>
              <h2 id="profile-favorites-title">Favorites</h2>
              <p className="profile-section__description">
                Quick access to the dishes you return to again and again.
              </p>
            </section>
            <section className="profile-section__actions">
              {!favoritesCollapsed ? (
                <form
                  className="favorites-search-form"
                  onSubmit={(event) => event.preventDefault()}
                  role="search"
                  aria-label="Search favorites"
                >
                  <label
                    className="profile-comment-sort"
                    htmlFor="favorites-search"
                  >
                    <span className="sr-only">Search favorites</span>
                    <input
                      id="favorites-search"
                      type="search"
                      placeholder="Search favorites…"
                      value={favoritesSearch}
                      onChange={(event) =>
                        setFavoritesSearch(event.target.value)
                      }
                    />
                  </label>
                </form>
              ) : null}
              <button
                type="button"
                className="btn btn--ghost"
                onClick={() => setFavoritesCollapsed((prev) => !prev)}
              >
                {favoritesCollapsed ? "Show" : "Hide"}
              </button>
              <button
                type="button"
                className="btn btn--ghost"
                onClick={() => navigate("/recipes")}
              >
                Browse recipes
              </button>
            </section>
          </section>

          {!favoritesCollapsed ? (
            hasVisibleFavorites ? (
              <>
                <CardsGrid className="profile-favorites-grid">
                  {visibleFavorites.map((recipe) => (
                    <Card
                      key={recipe.id}
                      item={toListing(recipe)}
                      isFavorite={recipe.isFavorite ?? true}
                      onFavoriteToggle={(id) =>
                        handleFavoriteToggle(id, recipe.isFavorite ?? true)
                      }
                      onClick={handleNavigateToRecipe}
                    />
                  ))}
                </CardsGrid>
                {favoritesHasMore && favoritesSearchTerm.length === 0 ? (
                  <section className="profile-load-more">
                    <button
                      ref={favoritesLoadMoreRef}
                      type="button"
                      className="btn btn--ghost"
                      onClick={handleLoadMoreFavorites}
                      disabled={loading}
                    >
                      Load more favorites
                    </button>
                  </section>
                ) : null}
              </>
            ) : favoritesSearchTerm.length > 0 ? (
              <section className="profile-empty" role="status">
                <p>No favorites matched your search.</p>
                <button
                  type="button"
                  className="btn btn--ghost"
                  onClick={() => setFavoritesSearch("")}
                >
                  Clear search
                </button>
              </section>
            ) : (
              <section className="profile-empty" role="status">
                <p>You haven&apos;t saved favorites yet.</p>
                <button
                  type="button"
                  className="btn btn--primary"
                  onClick={() => navigate("/recipes")}
                >
                  Find a recipe
                </button>
              </section>
            )
          ) : null}
        </section>

        <section
          className={`profile-section${commentsCollapsed ? " profile-section--collapsed" : ""}`}
          aria-labelledby="profile-comments-title"
        >
          <section className="profile-section__header">
            <section>
              <p className="profile-section__eyebrow">Reviews & notes</p>
              <h2 id="profile-comments-title">Posted comments</h2>
              <p className="profile-section__description">
                Keep track of your tasting notes and feedback across recipes.
              </p>
            </section>
            {hasComments ? (
              <section className="profile-section__actions">
                <label
                  className="profile-comment-sort"
                  htmlFor="profile-comment-sort"
                >
                  <span>Sort comments</span>
                  <select
                    id="profile-comment-sort"
                    value={commentSort}
                    onChange={(event) =>
                      setCommentSort(event.target.value as CommentSortOrder)
                    }
                  >
                    {COMMENT_SORT_OPTIONS.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </label>
                <button
                  type="button"
                  className="btn btn--ghost"
                  onClick={() => setCommentsCollapsed((prev) => !prev)}
                >
                  {commentsCollapsed ? "Show" : "Hide"}
                </button>
              </section>
            ) : null}
          </section>

          {hasComments && !commentsCollapsed ? (
            <>
              <ul className="profile-comment-list">
                {sortedProfileComments.map((comment, index) => {
                  const commentImage =
                    resolveImageUrl(comment.recipe.image) ?? FALLBACK_IMAGE;
                  return (
                    <li
                      key={`${comment.id}-${index}`}
                      className="profile-comment-card"
                    >
                      <button
                        type="button"
                        className="profile-comment-card__media"
                        onClick={() =>
                          handleNavigateToRecipe(comment.recipe.id)
                        }
                        aria-label={`Open ${comment.recipe.title}`}
                      >
                        <img src={commentImage} alt="" loading="lazy" />
                      </button>
                      <section className="profile-comment-card__body">
                        <section className="profile-comment-card__header">
                          <p
                            className="profile-comment-card__title"
                            aria-label={`Recipe: ${comment.recipe.title}`}
                          >
                            {comment.recipe.title}
                          </p>
                          <time dateTime={comment.createdAt}>
                            {formatDate(comment.createdAt)}
                          </time>
                        </section>
                        <p className="profile-comment-card__text">
                          {comment.body}
                        </p>
                        <section className="profile-comment-card__meta">
                          <ProfileCommentRating rating={comment.rating} />
                          <button
                            type="button"
                            className="profile-comment-card__link"
                            onClick={() =>
                              handleNavigateToRecipe(comment.recipe.id)
                            }
                          >
                            View recipe
                          </button>
                        </section>
                      </section>
                    </li>
                  );
                })}
              </ul>
              {commentsHasMore ? (
                <section className="profile-load-more">
                  <button
                    type="button"
                    className="btn btn--ghost"
                    onClick={handleLoadMoreComments}
                    disabled={loading}
                  >
                    Load older comments
                  </button>
                </section>
              ) : null}
            </>
          ) : !commentsCollapsed ? (
            <section className="profile-empty" role="status">
              <p>You haven&apos;t posted comments yet.</p>
              <button
                type="button"
                className="btn btn--ghost"
                onClick={() => navigate("/recipes")}
              >
                Write a review
              </button>
            </section>
          ) : null}
        </section>
      </main>
      {profileUser ? (
        <AccountSettingsModal
          isOpen={isAccountModalOpen}
          onClose={handleAccountModalClose}
          user={profileUser}
          onProfileUpdated={handleProfileUpdated}
          onAccountDeleted={handleAccountDeleted}
          dialogId={ACCOUNT_MODAL_ID}
        />
      ) : null}
    </>
  );
}

const capitalize = (value?: string | null) => {
  if (!value) return undefined;
  const trimmed = value.trim();
  if (!trimmed) return undefined;
  return trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase();
};

const formatDate = (value: string) => {
  try {
    return new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(
      new Date(value),
    );
  } catch {
    return value;
  }
};

const buildRecipeTags = (recipe: RecipeListItem): string[] | undefined => {
  const tags: string[] = [];
  if (
    typeof recipe.time === "number" &&
    Number.isFinite(recipe.time) &&
    recipe.time > 0
  ) {
    tags.push(`${Math.round(recipe.time)} min`);
  }
  const difficulty = capitalize(recipe.difficulty ?? undefined);
  if (difficulty) {
    tags.push(difficulty);
  }
  if (recipe.vegetarian) {
    tags.push("Vegetarian");
  } else if (recipe.glutenFree) {
    tags.push("Gluten-free");
  }
  return tags.length > 0 ? tags : undefined;
};

const toListing = (recipe: RecipeListItem): Listing => ({
  id: recipe.id,
  title: recipe.title,
  imageUrl: resolveImageUrl(recipe.image) ?? FALLBACK_IMAGE,
  rating:
    typeof recipe.averageRating === "number" ? recipe.averageRating : undefined,
  location: recipe.area ?? recipe.category ?? undefined,
  tags: buildRecipeTags(recipe),
});

export default UserProfilePage;
