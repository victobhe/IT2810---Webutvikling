import {
  useMemo,
  useRef,
  useEffect,
  useLayoutEffect,
  useCallback,
} from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@apollo/client";
import Header from "../components/Header";
import CardsGrid from "../components/Card-Grid";
import Card from "../components/Card";
import {
  GET_RECIPES,
  type RecipeListItem,
  type RecipesQueryData,
  type RecipesQueryVars,
} from "../graphql/recipes";
import "../styles/home-page.css";
import {
  readScrollPosition,
  writeScrollPosition,
  clearScrollPosition,
  HOME_SCROLL_KEY,
} from "../utils/scrollStorage";
import { scrollInstant } from "../utils/instantScroll";
import { useFavoriteToggle } from "../hooks/useFavoriteToggle";
import { resolveImageUrl } from "../utils/resolveImageUrl";
import { APOLLO_QUERY_POLICIES } from "../config/apolloPolicies";
import { useAuth } from "../contexts/useAuth";

const FEATURED_QUERY_VARS: RecipesQueryVars = {
  search: "",
  filters: {},
  sort: { field: "TITLE", direction: "ASC" },
  first: 3,
};

const FALLBACK_IMAGE = "/assets/logo.webp";

type RecipeSource = RecipeListItem & {
  timeMinutes?: number | null;
  summary?: string | null;
  description?: string | null;
  steps?: string[];
  coverUrl?: string | null;
};

const capitalize = (value?: string | null) => {
  if (!value) return undefined;
  return value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
};

const extractTime = (recipe: RecipeSource): number | null => {
  if (typeof recipe.time === "number" && Number.isFinite(recipe.time)) {
    return recipe.time;
  }
  if (
    typeof recipe.timeMinutes === "number" &&
    Number.isFinite(recipe.timeMinutes)
  ) {
    return recipe.timeMinutes;
  }
  return null;
};

const formatMeta = (recipe: RecipeSource): string => {
  const descriptors = new Set<string>();
  const timeValue = extractTime(recipe);
  if (timeValue) {
    descriptors.add(`${Math.round(timeValue)} min`);
  }
  const difficulty = capitalize(recipe.difficulty ?? undefined);
  if (difficulty) {
    descriptors.add(difficulty);
  }
  if (recipe.vegetarian) {
    descriptors.add("Vegetarian");
  } else if (recipe.glutenFree) {
    descriptors.add("Gluten-free");
  }
  if (recipe.area) {
    descriptors.add(recipe.area);
  } else if (recipe.category) {
    descriptors.add(recipe.category);
  }

  return descriptors.size > 0
    ? Array.from(descriptors).slice(0, 3).join(" • ")
    : "Chef favorite";
};

const clampRating = (value: number) =>
  Math.max(0, Math.min(5, Math.round(value * 10) / 10));

const getRecipeRating = (recipe: RecipeSource) => {
  if (
    typeof recipe.averageRating === "number" &&
    Number.isFinite(recipe.averageRating) &&
    (recipe.ratingCount ?? 0) > 0
  ) {
    return clampRating(recipe.averageRating);
  }
  return undefined;
};

const buildCardTags = (recipe: RecipeSource): string[] | undefined => {
  const tags = formatMeta(recipe)
    .split("•")
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);
  return tags.length > 0 ? tags : undefined;
};

const getImageSource = (recipe: RecipeSource) =>
  resolveImageUrl(recipe.image) ??
  resolveImageUrl(recipe.coverUrl ?? null) ??
  FALLBACK_IMAGE;

export default function HomePage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toggle: toggleFavorite } = useFavoriteToggle();
  const handleFavoriteToggle = useCallback(
    (recipeId: string, currentState: boolean) => {
      void toggleFavorite(recipeId, currentState);
    },
    [toggleFavorite],
  );
  const { data, loading, refetch } = useQuery<
    RecipesQueryData,
    RecipesQueryVars
  >(GET_RECIPES, {
    ...APOLLO_QUERY_POLICIES.homeRecipes,
    variables: FEATURED_QUERY_VARS,
  });

  const apiItems = data?.recipes?.items;
  const scrollTargetRef = useRef<number | null>(
    typeof window !== "undefined" ? readScrollPosition(HOME_SCROLL_KEY) : null,
  );
  const hasRestoredScrollRef = useRef(false);
  const lastUserIdRef = useRef<string | null>(user?.id ?? null);

  useEffect(() => {
    const currentUserId = user?.id ?? null;
    if (lastUserIdRef.current === currentUserId) return;
    lastUserIdRef.current = currentUserId;
    void refetch(FEATURED_QUERY_VARS);
  }, [refetch, user?.id]);

  const featuredRecipes = useMemo<RecipeSource[]>(() => {
    if (!apiItems) return [];
    return apiItems.slice(0, 3).map((item) => item as RecipeSource);
  }, [apiItems]);

  const recipeCount =
    data?.recipes?.pageInfo?.totalCount ?? apiItems?.length ?? undefined;

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (hasRestoredScrollRef.current) return;
    if (loading) return;
    const target = scrollTargetRef.current;
    if (target === null) return;

    hasRestoredScrollRef.current = true;
    scrollTargetRef.current = null;

    scrollInstant(target);
    clearScrollPosition(HOME_SCROLL_KEY);
  }, [loading, featuredRecipes.length]);

  useLayoutEffect(() => {
    if (typeof window === "undefined") return;
    if (scrollTargetRef.current !== null) return;
    scrollInstant(0);
  }, []);

  return (
    <>
      <Header recipeCount={recipeCount} />

      <main id="main-content" tabIndex={-1} className="landing-page">
        <section className="landing-hero" aria-labelledby="hero-title">
          <section className="landing-hero__grid">
            <h1 id="hero-title" className="landing-hero__title">
              Welcome to DishDelish
            </h1>
            <p className="landing-hero__lead">
              We craft reliable recipe collections for busy food lovers. Browse
              chef-tested meals, filter for every dietary need, and jump
              straight to detailed step-by-step guides.
            </p>
            <section className="landing-hero__cta">
              <button
                type="button"
                className="btn btn--primary"
                onClick={() => navigate("/recipes")}
              >
                Explore recipes
              </button>
            </section>
            <section className="landing-hero__stats" aria-live="polite">
              <span>Weekly inspiration & seasonal menus</span>
            </section>
          </section>
        </section>

        <section
          id="showcase"
          className="landing-showcase"
          aria-labelledby="showcase-title"
        >
          <header className="landing-showcase__header">
            <p className="landing-showcase__eyebrow">Featured dishes</p>
            <h2 id="showcase-title">Cook something new tonight</h2>
            <p>
              Tap a dish to open the full recipe with ingredients, steps, and
              serving suggestions.
            </p>
          </header>

          {featuredRecipes.length > 0 ? (
            <CardsGrid>
              {featuredRecipes.map((recipe, index) => (
                <Card
                  key={`${recipe.id}-${index}`}
                  item={{
                    id: recipe.id,
                    title: recipe.title,
                    imageUrl: getImageSource(recipe),
                    rating: getRecipeRating(recipe),
                    location: recipe.area ?? undefined,
                    tags: buildCardTags(recipe),
                  }}
                  isFavorite={recipe.isFavorite ?? false}
                  onFavoriteToggle={() =>
                    handleFavoriteToggle(recipe.id, recipe.isFavorite ?? false)
                  }
                  onClick={(id) => {
                    if (typeof window !== "undefined") {
                      writeScrollPosition(HOME_SCROLL_KEY, window.scrollY);
                    }
                    navigate(`/recipe/${id}`);
                  }}
                />
              ))}
            </CardsGrid>
          ) : (
            <p
              className="landing-showcase__empty"
              role="status"
              aria-live="polite"
            >
              {loading
                ? "Loading featured recipes..."
                : "Featured dishes will appear here soon."}
            </p>
          )}

          <section className="landing-showcase__cta">
            <button
              type="button"
              className="btn btn--primary"
              onClick={() => navigate("/recipes")}
            >
              Show all recipes
            </button>
          </section>
        </section>
      </main>
    </>
  );
}
