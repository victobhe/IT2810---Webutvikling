import { gql } from "@apollo/client";
import type { RecipeListItem } from "./recipes";

export const GET_MY_PROFILE = gql`
  query MyProfile($favoritesLimit: Int!, $commentsLimit: Int!) {
    myProfile(favoritesLimit: $favoritesLimit, commentsLimit: $commentsLimit) {
      user {
        id
        name
        email
      }
      stats {
        favorites
        comments
      }
      favorites {
        id
        title
        time
        difficulty
        vegetarian
        glutenFree
        category
        area
        image
        averageRating
        ratingCount
        isFavorite
      }
      favoritesHasMore
      comments {
        id
        body
        createdAt
        updatedAt
        rating
        recipe {
          id
          title
          image
          averageRating
          ratingCount
          isFavorite
        }
      }
      commentsHasMore
    }
  }
`;

export type ProfileStats = {
  favorites: number;
  comments: number;
};

export type ProfileComment = {
  id: string;
  body: string;
  createdAt: string;
  updatedAt: string;
  rating?: number | null;
  recipe: Pick<
    RecipeListItem,
    "id" | "title" | "image" | "averageRating" | "ratingCount" | "isFavorite"
  >;
};

export type ProfileQueryData = {
  myProfile: {
    user: {
      id: string;
      name?: string | null;
      email: string;
    };
    stats: ProfileStats;
    favorites: RecipeListItem[];
    favoritesHasMore: boolean;
    comments: ProfileComment[];
    commentsHasMore: boolean;
  };
};

export type ProfileQueryVars = {
  favoritesLimit: number;
  commentsLimit: number;
};
