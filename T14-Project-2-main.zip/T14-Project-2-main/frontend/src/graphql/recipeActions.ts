import { gql } from "@apollo/client";

export const TOGGLE_FAVORITE_MUTATION = gql`
  mutation ToggleFavorite($recipeId: ID!) {
    toggleFavorite(recipeId: $recipeId)
  }
`;

export const RATE_RECIPE_MUTATION = gql`
  mutation RateRecipe($recipeId: ID!, $value: Int!) {
    rateRecipe(recipeId: $recipeId, value: $value) {
      recipeId
      average
      count
    }
  }
`;

export const ADD_COMMENT_MUTATION = gql`
  mutation AddComment($recipeId: ID!, $body: String!) {
    addComment(recipeId: $recipeId, body: $body) {
      id
      recipeId
      body
      createdAt
      updatedAt
      user {
        id
        name
        email
      }
      rating
    }
  }
`;

export const DELETE_COMMENT_MUTATION = gql`
  mutation DeleteMyComment($commentId: ID!) {
    deleteMyComment(commentId: $commentId)
  }
`;

export const RECIPE_USER_STATE_QUERY = gql`
  query RecipeUserState($recipeId: ID!) {
    recipeUserState(recipeId: $recipeId) {
      isFavorite
      myRating
    }
  }
`;

export type ToggleFavoriteData = {
  toggleFavorite: boolean;
};

export type RateRecipeData = {
  rateRecipe: {
    recipeId: string;
    average: number;
    count: number;
  };
};

export type AddCommentData = {
  addComment: {
    id: string;
    recipeId: string;
    body: string;
    createdAt: string;
    updatedAt: string;
    user: {
      id: string;
      name?: string | null;
      email: string;
    };
    rating?: number | null;
  };
};

export type DeleteCommentData = {
  deleteMyComment: boolean;
};
