import { gql } from "@apollo/client";

export const ME_QUERY = gql`
  query Me {
    me {
      id
      email
      name
    }
  }
`;

export const LOGIN_MUTATION = gql`
  mutation Login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      user {
        id
        email
        name
      }
      token
    }
  }
`;

export const LOGOUT_MUTATION = gql`
  mutation Logout {
    logout
  }
`;

export const SIGNUP_MUTATION = gql`
  mutation Signup($email: String!, $password: String!, $name: String) {
    signup(email: $email, password: $password, name: $name) {
      user {
        id
        email
        name
      }
      token
    }
  }
`;

export type AuthUser = {
  id: string;
  email: string;
  name?: string | null;
};

export type MeQueryData = {
  me: AuthUser | null;
};

export type LoginMutationData = {
  login: {
    user: AuthUser;
    token?: string | null;
  };
};

export type LoginVariables = {
  email: string;
  password: string;
};

export type LogoutMutationData = {
  logout: boolean;
};

export type SignupMutationData = {
  signup: {
    user: AuthUser;
    token?: string | null;
  };
};

export type SignupVariables = {
  email: string;
  password: string;
  name?: string;
};
