import { gql } from "@apollo/client";

export const GET_RECIPES = gql`
  query Recipes(
    $search: String
    $filters: RecipeFiltersInput
    $sort: SortInput
    $after: String
    $first: Int
  ) {
    recipes(
      search: $search
      filters: $filters
      sort: $sort
      after: $after
      first: $first
    ) {
      items {
        id
        title
        time
        vegetarian
        glutenFree
        difficulty
        category
        area
        image
        averageRating
        ratingCount
        isFavorite
      }
      pageInfo {
        endCursor
        hasNextPage
        totalCount
      }
    }
  }
`;

export type RecipeListItem = {
  id: string;
  title: string;
  time?: number | null;
  vegetarian?: boolean | null;
  glutenFree?: boolean | null;
  difficulty?: string | null;
  category?: string | null;
  area?: string | null;
  image?: string | null;
  averageRating?: number | null;
  ratingCount?: number | null;
  isFavorite?: boolean;
};

export type RecipeFiltersInput = {
  q?: string;
  category?: string;
  area?: string;
  vegetarian?: boolean;
  glutenFree?: boolean;
  difficulty?: string[];
  favorites?: boolean;
  searchIngredients?: boolean;
};

export type RecipeSortInput = {
  field: "TITLE" | "TIME";
  direction: "ASC" | "DESC";
};

export type RecipesQueryData = {
  recipes: {
    items: RecipeListItem[];
    pageInfo: {
      endCursor: string | null;
      hasNextPage: boolean;
      totalCount: number | null;
    };
  };
};

export type RecipesQueryVars = {
  search: string;
  filters: RecipeFiltersInput;
  sort: RecipeSortInput;
  after?: string | null;
  first: number;
};
