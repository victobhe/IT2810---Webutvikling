import { gql } from "@apollo/client";
import type { AuthUser } from "./auth";

export const UPDATE_MY_PROFILE_MUTATION = gql`
  mutation UpdateMyProfile($input: UpdateProfileInput!) {
    updateMyProfile(input: $input) {
      id
      email
      name
    }
  }
`;

export const CHANGE_MY_PASSWORD_MUTATION = gql`
  mutation ChangeMyPassword($currentPassword: String!, $newPassword: String!) {
    changeMyPassword(
      currentPassword: $currentPassword
      newPassword: $newPassword
    )
  }
`;

export const DELETE_MY_ACCOUNT_MUTATION = gql`
  mutation DeleteMyAccount($password: String!) {
    deleteMyAccount(password: $password)
  }
`;

export type UpdateMyProfileData = {
  updateMyProfile: AuthUser;
};

export type UpdateMyProfileVars = {
  input: {
    name?: string | null;
    email?: string | null;
  };
};

export type ChangeMyPasswordData = {
  changeMyPassword: boolean;
};

export type ChangeMyPasswordVars = {
  currentPassword: string;
  newPassword: string;
};

export type DeleteMyAccountData = {
  deleteMyAccount: boolean;
};

export type DeleteMyAccountVars = {
  password: string;
};
