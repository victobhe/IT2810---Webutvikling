import { gql } from "@apollo/client";

export const ACCOUNT_MUTATIONS_CAPABILITIES = gql`
  query AccountMutationCapabilities {
    __schema {
      mutationType {
        fields {
          name
        }
      }
    }
  }
`;

export type AccountMutationCapabilitiesData = {
  __schema: {
    mutationType: {
      fields: Array<{ name: string }>;
    } | null;
  };
};
