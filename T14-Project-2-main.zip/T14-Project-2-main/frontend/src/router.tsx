import { createBrowserRouter } from "react-router-dom";
import HomePage from "./pages/HomePage";
import RecipesPage from "./pages/RecipesPage";
import RecipeDetailPage from "./pages/RecipeDetailPage";
import UserProfilePage from "./pages/UserProfilePage";
import NotFound from "./components/NotFound";

// 💡 automatisk basename basert på miljø
const base = import.meta.env.BASE_URL || "/";

export const router = createBrowserRouter(
  [
    { path: "/", element: <HomePage />, errorElement: <NotFound /> },
    { path: "/recipes", element: <RecipesPage />, errorElement: <NotFound /> },
    {
      path: "/profile",
      element: <UserProfilePage />,
      errorElement: <NotFound />,
    },
    {
      path: "/recipe/:id",
      element: <RecipeDetailPage />,
      errorElement: <NotFound />,
    },
  ],
  { basename: base },
);
