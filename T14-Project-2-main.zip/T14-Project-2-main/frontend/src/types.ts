// src/types.ts
export type SortInput = { field: "TITLE" | "TIME"; direction: "ASC" | "DESC" };
export type RecipeFiltersInput = {
  vegetarian?: boolean;
  glutenFree?: boolean;
  difficulty?: "EASY" | "MEDIUM" | "HARD";
};
