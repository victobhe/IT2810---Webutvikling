import type { QueryHookOptions } from "@apollo/client";

type QueryPolicy = Pick<
  QueryHookOptions<unknown, Record<string, unknown>>,
  "fetchPolicy" | "nextFetchPolicy" | "notifyOnNetworkStatusChange"
>;

/**
 * Centralized Apollo Client query policies.
 * Keep these in sync with README documentation.
 */
export const APOLLO_QUERY_POLICIES = {
  homeRecipes: {
    fetchPolicy: "cache-first",
    nextFetchPolicy: "cache-first",
  },
  recipesListing: {
    fetchPolicy: "cache-and-network",
    nextFetchPolicy: "cache-first",
    notifyOnNetworkStatusChange: true,
  },
  recipeDetails: {
    fetchPolicy: "cache-first",
    nextFetchPolicy: "cache-first",
  },
  recipeComments: {
    fetchPolicy: "cache-and-network",
    nextFetchPolicy: "cache-first",
    notifyOnNetworkStatusChange: true,
  },
} satisfies Record<string, QueryPolicy>;

export type ApolloPolicyName = keyof typeof APOLLO_QUERY_POLICIES;
