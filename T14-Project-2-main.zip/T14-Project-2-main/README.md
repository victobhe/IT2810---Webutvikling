# DishDelish

The DishDelish is a full-stack recipe explorer/cook book built for IT2810 Project 2. It combines a Vite/React SPA with a TypeScript GraphQL API backed by MongoDB so that users can search, sort, and filter an evolving collection of dishes.

**Link to a live version of the project:**
http://it2810-14.idi.ntnu.no/project2/

## Contents

- [Features](#features)
- [Search experience](#search-experience)
- [Search and Filtering in DishDelish](#search-and-filtering-in-dishdelish)
- [Functionality you might not notice](#functionality-you-might-not-notice)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Running the project](#running-the-project)
- [Backend deployment & operations](#backend-deployment--operations)
- [MongoDB index checklist](#mongodb-index-checklist)
- [Seeding, migrations & schema changes](#seeding-migrations--schema-changes)
- [Testing](#testing)
- [Contribution workflow](#contribution-workflow)
- [Accessibility](#accessibility)
- [Sustainability](#sustainability)
- [AI usage](#ai-usage)
- ["Admin user login"](#admin-user-login)

## Features

- GraphQL-powered search that returns the exact matches from the recipe API and shows a clear “no results” message (with suggested favorites when available) instead of fabricating mock data.
- Faceted filtering for vegetarian and/or gluten-free dishes, the difficulty and origin of dishes, and personal favorites.
- Sorting by title or preparation time, in both ascending and descending order.
- Recipe detail page with instructions, ingredients, favorites toggle, rating display, and placeholder community comments.
- Favorites management that synchronizes across tabs via storage events.
- Health-checked API server that serves both GraphQL responses and static assets, including responsive image variants generated during seeding.

## Search experience

DishDelish delivers search feedback in layers so users always see meaningful results. The input queries the GraphQL API for exact matches, then augments the list with partial or fuzzy hits grouped by field, and finally fills any gaps with curated mock data when needed—so the cards grid never feels empty. Filters for diet, difficulty, favorites, and sort order apply instantly to the returned recipes, and localStorage remembers the last search and filter state so navigating back to the grid restores the same view. Storage events keep favorites synchronized across tabs, and the UI highlights the active query and filters to reinforce that the search experience is responsive even when the backend work (e.g., vegetarian/gluten-free parity) is still in progress.

## Search and Filtering in DishDelish

**Direct GraphQL Search:**\
The recipe list is fetched using `GET_RECIPES` in `RecipesPage.tsx`. The
user always sees the server's actual results --- no fuzzy or "mock data"
layers are added automatically.

**Fallback on No Results:**\
If a search returns empty, the UI displays a clear status message and
--- when available --- a small fallback list of favorite recipes, but
never generated "fuzzy" results.

**Real-Time Filters:**\
Vegetarian, gluten-free, favorite, and difficulty filters update the
view immediately. Filter values are not stored in `localStorage`; they
reset when the user leaves the page.

**Favorite Sync Between Tabs:**\
`useFavoritesFilterSync` listens to `storage` events and updates
favorite status across browser tabs.

**Visual Feedback:**\
Search terms and active filters are highlighted in the UI so the user
always sees the current state.

## Functionality you might not notice

Some of the functionality that we have implemented could, if the user isn't observant, go unnoticed. These are:

- Textbox saying "Yummi!" if the user give 5 stars to a dish
- The print-button. The user is able to print out the dish if they want to
- Each user must log in to give a review. and each user may only give each dish one review. So if you come back later and review the same dish again, the score on the dish will be calculated again.
- Searching for ingredients and names of recipes.
- The user may search in their own favorites as well

## Tech Stack

- **Front-end:** React 19, Vite, TypeScript, Apollo Client, TanStack Query, React Router, lucide-react.
- **Back-end:** Node.js + Express, Apollo Server 4, MongoDB driver, Sharp for responsive image generation.
- **Tooling:** TypeScript, ESLint, GraphQL Code Generator, concurrently, dotenv.

## Project Structure

```
.
|-- .vite/          # Vite cache
|-- .vscode/        # Recommended workspace settings
|-- backend/        # Express/Apollo GraphQL API, seed scripts, data/
|-- frontend/      # Vite React application, public/
|-- .gitignore
`-- README.md
```

## Prerequisites

- Node.js 20.x (LTS) and npm 10.x
- MongoDB 6.x (local instance or a hosted cluster)
- Optional: PM2 or another process manager for deployment (see `backend/DEPLOY.md`)

## Installation

1. Install dependencies for each workspace:
   ```bash
   npm --prefix backend install
   npm --prefix front-end install
   ```
2. Configure environment variables:
   - `frontend/.env.development`
     ```TypeScript
     VITE_API_URL=http://localhost:3001/graphql
     VITE_USE_MOCKS=false
     ```
   - `backend/.env`
     ```TypeScript
     NODE_ENV=development
     HOST=0.0.0.0
     PORT=3001
     MONGO_URI=mongodb://localhost:27017
     MONGO_DB=project2
     # Optional overrides
     # PUBLIC_DIR=/absolute/path/to/backend/public
     # UPLOADS_DIR=/absolute/path/to/backend/public/uploads
     ```
   - If the production build needs the same API URL, add it to `frontend/.env.production`.
3. (Optional) Seed MongoDB with sample data:
   ```bash
   npm --prefix backend run seed
   ```
   This command fetches recipes from TheMealDB, upserts them into the `dishes` collection, and writes optimized image variants to `backend/public/uploads/`.

> Tip: Ensure MongoDB is running and that your `UPLOADS_DIR` folder is writable before seeding.

## Running the project

### Full stack (recommended)

1. Start MongoDB locally or ensure the remote database is reachable.
2. Launch the GraphQL API:
   ```bash
   npm --prefix backend run dev
   ```
   The API listens on `http://localhost:3001/graphql` and exposes `/health` for status checks.
3. In a separate terminal, launch the Vite dev server:
   ```bash
   npm --prefix front-end run dev
   ```
   Visit `http://localhost:5173`. The SPA reads `VITE_API_URL` and communicates with the backend.

> Note: The SPA no longer ships bundled mock recipes. Run the backend alongside the Vite dev server (or point it at a staging API) to exercise all filters and favorites logic accurately.

### Production build

- Build the SPA assets: `npm --prefix front-end run build` (outputs to `front-end/dist/`)
- Compile the backend TypeScript: `npm --prefix backend run build` (outputs to `backend/dist/`)
- Start the compiled backend: `npm --prefix backend run start` (or `npm --prefix backend run start:prod`)

For deployment to the NTNU VM, follow the detailed checklist in `backend/DEPLOY.md`.

## Backend deployment & operations

The production backend runs on the NTNU VM behind PM2. Keep the repository at `/var/www/html/project2` (or adjust the paths below if you use another directory).

### Refreshing the backend on the VM (PM2)

1. **Prepare the folder locally** – remove `backend/node_modules` and `backend/package-lock.json` so that only source files are uploaded:

```bash
rm -rf backend/node_modules backend/package-lock.json
```

2. **Stop the old process** – on the VM run `sudo pm2 stop backend && sudo pm2 delete backend` to free the Node port before copying new files.
3. **Copy the backend to the VM**:

```bash
scp -r backend <userName>@it2810-14.idi.ntnu.no:/tmp/
sudo mv /tmp/backend /var/www/html/project2/backend
sudo chmod -R 777 /var/www/html/project2/backend
```

4. **Install dependencies inside the VM**:

```bash
cd /var/www/html/project2/backend
npm install
```

5. **Configure environment variables** – create or update `/var/www/html/project2/backend/.env` with `NODE_ENV`, `HOST`, `PORT`, `MONGO_URI`, `MONGO_DB`, and optional `PUBLIC_DIR`/`UPLOADS_DIR`. Restart after every change to `.env`.
6. **Start the API with PM2**:

```bash
pm2 start npx --name backend -- ts-node --esm src/index.ts
pm2 save
```

If you later switch to systemd, reuse the same `.env` file and monitor the service with `journalctl -u project2`.

#### Logs & monitoring

- Stream runtime logs: `pm2 logs backend` (files live in `~/.pm2/logs/backend-out.log` and `backend-error.log`).
- Check process state: `pm2 status backend` or `pm2 monit` for resource usage.
- For systemd deployments, `journalctl -u project2 -f` tails the equivalent logs.

### MongoDB index checklist

Indexes on `recipeId`, `userId`, favorites, and ratings are mandatory for stable pagination and to enforce per-user uniqueness. Run these once per database:

```js
db.dishes.createIndex({ createdAt: -1, _id: 1 });
db.dishes.createIndex({
  title: "text",
  instructions: "text",
  category: "text",
  strMeal: "text",
});
db.dishes.createIndex({
  title: "text",
  instructions: "text",
  category: "text",
  strMeal: "text",
});
db.ratings.createIndex({ recipeId: 1, userId: 1 }, { unique: true });
db.ratings.createIndex({ userId: 1 });
db.ratings.createIndex({ recipeId: 1 });
db.favorites.createIndex({ userId: 1, recipeId: 1 }, { unique: true });
db.comments.createIndex({ recipeId: 1, _id: -1 });
db.comments.createIndex({ userId: 1 });
```

Running the index commands is idempotent; MongoDB will no-op if the index already exists.

## Seeding, migrations & schema changes

- Seed sample recipes and responsive images after every fresh install:

```bash
npm --prefix backend run seed
```

- Backfill historical comment ratings so `Comment.rating` always reflects the user’s rating at the time of posting:

```bash
npm --prefix backend run comment-ratings:backfill
```

- Schema highlights (see `backend/src/schema.ts`):
    - `Recipe` includes `isFavorite`, `myRating`, `averageRating`, and `ratingCount` fed by the `favorites` and `ratings` collections.
    - `RecipeUserState` exposes the favorite/rating status for the authenticated user.
    - `Comment` documents now embed a `rating` snapshot, which is why the backfill script must run during migrations.
- After deploying schema changes, re-run the MongoDB indexes above to guarantee the `favorites` and `ratings` collections enforce uniqueness on `recipeId`/`userId` pairs.

## Frontend state management

The SPA relies on Apollo Client’s normalized cache to coordinate UI state from GraphQL responses. The shared `ApolloClient` instance (`frontend/src/lib/apolloClient.ts`) configures an `InMemoryCache` with a custom type policy for the `recipes` field on `Query`. That policy deduplicates results across pages (`keyArgs: ["search", "filters", "sort"]`) and merges new edges into the existing array so cursor-based pagination works without manually stitching responses.

Mutation handlers update the cache optimistically instead of keeping parallel React state:

- `RecipesPage` toggles favorites by firing the `toggleFavorite` mutation with an optimistic result and calling `cache.modify` on the affected `Recipe` entity (`frontend/src/pages/RecipesPage.tsx`).
- `RecipeDetails` uses `cache.modify` in the rating/comment mutations to keep `averageRating`, `ratingCount`, and comment lists consistent after each action.

Because the cache is the single source of truth, UI components simply read from `useQuery` results and react to cache changes—no additional Redux/Zustand store is needed. When deploying new cache behaviour, update the type policies or mutation `update` functions accordingly.

## Testing

Our test suite combines component/unit testing (Vitest + Testing Library), end-to-end flows (Cypress UI), and backend GraphQL persistence checks (Cypress API specs):

**Component coverage:** Header, Card, CardGrid, RecipeList, LoginModal, ThemeToggle, RecipeDetails, AccountSettingsModal, HomePage, etc., ensuring rendering, user interaction, state changes, and edge cases (e.g., validation, duplicate review warnings, filter availability). We mock Apollo, router, and CSS where needed to keep tests deterministic.
**E2E coverage:** Cypress drives typical user journeys—listing → detail → login → rating/comment, search/filter/paginate on /recipes, error handling (failed rating), keyboard accessibility (focus order), and data persistence (large result sets, empty results). We intercept GraphQL calls to assert payloads and simulate failures.
Backend/persistence: Dedicated Cypress API tests hit the real GraphQL server to verify signup/login, cookie-based sessions, comment insertion, duplicate-comment errors, invalid login errors, and delete-account cleanup.

#### Considerations

Apollo caching often satisfies queries without network requests; our tests either reset the cache or assert DOM state instead of blindly waiting for intercepts. Accessibility behaviors (readonly states, notices, focus/keyboard handling) are part of the spec. Error paths (mutation failures, duplicate submissions, invalid credentials) are explicitly tested. Cleanup steps remove created comments/accounts to keep the DB tidy.

### Run Component tests

Run the following commands from the root folder:

```bash
npm --prefix frontend run test
```

#### Components (Vitest)

This section assumes that all necessary dependencies for the project are installed. Run the following commands from the root folder:

```bash
npm install cypress --save-dev

# terminal 1: Start the frontend
npm --prefix frontend run dev

#terminal 2: Start the backend
npm --prefix backend run dev

#terminal 3: Open the Cyporess GUI
cd frontend

npx cypress open
```

When the Cypress GUI is open:

1. Choose the E2E Testing option
2. Choose a browser of your choice
3. Press the “Start E2E Testing in \*“
4. After the test browser is finished loading, both the “e2e_test” and “2-api-persistence” can be run

## Contribution workflow

We follow a protected `main` branch with a `dev` integration branch:

1. Open a GitHub issue describing the change (avoid duplicates, apply relevant labels).
2. Create an issue-specific branch from the issue page and use Conventional Commit messages for each small, working change.
3. Open a pull request into `dev`, request a teammate review, and iterate on feedback before merging.
4. Merge `dev` into `main` regularly to release incremental updates.

## Sustainability

The application has been developed with sustainability in mind. The measures regarding sustainability includes:

- Inclusion of a dark mode theme to reduce power usage on certain displays and reduce eye sore
- Limit each query to 20 dishes so the API and upstream meal provider are queried only for the smallest useful batch
- Rely on GraphQL filters to reduce client-side post-processing and keep responses focused on the requested subset (favorites, tags, difficulty, etc.)
- Utilizing debounce search to avoid searching on every user input, reducing unnecessary data transfers and server load
- Persist favorites and search/filter state in localStorage and broadcast updates via storage events to avoid redundant API calls across tabs
- Loading images from an external source, with only the URL stored in the database, reducing the size of data transfers and the amount of storage used in the database
- Generate and serve responsive image variants during seeding so clients download the smallest resolution that matches their viewport
- The print function only prints out the strictly necessary information to cook the respective dish, to save on both printing paper and the environment

---

- Sustainability could most likely be improved by implementing for example:
  - Lazy-load recipe cards and images as they enter the viewport to avoid downloading what the user never scrolls to.
  - Monitor query and mutation latency to spot unnecessary refetching, then tighten throttling or debouncing around high-volume controls like filters or favorites.

## Accessibility

The application has been developed with accessibility in mind. The measures regarding accessibility includes:

- Utilizing semantic HTML and ARIA labels
- Having the ability to access every element by using the keyboard, through a logical and structural order
- Having a responsive design, adapting the content based on the size of the viewing window
- Utilizing high contrast design and colors to ensure visibility and readability

## AI usage

AI tools such as ChatGPT, Codex, Claude and Copilot have been utilized to help with development throughout the project. These tools functioned as coding assistants, with the team being responsible for the overarching architecture, quality control and final behavior of the application. AI tools have been utilized to:

- Rewrite, refactor and debug code for both functionality and styling
- Help with best practice for elements such as project architecture, file structure and code style
- Implement and configure parts of the architecture such as GraphQL and Apollo Server
- Generate certain data fields for the database, such as time to cook and difficulty
- Assist in writing and setting up tests
- Help with deployment to the VM
  All of the aforementioned uses of AI were tested, reviewed and verified by team members to ensure the generated work functioned as intended/wanted, and complied with the standards and requirements of the project.

## "Admin user login"

Email: Test@test.no
Password: TestTest
